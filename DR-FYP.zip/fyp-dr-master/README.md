# Diabetic retinopathy grading — patient-level validated, imbalance-aware, explainable

Final-year project, Department of Computer Science, Bahria University (2026–2027).
A deep-learning system that estimates diabetic retinopathy severity (grade 0–4) from a
retinal fundus photograph, served through a web interface.

**This is a research prototype, not a medical device.** The model is below the clinical
screening reference, and the interface says so on every screen.

| | |
|---|---|
| Model | EfficientNet-B0 with an ordinal-regression head, 224 × 224 |
| Training data | EyePACS, split by **patient** so no patient is in both training and testing |
| Validation QWK | **0.7569** (mean of three training runs) |
| Referable sensitivity | **0.7360** at 95% specificity — below the 0.80 screening reference |
| External validation | APTOS 2019. Under criteria fixed before the test, the model is **not** considered to generalise beyond its training population |

The full reasoning behind every choice is in `docs/DECISIONS.md`.

---

## Run the app

You need **Python 3.12** and **Node.js 20 or newer**. No GPU is needed. The trained model
is included at `runs/phase4_stage3_arm_e_efficientnet_b0/best.pth`.

### 1. Backend (Python)

First copy `.env.example` to `.env`. It already points at the model, and it is where the
assistant's free API key goes (optional — see "The assistant" below). Settings in `.env`
are read every time the backend starts, so you do not have to type them in each terminal.

**Windows (PowerShell)**

```powershell
py -3.12 -m venv .venv
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env
.venv\Scripts\python -m uvicorn backend.app:app --port 8000
```

**macOS / Linux**

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
export FYP_CHECKPOINT=runs/phase4_stage3_arm_e_efficientnet_b0/best.pth
.venv/bin/python -m uvicorn backend.app:app --port 8000
```

On Linux, `pip` installs the CUDA build of PyTorch, which is a large download. It still
runs on CPU.

Leave it running. `http://localhost:8000/health` should answer `{"status":"ok",...}`.

The backend **refuses to start** if the model file or its calibration files are missing.
That is deliberate: it will not grade images with a safety check silently absent.

### 2. Frontend (in a second terminal)

```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:3000**.

If the backend runs on a different port (for example 8001), create `frontend/.env.local`
with the line `NEXT_PUBLIC_API_BASE=http://localhost:8001` and restart `npm run dev`.

### 3. Sign in

On first start the backend creates its database (`var/app.db`) with demo accounts, so each
role can be shown. **These passwords are public — local demonstration only.**

| role | email | password |
|---|---|---|
| Patient | `patient@demo.pk` | `Patient@1234` |
| Eye specialist (Lahore clinic) | `s05@clinic.demo.pk` | `Doctor@1234` |
| Eye specialist (any demo clinic) | `s01@clinic.demo.pk` … `s10@clinic.demo.pk` | `Doctor@1234` |
| Administrator | `admin@demo.pk` | `Admin@1234` |

New patients can also create their own account. Specialist accounts are created by the
administrator (Accounts page). `python -m backend.seed --list` prints the demo logins.

### 4. What each role can do

- **Patient** — upload a fundus photograph and get the estimated grade, the separate
  referral decision, the graded image and a Grad-CAM heatmap; ask the assistant about the
  result; save it and ask an eye specialist to review it; download the PDF; send an
  appointment request to a clinic; follow each eye's score over time with a re-screening
  reminder.
- **Eye specialist** — a review queue of screenings patients sent for review: agree with
  the model, or record a different grade and referral with a note (stored beside the
  model's answer, never replacing it); confirm or decline appointment requests.
- **Administrator** — a monitoring dashboard (upload outcomes, framing and quality
  warnings, grade mix, specialist agreement, assistant outcomes) and account management.

The whole interface switches between **English and Urdu** (button in the top bar).

### 5. The assistant

The assistant answers questions about diabetic retinopathy, eye screening and the
patient's own result, **only from a small set of cited sources** (`backend/assistant/kb/`).
Urgent symptoms, medicine questions and "do I have it?" questions are handled by fixed
rules before any language model is involved, and every model answer is checked again
before it is shown.

- **Without a key** it runs in offline mode: answers are the matching source passages.
- **With a free Gemini key** in `.env` (`GEMINI_API_KEY=...`) it writes short answers
  from those passages. Check the connection with `python -m backend.assistant.check`.
- Score it on its 38-question test set plus 22 paraphrased questions:
  `python tools/eval_assistant.py` (`--offline` to test without a model).
- When a question is worded differently from the sources, Gemini rephrases it as search
  words and the search runs again; the answer still comes only from the sources.

The test fixtures used during development are **not** included, because they are derived
from EyePACS images that cannot be redistributed. `fixtures/expected/` holds the recorded
API responses for every screen state instead.

---

## Run the tests

```bash
.venv/bin/python -m pytest tests -q        # Windows: .venv\Scripts\python -m pytest tests -q
```

A handful of tests skip without the original raw EyePACS label file. That is expected.

---

## What is not in this repository

- **The datasets.** EyePACS (35 GB) and APTOS 2019 come from Kaggle and are not
  redistributed here. All training, evaluation and Grad-CAM runs were done on Kaggle, from
  the notebooks in `notebooks/`.
- **Other checkpoints.** Only the deployed model (arm E, seed 42) is included.

## Where to look

| path | what |
|---|---|
| `backend/` | the API: grading, accounts, records, review, admin, assistant |
| `backend/assistant/` | the assistant: knowledge base, retrieval, safety rules, model connectors |
| `docs/DECISIONS.md` | every non-obvious decision, with its reasoning and results |
| `docs/api-contract.md` | the backend API |
| `data/splits/` | the patient-level train / validation / test splits |
| `src/` | data pipeline, models, training, evaluation, Grad-CAM, inference |
| `backend/` | FastAPI service |
| `frontend/` | Next.js interface |
| `notebooks/` | the Kaggle notebooks that produced every result |
| `tests/` | including `test_no_leakage.py`, which enforces the patient-level split |

// Only same-site paths, so a crafted link cannot send someone elsewhere after sign-in.
export function safeNext(next: string | null): string | null {
  return next && next.startsWith("/") && !next.startsWith("//") ? next : null;
}

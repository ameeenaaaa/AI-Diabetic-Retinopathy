"use client";

// The downloadable screening report. Same rules as the page: both answers at equal weight,
// guard.message verbatim, all four disclaimer strings verbatim, the graded crop (not the
// upload), and a provenance line built from /meta fields — never `meta.provenance`.

import type { MetaSnapshot, SavedScreening } from "./store";
import type { PredictGraded } from "./types";
import { guidanceForGraded } from "./guidance";

const f3 = (x: number) => x.toFixed(3);
const fmt2 = (x: number) => {
  const s = x.toFixed(2);
  return Number(s) === 0 ? "0.00" : s;
};

export function gradeBasis(cuts: PredictGraded["cuts"], grade: number): string {
  if (grade === 0) return `Score is below the first cut point, ${f3(cuts[0])}.`;
  if (grade === 4) return `Score is above the last cut point, ${f3(cuts[3])}.`;
  return `Score is between the cut points ${f3(cuts[grade - 1])} and ${f3(cuts[grade])}.`;
}

export function provenanceLine(m: MetaSnapshot): string {
  return `Model ${m.run_id}, ${m.arch} with an ${m.head.replace(/_/g, "-")} head, seed ${m.seed}. Reported figures are means over three training runs: validation quadratic weighted kappa ${m.reported_val_qwk.toFixed(4)}, referable sensitivity ${m.reported_val_sens_at_spec95.toFixed(4)} at 95% specificity.`;
}

const EYE: Record<SavedScreening["eye"], string> = {
  left: "Left eye",
  right: "Right eye",
  unspecified: "Eye not specified",
};

// jsPDF's built-in fonts are WinAnsi; swap the few characters outside it.
const pdfSafe = (s: string) =>
  s.replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/≥/g, ">=").replace(/≤/g, "<=");

export async function downloadReport(rec: SavedScreening): Promise<void> {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 16;
  const CW = W - 2 * M;
  let y = M;

  const ensure = (h: number) => {
    if (y + h > H - M) {
      doc.addPage();
      y = M;
    }
  };
  const text = (s: string, size = 10, style: "normal" | "bold" = "normal", gap = 1.5, color = 20) => {
    doc.setFont("helvetica", style);
    doc.setFontSize(size);
    doc.setTextColor(color);
    const lines = doc.splitTextToSize(pdfSafe(s), CW) as string[];
    const lh = size * 0.42;
    for (const line of lines) {
      ensure(lh);
      doc.text(line, M, y + lh * 0.8);
      y += lh;
    }
    y += gap;
  };
  const rule = () => {
    ensure(4);
    doc.setDrawColor(190);
    doc.setLineWidth(0.3);
    doc.line(M, y, W - M, y);
    y += 4;
  };

  const r = rec.result;
  const created = new Date(rec.createdAt);

  // header
  text("Diabetic retinopathy grade estimate", 17, "bold", 1);
  text("Screening report from a research prototype — not a medical device", 10, "normal", 3, 90);
  text(
    `Date: ${created.toLocaleString("en-GB")}    Report ID: ${rec.id.slice(0, 8)}    ${EYE[rec.eye]}${rec.label ? `    Label: ${rec.label}` : ""}`,
    9,
    "normal",
    1,
    70,
  );
  text(`Input file: ${rec.fileName}${rec.patient ? `    Patient: ${rec.patient.name}` : ""}`, 9, "normal", 3, 70);
  rule();

  // two answers, equal weight, side by side
  ensure(30);
  const colW = (CW - 8) / 2;
  const top = y;
  const col = (x: number, label: string, value: string, note: string) => {
    let yy = top;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(90);
    doc.text(label, x, yy + 3);
    yy += 6;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(20);
    doc.text(pdfSafe(value), x, yy + 6);
    yy += 10;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(70);
    const lines = doc.splitTextToSize(pdfSafe(note), colW) as string[];
    doc.text(lines, x, yy + 3);
    return yy + lines.length * 3.8 + 3;
  };
  const yA = col(M, "Estimated grade", r.grade_name, `Grade ${r.grade} on the 0 to 4 scale. ${gradeBasis(r.cuts, r.grade)}`);
  doc.setDrawColor(190);
  doc.line(M + colW + 4, top, M + colW + 4, top + 26);
  const yB = col(
    M + colW + 8,
    "Referral",
    r.referable ? "Refer" : "Not flagged",
    `Score is ${r.referable ? "at or above" : "below"} the referral threshold, ${f3(r.referral_threshold)}.`,
  );
  y = Math.max(yA, yB) + 2;

  text(`Score ${fmt2(r.score)}. Grade cut points at ${r.cuts.map(f3).join(", ")}.`, 9, "normal", 1.5, 70);
  text(
    "These are two separate decisions read off the same score. The grade uses four cut points fitted to agree with human graders; referral uses one threshold fitted separately for screening." +
      ((r.grade >= 2) !== r.referable
        ? " For this image they differ, and both are shown as computed."
        : ""),
    9,
    "normal",
    3,
    40,
  );

  // image-quality (framing) check, verbatim
  text(
    r.guard.status === "ok"
      ? "Image-quality check (framing)"
      : "Image-quality check (framing) — WARNING: outside the training range",
    11,
    "bold",
    1,
  );
  text(r.guard.message, 10, "normal", 3);
  if (r.quality) {
    text(
      r.quality.status === "ok"
        ? "Image-quality check (capture)"
        : "Image-quality check (capture) — WARNING: low image quality",
      11,
      "bold",
      1,
    );
    text(r.quality.message, 10, "normal", 3);
  }

  // images
  const imgs: [string, string][] = [];
  if (r.preprocessed_png) imgs.push([r.preprocessed_png, "Graded image (224 x 224 crop the model received)"]);
  if (r.overlay_png) imgs.push([r.overlay_png, "Grad-CAM (7 x 7 grid, enlarged; broad regions only)"]);
  if (imgs.length) {
    const size = 70;
    ensure(size + 10);
    imgs.forEach(([src, cap], i) => {
      const x = M + i * (size + 10);
      try {
        doc.addImage(src, "PNG", x, y, size, size);
      } catch {
        doc.setFontSize(9);
        doc.text("Image could not be embedded.", x, y + 10);
      }
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.setTextColor(80);
      doc.text(doc.splitTextToSize(cap, size) as string[], x, y + size + 4);
    });
    y += size + 12;
  }
  rule();

  // specialist review — beside the model's answer, never instead of it
  if (rec.review && rec.review.status !== "not_requested") {
    text("Specialist review", 12, "bold", 1);
    if (rec.review.status === "pending") {
      text("Requested; waiting for a specialist.", 10, "normal", 3);
    } else {
      text(
        rec.review.agrees
          ? "The specialist agreed with the estimated grade and the referral decision above."
          : `The specialist recorded a different reading: grade ${rec.review.grade_name}, referral ${rec.review.refer ? "Refer" : "Not flagged"}. The model's own answer above is unchanged.`,
        10,
        "normal",
        1,
      );
      if (rec.review.note) text(`Note: ${rec.review.note}`, 10, "normal", 1);
      text(
        `Reviewed by ${rec.review.reviewer_name ?? "a specialist"}${rec.review.reviewed_at ? `, ${new Date(rec.review.reviewed_at).toLocaleDateString("en-GB")}` : ""}.`,
        9,
        "normal",
        3,
        70,
      );
    }
    rule();
  }

  // guidance
  const g = guidanceForGraded(r.referable, r.guard, rec.meta.reported_val_sens_at_spec95, r.quality);
  text("Referral guidance", 12, "bold", 1);
  text(g.heading, 10, "bold", 1);
  text(g.summary, 10, "normal", 1.5);
  g.steps.forEach((s, i) => text(`${i + 1}. ${s}`, 10, "normal", 0.8));
  y += 1;
  if (g.framingNote) text(g.framingNote, 10, "normal", 1.5);
  if (g.qualityNote) text(g.qualityNote, 10, "normal", 1.5);
  text(g.urgent, 10, "bold", 3);
  rule();

  // limits — verbatim, all four
  text("Limits of this prototype", 12, "bold", 1);
  r.disclaimer.forEach((d) => text(`- ${d}`, 10, "normal", 1));
  y += 2;
  rule();
  text(provenanceLine(rec.meta), 8, "normal", 1, 90);
  text(
    "This report estimates a grade from one photograph. It is not a medical assessment and does not replace an examination by an eye specialist.",
    8,
    "normal",
    0,
    90,
  );

  const stamp = created.toISOString().slice(0, 10);
  doc.save(`dr-screening-report-${stamp}-${rec.id.slice(0, 8)}.pdf`);
}

"use client";

// The sign-in token, kept in this browser's localStorage so a refresh stays signed in.
// Every access is wrapped: storage can be unavailable (private windows, blocked site data),
// and then the user is simply signed in for this tab only.

const KEY = "dr-session-token";
let memory: string | null = null;

export function getToken(): string | null {
  if (memory) return memory;
  try {
    memory = typeof window !== "undefined" ? window.localStorage.getItem(KEY) : null;
  } catch {
    memory = null;
  }
  return memory;
}

export function setToken(token: string | null): void {
  memory = token;
  try {
    if (token) window.localStorage.setItem(KEY, token);
    else window.localStorage.removeItem(KEY);
  } catch {
    // storage unavailable: the in-memory copy still works for this tab
  }
}

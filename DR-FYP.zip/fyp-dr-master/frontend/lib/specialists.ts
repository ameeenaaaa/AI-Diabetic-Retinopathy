// The specialist directory, now served by the backend (GET /specialists, DECISION-078) so
// that each clinic is linked to the specialist account that answers its requests.
//
// DEMO DIRECTORY — the seeded clinics (backend/demo_specialists.json) are invented for the
// prototype and have no contact details, so a demo can never send someone to a real phone
// number. Clinics an administrator adds are marked `demo: false`.

import { anyArray, getJson, must } from "./api";

export type Specialty = "Vitreoretinal specialist" | "Ophthalmologist" | "Diabetic eye screening";

export interface Specialist {
  id: string;
  clinic: string;
  lead: string;
  specialties: Specialty[];
  city: string;
  area: string;
  services: string[];
  days: string;
  languages: string[];
  demo: boolean;
  bookable: boolean;
}

export const SPECIALTIES: Specialty[] = ["Vitreoretinal specialist", "Ophthalmologist", "Diabetic eye screening"];

export const listSpecialists = () => must(getJson<Specialist[]>("/specialists", anyArray));

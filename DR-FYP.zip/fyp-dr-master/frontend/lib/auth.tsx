"use client";

// Who is signed in, and the gate every role-specific page sits behind (DECISION-078).
//
// The server decides what each role may do; this file only decides what to SHOW. Hiding a
// button is never the protection — every route checks the role again on the server.

import Link from "next/link";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { getJson, problemText, sendJson } from "./api";
import { useI18n } from "./i18n";
import { getToken, setToken } from "./session";
import type { Role, User } from "./types";

type AuthState =
  | { kind: "loading" }
  | { kind: "guest" }
  | { kind: "user"; user: User };

interface Auth {
  state: AuthState;
  user: User | null;
  login: (email: string, password: string) => Promise<string | null>;
  register: (body: { name: string; email: string; password: string; city: string; phone: string }) => Promise<string | null>;
  logout: () => Promise<void>;
}

const Ctx = createContext<Auth | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({ kind: "loading" });

  useEffect(() => {
    let live = true;
    if (!getToken()) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- no token: nothing to fetch
      setState({ kind: "guest" });
      return;
    }
    getJson<{ user: User }>("/auth/me").then((r) => {
      if (!live) return;
      if (r.kind === "ok") setState({ kind: "user", user: r.data.user });
      else {
        if (r.kind === "http" && r.status === 401) setToken(null);
        setState({ kind: "guest" });
      }
    });
    return () => {
      live = false;
    };
  }, []);

  const accept = useCallback((token: string, user: User) => {
    setToken(token);
    setState({ kind: "user", user });
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      const r = await sendJson<{ token: string; user: User }>("/auth/login", { email, password });
      if (r.kind !== "ok") return r.kind === "http" && r.status === 401 ? "The email or password is wrong." : problemText(r);
      accept(r.data.token, r.data.user);
      return null;
    },
    [accept],
  );

  const register = useCallback(
    async (body: { name: string; email: string; password: string; city: string; phone: string }) => {
      const r = await sendJson<{ token: string; user: User }>("/auth/register", body);
      if (r.kind !== "ok") return problemText(r);
      accept(r.data.token, r.data.user);
      return null;
    },
    [accept],
  );

  const logout = useCallback(async () => {
    await sendJson("/auth/logout", {});
    setToken(null);
    setState({ kind: "guest" });
  }, []);

  const value = useMemo<Auth>(
    () => ({ state, user: state.kind === "user" ? state.user : null, login, register, logout }),
    [state, login, register, logout],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): Auth {
  const a = useContext(Ctx);
  if (!a) throw new Error("useAuth must be used inside <AuthProvider>");
  return a;
}

export const HOME_FOR: Record<Role, string> = {
  patient: "/screen",
  specialist: "/specialist",
  admin: "/admin",
};

// Renders children only for the given roles; otherwise says why, and what to do.
export function RequireRole({ roles, children }: { roles: Role[]; children: React.ReactNode }) {
  const { state } = useAuth();
  const { t } = useI18n();

  if (state.kind === "loading") return <p className="text-ink-2" role="status">…</p>;

  if (state.kind === "guest") {
    const next = typeof window !== "undefined" ? window.location.pathname + window.location.search : "/";
    return (
      <div className="mx-auto max-w-xl py-10 text-center">
        <h1 className="text-3xl font-bold">{t("gate.need_signin")}</h1>
        <p className="mt-3 text-lg text-ink-2">{t("gate.need_signin_lead")}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href={`/login?next=${encodeURIComponent(next)}`} className="btn-primary">
            {t("nav.signin")}
          </Link>
          {roles.includes("patient") && (
            <Link href={`/register?next=${encodeURIComponent(next)}`} className="btn-ghost">
              {t("nav.register")}
            </Link>
          )}
        </div>
      </div>
    );
  }

  if (!roles.includes(state.user.role)) {
    return (
      <div className="mx-auto max-w-xl py-10 text-center">
        <h1 className="text-3xl font-bold">{t("gate.wrong_role")}</h1>
        <p className="mt-3 text-lg text-ink-2">
          {t("gate.wrong_role_lead")} {t(`role.${state.user.role}`)}.
        </p>
        <Link href={HOME_FOR[state.user.role]} className="btn-primary mt-6">
          {t(state.user.role === "admin" ? "nav.dashboard" : state.user.role === "specialist" ? "nav.review" : "nav.screen")}
        </Link>
      </div>
    );
  }

  return <>{children}</>;
}

// The API contract, typed from docs/api-contract.md and fixtures/expected/*.json.
// The /predict response is a discriminated union on `graded`: the declined variant has no
// `grade` key at all, so nothing can read a grade without narrowing first.

export type GuardStatus =
  | "ok"
  | "framing_below_training_range"
  | "framing_above_training_range"
  | "no_retina_detected"
  | "not_a_fundus_photograph"; // DECISION-076: declined before grading

// The two statuses that come back with `graded: false`.
export type DeclinedStatus = "no_retina_detected" | "not_a_fundus_photograph";

export interface GuardInRange {
  status: Exclude<GuardStatus, DeclinedStatus>;
  coverage: number;
  low: number;
  high: number;
  message: string;
}

export interface GuardNoRetina {
  status: DeclinedStatus;
  coverage: null;
  low: number;
  high: number;
  message: string;
}

export interface CoverageCalibration {
  split: string;
  n_images: number;
  low: number;
  high: number;
}

export interface Meta {
  run_id: string;
  seed: number;
  arch: string;
  head: string;
  image_size: number;
  provenance: string;
  reported_val_qwk: number;
  reported_val_sens_at_spec95: number;
  disclaimer: string[];
  coverage_calibration: CoverageCalibration;
}

// Capture quality of the raw upload (DECISION-076). Qualifies a grade; never withholds it.
// Optional because screenings saved before it existed do not carry it.
export interface Quality {
  status: "ok" | "poor_capture_quality";
  flags: string[];
  message: string;
}

export type GradeIndex = 0 | 1 | 2 | 3 | 4;

export interface PredictGraded {
  graded: true;
  grade: GradeIndex;
  grade_name: string;
  score: number;
  referable: boolean;
  referral_threshold: number;
  cuts: [number, number, number, number];
  guard: GuardInRange;
  quality?: Quality;
  run_id: string;
  disclaimer: string[];
  overlay_png?: string;
  preprocessed_png?: string;
  // Present when a signed-in patient graded the image: the key for saving it (DECISION-078).
  result_id?: string;
}

export interface PredictDeclined {
  graded: false;
  guard: GuardNoRetina;
  run_id: string;
  disclaimer: string[];
}

export type PredictResponse = PredictGraded | PredictDeclined;

// The ladder of names by index, used only to label ruler segments. The grade of a result
// always comes from `grade_name` in the response, never from this list.
export const GRADE_NAMES = ["No DR", "Mild", "Moderate", "Severe", "Proliferative"] as const;

// ------------------------------------------------------------------ accounts (DECISION-078)
export type Role = "patient" | "specialist" | "admin";

export interface User {
  id: number;
  email: string;
  name: string;
  role: Role;
  city: string;
  phone: string;
  active: boolean;
  created_at: string;
  clinic?: string | null;
}

// A specialist's review, stored BESIDE the model's answer — never replacing it.
export type ReviewStatus = "not_requested" | "pending" | "reviewed";
export interface Review {
  status: ReviewStatus;
  agrees?: boolean;
  grade?: number;
  grade_name?: string;
  refer?: boolean;
  note?: string;
  reviewer_name?: string;
  reviewed_at?: string;
}

// ------------------------------------------------------------------ assistant
export interface ChatSource {
  id: string; // S1, S2 … or R
  title: string;
  heading: string;
  source: string;
  url: string;
  kind: "health" | "app" | "result";
}

export type ChatAction =
  | { type: "find_specialist"; city: string | null }
  | { type: "download_report" }
  | { type: "new_screening" }
  | { type: "open_records" };

export type ChatOutcome = "answered" | "urgent" | "refused" | "out_of_scope" | "blocked" | "error";

export interface ChatReply {
  answer: string;
  outcome: ChatOutcome;
  lang: "en" | "ur";
  mode: "llm" | "offline" | "fixed";
  provider: string;
  sources: ChatSource[];
  cited: string[];
  actions: ChatAction[];
  note: string;
  searched_as?: string; // the model's rephrased search words, when used (DECISION-080)
}

export interface AssistantStatus {
  provider: string;
  label: string;
  mode: "llm" | "offline";
  passages: number;
}

// ------------------------------------------------------------------ admin
export interface Stats {
  generated_at: string;
  users: Record<Role, number>;
  uploads: {
    total: number;
    graded: number;
    declined_not_fundus: number;
    declined_no_retina: number;
    framing_warning: number;
    poor_quality: number;
    referable: number;
    grades: number[];
    grade_names: string[];
    weekly: number[];
  };
  screenings: {
    saved: number;
    review_pending: number;
    reviewed: number;
    agreed: number;
    referral_agreed: number;
    table: number[][];
  };
  appointments: Record<"requested" | "confirmed" | "declined" | "completed" | "cancelled", number>;
  assistant: Record<ChatOutcome, number>;
}

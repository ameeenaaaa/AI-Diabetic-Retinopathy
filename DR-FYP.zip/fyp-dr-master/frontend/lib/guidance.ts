// Referral guidance — what to do next, read off `referable` and `guard` ONLY.
//
// It is never derived from the grade (CLAUDE.md: grade and referral are independent). Every
// branch ends at the same place — an examination by an eye specialist — because this model
// estimates a grade; it does not replace that examination. The missed-referral share comes
// from /meta, never from a constant typed here.

import type { DeclinedStatus, GuardInRange, Quality } from "./types";

export interface Guidance {
  heading: string;
  summary: string;
  steps: string[];
  framingNote: string | null;
  qualityNote: string | null;
  urgent: string;
  specialistHint: string;
}

const URGENT =
  "Sudden changes in vision — new floaters, flashes of light, a shadow or curtain across your sight, or sudden blurring — need urgent eye care the same day. Do not wait for an appointment request to be answered.";

function framingNote(guard: GuardInRange): string | null {
  if (guard.status === "ok") return null;
  return "This photograph is framed outside the range the model was trained on, so this reading is less dependable than usual. A re-taken photograph may help, but the specialist examination matters either way.";
}

function qualityNote(q?: Quality): string | null {
  if (!q || q.status === "ok") return null;
  return "The photograph itself is of low quality, so this reading is less dependable than usual. Retaking the photograph and uploading it again is recommended; either way, the specialist examination is what matters.";
}

export function missedShare(sensAtSpec95: number): number {
  return Math.round((1 - sensAtSpec95) * 100);
}

export function guidanceForGraded(
  referable: boolean,
  guard: GuardInRange,
  sensAtSpec95: number,
  quality?: Quality,
): Guidance {
  if (referable) {
    return {
      heading: "Recommended: an eye-specialist assessment",
      summary:
        "The score is at or above the referral threshold, so this image was flagged for referral. That is a reason to be examined, not a finding about your eye.",
      steps: [
        "Request an appointment with an ophthalmologist or a vitreoretinal (retina) specialist.",
        "Tell the clinic the photograph was flagged for referral by a screening prototype, and ask how soon they want to see you.",
        "Take the PDF report with you, together with your recent blood-sugar (HbA1c) results if you have them.",
      ],
      framingNote: framingNote(guard),
      qualityNote: qualityNote(quality),
      urgent: URGENT,
      specialistHint: "A vitreoretinal specialist or a general ophthalmologist can assess this.",
    };
  }
  const missed = missedShare(sensAtSpec95);
  return {
    heading: "Recommended: keep your routine diabetic eye examinations",
    summary: `The score is below the referral threshold, so this image was not flagged. Not flagged is not reassurance: on validation images, about ${missed}% of the images that needed referral were not flagged either.`,
    steps: [
      "Keep the regular dilated eye examinations your doctor advises for people with diabetes.",
      "If you have not had one in the last year, request an appointment with an ophthalmologist or a diabetic eye-screening service.",
      "Take the PDF report with you so the specialist can see what was graded.",
    ],
    framingNote: framingNote(guard),
    qualityNote: qualityNote(quality),
    urgent: URGENT,
    specialistHint: "An ophthalmologist or a diabetic eye-screening service can examine you.",
  };
}

export function guidanceForDeclined(status: DeclinedStatus = "no_retina_detected"): Guidance {
  return {
    heading: "No referral reading for this upload",
    summary:
      status === "not_a_fundus_photograph"
        ? "The upload does not look like a usable retinal photograph, so nothing was graded and no referral decision was made."
        : "No retina was found in the image, so nothing was graded and no referral decision was made.",
    steps: [
      "Upload a fundus (retinal) photograph — the round image of the back of the eye taken with a retinal camera.",
      "Whatever any upload shows, a dilated examination by an eye specialist is how diabetic retinopathy is assessed.",
    ],
    framingNote: null,
    qualityNote: null,
    urgent: URGENT,
    specialistHint: "An ophthalmologist or a diabetic eye-screening service can examine you.",
  };
}

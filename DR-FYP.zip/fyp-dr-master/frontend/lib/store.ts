"use client";

// Records: saved screenings, appointment requests and specialist reviews.
//
// Since DECISION-078 these live on the server, under the signed-in account, instead of in
// this browser's IndexedDB. What is kept is unchanged: the model's result, the 224 x 224
// crop it graded and its Grad-CAM overlay — never the original upload. A result is saved
// by its server-side `result_id`, so a saved record is exactly what the model returned.

import { useCallback, useEffect, useState } from "react";
import { getJson, must, anyArray, sendJson } from "./api";
import type { Meta, PredictGraded, Review } from "./types";

// The figures the PDF and the saved report need, captured at save time.
export interface MetaSnapshot {
  run_id: string;
  seed: number;
  arch: string;
  head: string;
  image_size: number;
  reported_val_qwk: number;
  reported_val_sens_at_spec95: number;
}

export type Eye = "left" | "right" | "unspecified";

export interface SavedScreening {
  id: string;
  createdAt: string; // ISO
  fileName: string;
  label: string;
  eye: Eye;
  result: PredictGraded;
  meta: MetaSnapshot;
  review?: Review;
  patient?: { name: string; city: string }; // present when a specialist is viewing
}

export type AppointmentStatus = "requested" | "confirmed" | "declined" | "completed" | "cancelled";
export type Slot = "morning" | "afternoon" | "evening";

export interface Appointment {
  id: string;
  createdAt: string;
  updatedAt: string;
  specialistId: string;
  specialistName: string;
  city: string;
  screeningId: string | null;
  patientName: string;
  phone: string;
  preferredDate: string; // yyyy-mm-dd
  slot: Slot;
  notes: string;
  status: AppointmentStatus;
  specialistNote: string;
}

export function snapshotMeta(m: Meta): MetaSnapshot {
  return {
    run_id: m.run_id,
    seed: m.seed,
    arch: m.arch,
    head: m.head,
    image_size: m.image_size,
    reported_val_qwk: m.reported_val_qwk,
    reported_val_sens_at_spec95: m.reported_val_sens_at_spec95,
  };
}

const CHANGED = "dr-records-changed";
export function announce() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event(CHANGED));
}

// ------------------------------------------------------------------ screenings
export const listScreenings = () => must(getJson<SavedScreening[]>("/screenings", anyArray));

export async function getScreening(id: string): Promise<SavedScreening | undefined> {
  if (!id) return undefined;
  try {
    return await must(getJson<SavedScreening>(`/screenings/${encodeURIComponent(id)}`));
  } catch (e) {
    if (e instanceof Error && /not yours|does not exist/i.test(e.message)) return undefined;
    throw e;
  }
}

export async function saveScreening(
  resultId: string,
  opts: { eye: Eye; label: string; requestReview: boolean },
): Promise<SavedScreening> {
  const s = await must(
    sendJson<SavedScreening>("/screenings", {
      result_id: resultId,
      eye: opts.eye,
      label: opts.label,
      request_review: opts.requestReview,
    }),
  );
  announce();
  return s;
}

export async function deleteScreening(id: string): Promise<void> {
  await must(sendJson(`/screenings/${encodeURIComponent(id)}`, undefined, "DELETE"));
  announce();
}

export async function requestReview(id: string): Promise<SavedScreening> {
  const s = await must(sendJson<SavedScreening>(`/screenings/${encodeURIComponent(id)}/request-review`, {}));
  announce();
  return s;
}

// ------------------------------------------------------------------ review (specialist)
export const reviewQueue = (status: "pending" | "reviewed") =>
  must(getJson<SavedScreening[]>(`/reviews/queue?status=${status}`, anyArray));

export async function submitReview(
  id: string,
  body: { agrees: boolean; grade?: number; refer?: boolean; note: string },
): Promise<SavedScreening> {
  const s = await must(sendJson<SavedScreening>(`/screenings/${encodeURIComponent(id)}/review`, body));
  announce();
  return s;
}

// ------------------------------------------------------------------ appointments
export const listAppointments = () => must(getJson<Appointment[]>("/appointments", anyArray));

export async function createAppointment(body: {
  specialist_id: string;
  screening_id: string | null;
  patient_name: string;
  phone: string;
  preferred_date: string;
  slot: Slot;
  notes: string;
}): Promise<Appointment> {
  const a = await must(sendJson<Appointment>("/appointments", body));
  announce();
  return a;
}

export async function setAppointmentStatus(
  a: Appointment,
  status: Exclude<AppointmentStatus, "requested">,
  note = "",
): Promise<void> {
  await must(sendJson(`/appointments/${encodeURIComponent(a.id)}`, { status, note }, "PATCH"));
  announce();
}

// ------------------------------------------------------------------ hook
export type Loaded<T> = { kind: "loading" } | { kind: "ok"; data: T } | { kind: "error"; message: string };

// Re-reads whenever any record changes in this tab.
export function useRecords<T>(load: () => Promise<T>): Loaded<T> {
  const [state, setState] = useState<Loaded<T>>({ kind: "loading" });
  const run = useCallback(() => {
    load()
      .then((data) => setState({ kind: "ok", data }))
      .catch((e: unknown) => setState({ kind: "error", message: e instanceof Error ? e.message : String(e) }));
  }, [load]);

  useEffect(() => {
    run();
    window.addEventListener(CHANGED, run);
    return () => window.removeEventListener(CHANGED, run);
  }, [run]);

  return state;
}

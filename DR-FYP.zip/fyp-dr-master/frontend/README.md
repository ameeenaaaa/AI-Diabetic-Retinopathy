# Frontend — retinopathy grade estimate

Next.js 16 (App Router) + TypeScript + Tailwind v4. Rules for this app are in the repo-root
`CLAUDE.md` (frontend section); the API contract is `docs/api-contract.md`.

## Run

The backend must be up first — this page reads every figure and all four limits from it.

```
# repo root
set FYP_CHECKPOINT=<path to seed 42 best.pth>
.venv\Scripts\python -m uvicorn backend.app:app --port 8000

# frontend/
npm install
npm run dev          # http://localhost:3000
```

Point at a different backend with `NEXT_PUBLIC_API_BASE`.

## Layout

| path | what |
|---|---|
| `app/page.tsx` | home: the patient journey as a flow (no sign-in step) |
| `app/screen/page.tsx` | upload, grading, declined, both framing warnings, graded, every error; then referral guidance, save, PDF |
| `app/specialists/page.tsx` | specialist directory with search/filters and the appointment-request form |
| `app/records/page.tsx` | saved screenings and appointment requests (status: Requested / Booked / Attended / Cancelled) |
| `app/records/view/page.tsx` | one saved screening (`?id=`), re-rendered from the stored result |
| `app/about/page.tsx` | what the model was measured to do, from `/meta` |
| `lib/types.ts` | the contract; `/predict` is a union on `graded` so `grade` cannot be read unnarrowed |
| `lib/api.ts` | one client; every call resolves to ok / http / network / malformed, validated at runtime |
| `lib/store.ts` | browser-only records in IndexedDB (DECISION-075) — nothing is stored server-side |
| `lib/guidance.ts` | referral guidance, read off `referable` + `guard` only, never `grade` |
| `lib/report.ts` | client-side PDF (jsPDF): both answers, guard message, all four limits, provenance |
| `lib/specialists.ts` | **demo** directory — invented clinics, no contact details; replace before real use |
| `components/ScoreRuler.tsx` | the score against the four cut points and the referral threshold, to scale |
| `components/Readout.tsx` | grade and referral as two answers of equal weight |

## Checks before committing

```
npx tsc --noEmit && npm run lint && npm run build
grep -rn "0\.7615\|0\.7464" app components lib .next   # must print nothing
```

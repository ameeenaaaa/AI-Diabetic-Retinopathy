import Link from "next/link";
import { ArrowDown, CalendarCheck, FileText, History, ImagePlus, ScanEye, Stethoscope, Bot } from "lucide-react";
import type { ReactNode } from "react";

// The patient journey, top to bottom, after signing in as a patient (DECISION-078). Each step links to the page that does it.

function Arrow() {
  return (
    <div className="flex justify-center py-2 text-brand/60" aria-hidden="true">
      <ArrowDown className="h-4 w-4" />
    </div>
  );
}

function Step({
  icon,
  title,
  body,
  href,
  n,
  tone = "plain",
}: {
  icon: ReactNode;
  title: string;
  body?: string;
  href: string;
  n: number;
  tone?: "plain" | "highlight" | "card";
}) {
  const box =
    tone === "highlight"
      ? "rounded-2xl border border-brand/20 bg-brand-soft px-5 py-4"
      : tone === "card"
        ? "h-full rounded-2xl border border-rule bg-sheet px-5 py-4 shadow-sm"
        : "rounded-2xl px-5 py-2";
  const tint = TINTS[(n - 1) % TINTS.length];
  return (
    <li className="list-none">
      <Link
        href={href}
        className={`group flex flex-col items-center text-center transition-colors hover:border-brand/40 ${box}`}
      >
        <span className="sr-only">Step {n}: </span>
        <span className={`icon-circle h-12 w-12 ${tint}`}>{icon}</span>
        <span className="mt-2 font-bold group-hover:text-brand">{title}</span>
        {body && <span className="mt-0.5 text-[0.95rem] leading-snug text-ink-2">{body}</span>}
      </Link>
    </li>
  );
}

// Colour identifies the STEP, never a result.
const TINTS = [
  "bg-brand-soft text-brand",
  "bg-sev-0 text-indigo",
  "bg-accent-soft text-accent",
  "bg-warm-soft text-warm",
  "bg-blue-soft text-blue",
  "bg-rose-soft text-rose",
  "bg-brand-soft text-brand",
];

const ic = "h-6 w-6";

export function FlowDiagram() {
  return (
    <ol aria-label="How a screening works" className="mx-auto max-w-3xl">
      <Step n={1} href="/screen" icon={<ImagePlus aria-hidden="true" className={ic} />} title="Upload a retinal image" body="One fundus photograph, JPEG or PNG" />
      <Arrow />
      <Step
        n={2}
        href="/screen"
        tone="highlight"
        icon={<ScanEye aria-hidden="true" className={ic} />}
        title="Automated screening"
        body="Grade 0–4 estimate + Grad-CAM + image-quality (framing) check"
      />
      <Arrow />
      <li className="list-none">
        <ul className="grid gap-3 sm:grid-cols-3">
          <Step
            n={3}
            href="/records"
            tone="card"
            icon={<FileText aria-hidden="true" className={ic} />}
            title="Screening report"
            body="Save the result and download a PDF"
          />
          <Step
            n={4}
            href="/screen"
            tone="card"
            icon={<Stethoscope aria-hidden="true" className={ic} />}
            title="Referral guidance"
            body="Which professional assessment to arrange next"
          />
          <Step
            n={5}
            href="/assistant"
            tone="card"
            icon={<Bot aria-hidden="true" className={ic} />}
            title="Ask the assistant"
            body="Questions about the result, answered from cited sources"
          />
        </ul>
      </li>
      <Arrow />
      <Step n={6} href="/specialists" icon={<CalendarCheck aria-hidden="true" className={ic} />} title="Specialist review and appointment" body="An eye specialist reviews the result and answers the appointment request" />
      <Arrow />
      <Step n={7} href="/records?tab=history" icon={<History aria-hidden="true" className={ic} />} title="Track each eye over time" body="Score history, re-screening reminder, appointments" />
    </ol>
  );
}

"use client";

// The assistant (DECISION-078). Every reply shows where it came from: the numbered sources
// it used, and a label when it was an urgent-care reply, a refusal, outside its sources, or
// a draft the safety check withheld. The server makes all of those decisions; this file
// only shows them.

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, BookOpen, Bot, Send, Square, Volume2 } from "lucide-react";
import { getJson, problemText, sendJson } from "@/lib/api";
import { useI18n, type Key } from "@/lib/i18n";
import type { AssistantStatus, ChatReply } from "@/lib/types";

type Msg = { role: "user"; text: string } | { role: "assistant"; reply: ChatReply } | { role: "error"; text: string };

const SUGGEST: Record<"en" | "ur", { result: string[]; general: string[] }> = {
  en: {
    result: ["What does my result mean?", "Why are the grade and referral separate?", "What does the heatmap show?", "What should I do next?"],
    general: ["What is diabetic retinopathy?", "How often should I be screened?", "What happens at a screening appointment?", "How accurate is this app?"],
  },
  ur: {
    result: ["میرے نتیجے کا کیا مطلب ہے؟", "مجھے آگے کیا کرنا چاہیے؟"],
    general: ["ذیابیطس ریٹینوپیتھی کیا ہے؟", "مجھے کتنی بار اسکریننگ کروانی چاہیے؟"],
  },
};

const OUTCOME_LABEL: Partial<Record<ChatReply["outcome"], Key>> = {
  urgent: "chat.urgent",
  refused: "chat.refused",
  out_of_scope: "chat.out_of_scope",
  blocked: "chat.blocked",
  error: "chat.error",
};

function speak(text: string, lang: "en" | "ur", onEnd: () => void): boolean {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/\[(S\d+|R)\]/g, ""));
  u.lang = lang === "ur" ? "ur-PK" : "en-GB";
  u.rate = 0.95;
  u.onend = onEnd;
  u.onerror = onEnd;
  window.speechSynthesis.speak(u);
  return true;
}

// [S1] / [R] markers become small labelled chips so the citation is visible but quiet.
function Answer({ text }: { text: string }) {
  const parts = text.split(/(\[(?:S\d+|R)\])/g);
  return (
    <>
      {text.split(/\n{2,}/).length > 1
        ? text.split(/\n{2,}/).map((para, i) => (
            <p key={i} className={i ? "mt-2" : ""}>
              <Answer text={para} />
            </p>
          ))
        : parts.map((p, i) =>
            /^\[(S\d+|R)\]$/.test(p) ? (
              <span key={i} className="ltr mx-0.5 rounded bg-raised px-1 text-[0.75rem] font-bold text-ink-2">
                {p.slice(1, -1)}
              </span>
            ) : (
              <span key={i}>{p}</span>
            ),
          )}
    </>
  );
}

export function AssistantPanel({
  resultId,
  screeningId,
  onDownloadReport,
  general = false,
}: {
  resultId?: string;
  screeningId?: string;
  onDownloadReport?: () => void;
  general?: boolean;
}) {
  const { t, lang } = useI18n();
  const router = useRouter();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<AssistantStatus | null>(null);
  const [speaking, setSpeaking] = useState<number | null>(null);
  const end = useRef<HTMLDivElement>(null);
  const hasContext = Boolean(resultId || screeningId);

  useEffect(() => {
    getJson<AssistantStatus>("/assistant/status").then((r) => r.kind === "ok" && setStatus(r.data));
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    };
  }, []);

  useEffect(() => {
    end.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [msgs, busy]);

  // A different screening is a different conversation.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reset when the context changes
    setMsgs([]);
  }, [resultId, screeningId]);

  const ask = async (q: string) => {
    const question = q.trim();
    if (!question || busy) return;
    const history = msgs
      .filter((m): m is Exclude<Msg, { role: "error" }> => m.role !== "error")
      .slice(-6)
      .map((m) => (m.role === "user" ? { role: "user", text: m.text } : { role: "assistant", text: m.reply.answer }));
    setMsgs((m) => [...m, { role: "user", text: question }]);
    setText("");
    setBusy(true);
    const r = await sendJson<ChatReply>("/assistant/chat", {
      message: question,
      result_id: resultId ?? null,
      screening_id: screeningId ?? null,
      history,
      lang,
    });
    setBusy(false);
    setMsgs((m) => [...m, r.kind === "ok" ? { role: "assistant", reply: r.data } : { role: "error", text: problemText(r) }]);
  };

  const act = (a: ChatReply["actions"][number]) => {
    if (a.type === "find_specialist") {
      const q = new URLSearchParams();
      if (a.city) q.set("city", a.city);
      if (screeningId) q.set("screening", screeningId);
      router.push(`/specialists${q.toString() ? `?${q}` : ""}`);
    } else if (a.type === "download_report") onDownloadReport?.();
    else if (a.type === "new_screening") router.push("/screen");
    else router.push("/records");
  };

  const actionLabel = (a: ChatReply["actions"][number]) =>
    a.type === "find_specialist"
      ? a.city
        ? `${t("chat.find_in")} ${a.city}`
        : t("chat.find_specialist")
      : t(`chat.${a.type}` as Key);

  const suggestions = SUGGEST[lang][hasContext && !general ? "result" : "general"];

  return (
    <section aria-labelledby="assistant-h" className="card flex flex-col p-5 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Bot aria-hidden="true" className="h-5 w-5 text-accent" />
          <h2 id="assistant-h" className="text-base font-bold">{t("chat.title")}</h2>
        </div>
        {status && (
          <span className="rounded-full border border-rule px-2.5 py-0.5 text-[0.75rem] text-ink-2" title={status.label}>
            {status.mode === "llm" ? `${t("chat.mode_llm")}: ${status.label}` : t("chat.mode_offline")}
          </span>
        )}
      </div>
      <p className="mt-2 max-w-[70ch] text-[0.95rem] leading-snug text-ink-2">
        {hasContext ? t("chat.lead") : t("chat.lead_general")}
      </p>

      <div className="mt-4 max-h-[28rem] space-y-4 overflow-y-auto pe-1" aria-live="polite">
        {msgs.length === 0 && (
          <div>
            <p className="text-[0.85rem] text-ink-2">{t("chat.suggest")}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {suggestions.map((s) => (
                <button key={s} type="button" onClick={() => ask(s)} className="rounded-full border border-rule px-3 py-1 text-[0.9rem] hover:border-ink-2 hover:bg-raised">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {msgs.map((m, i) =>
          m.role === "user" ? (
            <div key={i} className="ms-auto max-w-[85%] rounded-2xl rounded-ee-sm bg-brand px-4 py-2 text-white leading-snug">
              {m.text}
            </div>
          ) : m.role === "error" ? (
            <p key={i} role="alert" className="alert text-[0.95rem]">
              {m.text}
            </p>
          ) : (
            <div key={i} className="max-w-[92%]">
              {OUTCOME_LABEL[m.reply.outcome] && (
                <p
                  className={`mb-1 inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[0.75rem] font-bold ${
                    m.reply.outcome === "urgent" ? "bg-rose text-white" : "border border-rule text-ink-2"
                  }`}
                >
                  {m.reply.outcome === "urgent" && <AlertTriangle aria-hidden="true" className="h-3.5 w-3.5" />}
                  {t(OUTCOME_LABEL[m.reply.outcome]!)}
                </p>
              )}
              <div
                className={`rounded-2xl rounded-es-sm px-4 py-3 leading-relaxed ${
                  m.reply.outcome === "urgent" ? "notice-urgent text-lg font-bold" : "border border-rule bg-paper"
                }`}
                dir={m.reply.lang === "ur" ? "rtl" : "ltr"}
              >
                <Answer text={m.reply.answer} />
              </div>

              {m.reply.note && <p className="mt-1 text-[0.8rem] leading-snug text-ink-2">{m.reply.note}</p>}

              {m.reply.sources.length > 0 && (
                <details className="mt-2 text-[0.85rem]">
                  <summary className="inline-flex cursor-pointer items-center gap-1.5 text-ink-2 hover:text-ink">
                    <BookOpen aria-hidden="true" className="h-3.5 w-3.5" />
                    {t("chat.sources")} ({m.reply.sources.length})
                  </summary>
                  {m.reply.searched_as && (
                    <p className="mt-2 text-ink-2" dir="ltr">
                      Searched as: <span className="italic">{m.reply.searched_as}</span>
                    </p>
                  )}
                  <ul className="mt-2 space-y-1.5 border-s-2 border-rule ps-3" dir="ltr">
                    {m.reply.sources.map((s) => (
                      <li key={s.id} className={m.reply.cited.includes(s.id) ? "" : "opacity-70"}>
                        <span className="me-1.5 rounded bg-raised px-1 font-bold">{s.id}</span>
                        {s.kind === "result" ? (
                          t("chat.your_result")
                        ) : s.url.startsWith("/") ? (
                          <Link href={s.url} className="underline underline-offset-2">{s.title}</Link>
                        ) : (
                          <a href={s.url} target="_blank" rel="noreferrer" className="underline underline-offset-2">{s.title}</a>
                        )}
                        {s.heading && <span className="text-ink-2"> — {s.heading}</span>}
                      </li>
                    ))}
                  </ul>
                </details>
              )}

              <div className="mt-2 flex flex-wrap gap-2">
                {m.reply.actions
                  .filter((a) => a.type !== "download_report" || onDownloadReport)
                  .map((a, j) => (
                    <button key={j} type="button" onClick={() => act(a)} className="btn-ghost px-3 py-1 text-[0.9rem]">
                      {actionLabel(a)}
                    </button>
                  ))}
                <button
                  type="button"
                  className="inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-[0.85rem] text-ink-2 hover:bg-raised hover:text-ink"
                  onClick={() => {
                    if (speaking === i) {
                      window.speechSynthesis.cancel();
                      setSpeaking(null);
                    } else if (speak(m.reply.answer, m.reply.lang, () => setSpeaking(null))) setSpeaking(i);
                  }}
                >
                  {speaking === i ? <Square aria-hidden="true" className="h-3.5 w-3.5" /> : <Volume2 aria-hidden="true" className="h-3.5 w-3.5" />}
                  {speaking === i ? t("chat.stop") : t("chat.read_aloud")}
                </button>
              </div>
            </div>
          ),
        )}
        {busy && (
          <p className="text-[0.9rem] text-ink-2" role="status">
            {t("chat.thinking")}
          </p>
        )}
        <div ref={end} />
      </div>

      <form
        className="mt-4 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          ask(text);
        }}
      >
        <label htmlFor="chat-input" className="sr-only">{t("chat.placeholder")}</label>
        <input
          id="chat-input"
          className="field"
          maxLength={1000}
          placeholder={t("chat.placeholder")}
          value={text}
          onChange={(e) => setText(e.target.value)}
          autoComplete="off"
        />
        <button type="submit" className="btn-primary shrink-0" disabled={busy || !text.trim()}>
          <Send aria-hidden="true" className="h-4 w-4" />
          {t("chat.send")}
        </button>
      </form>
      <p className="mt-3 text-[0.8rem] leading-snug text-ink-2">{t("chat.footer")}</p>
    </section>
  );
}

"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, Download, FileText, Save } from "lucide-react";
import { downloadReport } from "@/lib/report";
import { useI18n } from "@/lib/i18n";
import { saveScreening, type Eye, type SavedScreening } from "@/lib/store";

// Save the result under the signed-in account and/or download it as a PDF. `draft` is the
// record that would be saved; the PDF is built from the same record whether or not it is.
// Saving sends only the server-side result id — the server stores what the model returned.
export function ReportActions({
  draft,
  saved,
  onSaved,
}: {
  draft: SavedScreening;
  saved: boolean;
  onSaved?: (rec: SavedScreening) => void;
}) {
  const { t } = useI18n();
  const r = draft.result;
  const warned = r.guard.status !== "ok" || r.quality?.status === "poor_capture_quality";
  const [label, setLabel] = useState(draft.label);
  const [eye, setEye] = useState<Eye>(draft.eye);
  // Ticked by default when the result was flagged or warned: those are the cases a
  // specialist's look adds most to. The patient can untick it.
  const [review, setReview] = useState(r.referable || warned);
  const [busy, setBusy] = useState<"save" | "pdf" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const current: SavedScreening = { ...draft, label: label.trim(), eye };

  const save = async () => {
    if (!r.result_id) {
      setError("This result cannot be saved because it was graded without signing in. Sign in and screen the photograph again.");
      return;
    }
    setBusy("save");
    setError(null);
    try {
      const rec = await saveScreening(r.result_id, { eye, label: label.trim(), requestReview: review });
      onSaved?.(rec);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  };

  const pdf = async () => {
    setBusy("pdf");
    setError(null);
    try {
      await downloadReport(current);
    } catch (e) {
      setError(`The PDF could not be created: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(null);
    }
  };

  return (
    <section aria-labelledby="report" className="card p-5 sm:p-6">
      <div className="flex items-center gap-2">
        <FileText aria-hidden="true" className="h-5 w-5 text-accent" />
        <h2 id="report" className="text-base font-bold">
          {t("screen.save_title")}
        </h2>
      </div>

      {!saved && (
        <>
          <div className="mt-4 grid gap-4 sm:grid-cols-[1fr_auto]">
            <div>
              <label htmlFor="rec-label" className="label">
                {t("screen.label")} <span className="font-normal text-ink-2">{t("auth.optional")}</span>
              </label>
              <input
                id="rec-label"
                className="field"
                maxLength={60}
                value={label}
                placeholder="e.g. Camera at clinic visit, March"
                onChange={(e) => setLabel(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="rec-eye" className="label">
                {t("screen.eye")}
              </label>
              <select id="rec-eye" className="field" value={eye} onChange={(e) => setEye(e.target.value as Eye)}>
                <option value="unspecified">{t("screen.eye_unspecified")}</option>
                <option value="left">{t("screen.eye_left")}</option>
                <option value="right">{t("screen.eye_right")}</option>
              </select>
            </div>
          </div>
          <label className="mt-4 flex items-start gap-3">
            <input type="checkbox" className="mt-1.5 h-4 w-4 accent-[var(--color-sev-4)]" checked={review} onChange={(e) => setReview(e.target.checked)} />
            <span>
              <span className="font-bold">{t("screen.ask_review")}</span>
              <span className="block text-[0.9rem] leading-snug text-ink-2">{t("screen.ask_review_hint")}</span>
            </span>
          </label>
        </>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        {saved ? (
          <p className="inline-flex items-center gap-2 text-[0.95rem]">
            <Check aria-hidden="true" className="h-4 w-4" />
            {t("screen.saved")}{" "}
            <Link href="/records" className="underline underline-offset-4">
              {t("nav.records")}
            </Link>
          </p>
        ) : (
          <button type="button" className="btn-primary" onClick={save} disabled={busy !== null}>
            <Save aria-hidden="true" className="h-4 w-4" />
            {busy === "save" ? t("screen.saving") : t("screen.save")}
          </button>
        )}
        <button type="button" className="btn-ghost" onClick={pdf} disabled={busy !== null}>
          <Download aria-hidden="true" className="h-4 w-4" />
          {busy === "pdf" ? t("screen.pdf_busy") : t("screen.pdf")}
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-[0.95rem]">
          {error}
        </p>
      )}
      <p className="mt-4 text-[0.85rem] leading-snug text-ink-2">{t("screen.store_note")}</p>
    </section>
  );
}

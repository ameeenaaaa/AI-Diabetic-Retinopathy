"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, X } from "lucide-react";
import type { Specialist } from "@/lib/specialists";
import { createAppointment, listScreenings, useRecords, type Slot } from "@/lib/store";
import { useAuth } from "@/lib/auth";

function todayIso(): string {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
}

export function AppointmentForm({
  specialist,
  screeningId,
  onClose,
}: {
  specialist: Specialist;
  screeningId: string | null;
  onClose: () => void;
}) {
  const screenings = useRecords(listScreenings);
  const { user } = useAuth();
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState<Slot>("morning");
  const [linked, setLinked] = useState<string>(screeningId ?? "");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim()) return setError("Enter the name the appointment is for.");
    if (!/^[+\d][\d\s-]{6,}$/.test(phone.trim())) return setError("Enter a phone number the clinic can call back on.");
    if (!date) return setError("Choose a preferred date.");
    if (date < todayIso()) return setError("The preferred date is in the past. Choose today or later.");
    setBusy(true);
    try {
      await createAppointment({
        specialist_id: specialist.id,
        screening_id: linked || null,
        patient_name: name.trim(),
        phone: phone.trim(),
        preferred_date: date,
        slot,
        notes: notes.trim(),
      });
      setDone(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="appt-title"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6"
      onKeyDown={(e) => e.key === "Escape" && onClose()}
    >
      <div className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-t-2xl border border-rule bg-sheet p-5 sm:rounded-2xl sm:p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h2 id="appt-title" className="text-xl font-bold">
              Request an appointment
            </h2>
            <p className="mt-0.5 text-ink-2">
              {specialist.clinic} · {specialist.city}
            </p>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-ink-2 hover:bg-raised hover:text-ink">
            <X className="h-5 w-5" />
          </button>
        </div>

        {done ? (
          <div className="mt-6">
            <p className="inline-flex items-center gap-2 text-lg font-bold">
              <Check aria-hidden="true" className="h-5 w-5" /> Request sent
            </p>
            <p className="mt-2 leading-snug">
              The clinic&apos;s specialist sees it in their appointment list and can confirm a time
              or decline it. You can follow its status under My records. If you attached a
              screening, the specialist can open it.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link href="/records?tab=appointments" className="btn-primary">
                Track my appointments
              </Link>
              <button type="button" onClick={onClose} className="btn-ghost">
                Back to the directory
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="mt-5 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="appt-name">Name</label>
                <input id="appt-name" className="field" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="appt-phone">Phone</label>
                <input id="appt-phone" className="field" type="tel" autoComplete="tel" placeholder="+92 3xx xxxxxxx" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="appt-date">Preferred date</label>
                <input id="appt-date" className="field" type="date" min={todayIso()} value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="appt-slot">Preferred time</label>
                <select id="appt-slot" className="field" value={slot} onChange={(e) => setSlot(e.target.value as Slot)}>
                  <option value="morning">Morning</option>
                  <option value="afternoon">Afternoon</option>
                  <option value="evening">Evening</option>
                </select>
              </div>
            </div>

            <div>
              <label className="label" htmlFor="appt-screening">Attach a saved screening <span className="font-normal text-ink-2">(optional)</span></label>
              <select id="appt-screening" className="field" value={linked} onChange={(e) => setLinked(e.target.value)}>
                <option value="">None</option>
                {screenings.kind === "ok" &&
                  screenings.data.map((s) => (
                    <option key={s.id} value={s.id}>
                      {new Date(s.createdAt).toLocaleDateString("en-GB")} — {s.result.grade_name}, {s.result.referable ? "Refer" : "Not flagged"}
                      {s.label ? ` — ${s.label}` : ""}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="label" htmlFor="appt-notes">Notes for the clinic <span className="font-normal text-ink-2">(optional)</span></label>
              <textarea id="appt-notes" rows={3} className="field" maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            {error && <p role="alert" className="alert">{error}</p>}

            <p className="text-[0.85rem] leading-snug text-ink-2">
              The request goes to this clinic&apos;s specialist account in the app. Demo clinics
              are invented, so nothing reaches a real clinic.
            </p>
            <div className="flex flex-wrap gap-3">
              <button type="submit" className="btn-primary" disabled={busy}>
                {busy ? "Sending…" : "Send appointment request"}
              </button>
              <button type="button" onClick={onClose} className="btn-ghost">
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

import Link from "next/link";
import { CalendarCheck, Stethoscope } from "lucide-react";
import type { Guidance } from "@/lib/guidance";

export function ReferralGuidance({ g, specialistHref }: { g: Guidance; specialistHref: string }) {
  return (
    <section aria-labelledby="guidance" className="card p-5 sm:p-6">
      <div className="flex items-center gap-2 text-ink-2">
        <Stethoscope aria-hidden="true" className="h-5 w-5 text-warm" />
        <h2 id="guidance" className="text-base font-bold text-ink">
          Referral guidance
        </h2>
      </div>
      <p className="mt-3 text-xl font-bold leading-snug">{g.heading}</p>
      <p className="mt-2 max-w-[68ch] leading-snug">{g.summary}</p>

      <ol className="mt-4 max-w-[68ch] list-decimal space-y-1.5 pl-5 leading-snug">
        {g.steps.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ol>

      {g.framingNote && (
        <p className="mt-4 max-w-[68ch] border-l-4 border-amber pl-4 leading-snug">{g.framingNote}</p>
      )}
      {g.qualityNote && (
        <p className="mt-4 max-w-[68ch] border-l-4 border-amber pl-4 leading-snug">{g.qualityNote}</p>
      )}

      <p className="mt-4 max-w-[68ch] rounded-lg bg-raised px-4 py-3 text-[0.95rem] leading-snug">
        <strong>Urgent symptoms. </strong>
        {g.urgent}
      </p>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <Link href={specialistHref} className="btn-primary">
          <CalendarCheck aria-hidden="true" className="h-4 w-4" />
          Find an eye specialist
        </Link>
        <span className="text-[0.95rem] text-ink-2">{g.specialistHint}</span>
      </div>
    </section>
  );
}

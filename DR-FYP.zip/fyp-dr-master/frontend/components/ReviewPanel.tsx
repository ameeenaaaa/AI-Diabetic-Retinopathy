"use client";

import { ClipboardCheck, Clock, UserCheck } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import type { Review } from "@/lib/types";

export function ReviewBadge({ review }: { review?: Review }) {
  const { t } = useI18n();
  if (!review || review.status === "not_requested") return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-rule px-2.5 py-0.5 text-[0.8rem] text-ink-2">
      {review.status === "pending" ? <Clock aria-hidden="true" className="h-3.5 w-3.5" /> : <UserCheck aria-hidden="true" className="h-3.5 w-3.5" />}
      {review.status === "pending"
        ? t("review.pending")
        : review.agrees
          ? t("review.reviewed")
          : `${t("review.reviewed")}: ${review.grade_name}, ${review.refer ? "Refer" : "Not flagged"}`}
    </span>
  );
}

// The specialist's reading, shown BESIDE the model's — the model's answer is never edited.
export function ReviewPanel({ review, onRequest }: { review?: Review; onRequest?: () => void }) {
  const { t, lang } = useI18n();
  if (!review) return null;
  return (
    <section aria-labelledby="review-h" className="card p-5">
      <div className="flex items-center gap-2">
        <ClipboardCheck aria-hidden="true" className="h-5 w-5 text-accent" />
        <h2 id="review-h" className="text-base font-bold">{t("review.title")}</h2>
      </div>
      {review.status === "not_requested" && (
        <div className="mt-3">
          <p className="text-ink-2">{t("review.not_requested")}.</p>
          {onRequest && (
            <button type="button" className="btn-ghost mt-3" onClick={onRequest}>
              {t("review.request")}
            </button>
          )}
        </div>
      )}
      {review.status === "pending" && <p className="mt-3">{t("review.pending")}.</p>}
      {review.status === "reviewed" && (
        <div className="mt-3 space-y-2">
          {review.agrees ? (
            <p className="text-lg font-bold">{t("review.agreed")}</p>
          ) : (
            <>
              <p className="text-ink-2">{t("review.corrected")}:</p>
              <dl className="grid max-w-md grid-cols-2 gap-4">
                <div>
                  <dt className="text-[0.9rem] text-ink-2">Grade</dt>
                  <dd className="text-2xl font-bold">{review.grade_name}</dd>
                </div>
                <div>
                  <dt className="text-[0.9rem] text-ink-2">Referral</dt>
                  <dd className="text-2xl font-bold">{review.refer ? "Refer" : "Not flagged"}</dd>
                </div>
              </dl>
            </>
          )}
          {review.note && <p className="border-s-4 border-rule ps-3 leading-snug">{review.note}</p>}
          <p className="text-[0.85rem] text-ink-2">
            {t("review.by")} {review.reviewer_name}
            {review.reviewed_at && ` · ${new Date(review.reviewed_at).toLocaleDateString(lang === "ur" ? "ur-PK" : "en-GB")}`}
          </p>
          <p className="text-[0.85rem] text-ink-2">{t("review.model_kept")}</p>
        </div>
      )}
    </section>
  );
}

"use client";

import { useI18n, type Key } from "@/lib/i18n";
import type { AppointmentStatus } from "@/lib/store";

export function StatusPill({ status }: { status: AppointmentStatus }) {
  const { t } = useI18n();
  return (
    <span className={`rounded-full border px-3 py-0.5 text-[0.85rem] ${status === "confirmed" ? "border-emerald/40 bg-emerald/10 font-bold text-emerald" : status === "requested" ? "border-blue/30 bg-blue-soft text-blue" : status === "declined" ? "border-rose/30 bg-rose-soft text-rose" : "border-rule text-ink-2"}`}>
      {t(`appt.${status}` as Key)}
    </span>
  );
}

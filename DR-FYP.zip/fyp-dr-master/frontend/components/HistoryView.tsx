"use client";

// How each eye's score has changed across saved screenings (DECISION-078).
//
// One chart per eye: score on the y axis, screenings oldest -> newest on the x axis. The
// grade ranges are drawn as bands in the single-hue severity scale (no traffic lights, per
// the colour rule) and the referral threshold as a dashed line, so a point reads as a
// position on the same scale the result page uses. Every point has a hover title, and the
// same numbers are available as a table.
//
// "Worsened" is stated only when the score went UP and the reading moved to a higher grade
// or to Refer. A score wobbling within one grade is not reported as a change: the model is
// not precise enough for that to mean anything.

import { useState } from "react";
import { AlertTriangle, CalendarClock } from "lucide-react";
import { useI18n, type Key } from "@/lib/i18n";
import type { Eye, SavedScreening } from "@/lib/store";

const EYES: Eye[] = ["right", "left", "unspecified"];
const BAND = ["var(--color-sev-0)", "var(--color-sev-1)", "var(--color-sev-2)", "var(--color-sev-3)", "var(--color-sev-4)"];
const NAMES = ["No DR", "Mild", "Moderate", "Severe", "Proliferative"];

export function worsened(prev: SavedScreening, last: SavedScreening): boolean {
  const a = prev.result;
  const b = last.result;
  return b.score > a.score && (b.grade > a.grade || (b.referable && !a.referable));
}

export function nextDue(items: SavedScreening[]): Date | null {
  if (!items.length) return null;
  const latest = items.reduce((m, s) => (s.createdAt > m.createdAt ? s : m));
  const d = new Date(latest.createdAt);
  d.setFullYear(d.getFullYear() + 1);
  return d;
}

function Chart({ items, lang }: { items: SavedScreening[]; lang: "en" | "ur" }) {
  const W = 960;
  const H = 250;
  const pad = { l: 36, r: 110, t: 12, b: 34 };
  const r0 = items[0].result;
  const cuts = r0.cuts;
  const scores = items.map((s) => s.result.score);
  const lo = Math.min(-0.5, ...scores) - 0.1;
  const hi = Math.max(4.3, ...scores) + 0.1;
  const y = (v: number) => pad.t + ((hi - v) / (hi - lo)) * (H - pad.t - pad.b);
  const n = items.length;
  const x = (i: number) => pad.l + (n === 1 ? (W - pad.l - pad.r) / 2 : (i / (n - 1)) * (W - pad.l - pad.r));
  const edges = [lo, ...cuts, hi];
  const loc = lang === "ur" ? "ur-PK" : "en-GB";
  const days = items.map((s) => s.createdAt.slice(0, 10));
  const sameDay = new Set(days).size < days.length;   // add the time when dates repeat
  const fmt = (iso: string) =>
    new Date(iso).toLocaleString(loc, sameDay ? { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", year: "2-digit" });

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full max-w-[960px]" role="img" aria-label="Score over time">
      {edges.slice(0, -1).map((e0, g) => {
        const e1 = edges[g + 1];
        return (
          <g key={g}>
            <rect x={pad.l} y={y(e1)} width={W - pad.l - pad.r} height={y(e0) - y(e1)} fill={BAND[g]} opacity={0.35} />
            <text x={W - pad.r + 8} y={(y(e0) + y(e1)) / 2 + 4} fontSize="12" fill="var(--color-ink-2)">
              {NAMES[g]}
            </text>
          </g>
        );
      })}
      <line x1={pad.l} x2={W - pad.r} y1={y(r0.referral_threshold)} y2={y(r0.referral_threshold)} stroke="var(--color-ink)" strokeWidth={1.5} strokeDasharray="5 4" />
      <text x={W - pad.r - 4} y={y(r0.referral_threshold) - 5} fontSize="11" textAnchor="end" fill="var(--color-ink)">
        Referral threshold {r0.referral_threshold.toFixed(3)}
      </text>
      {[0, 1, 2, 3, 4].map((v) => (
        <text key={v} x={pad.l - 8} y={y(v) + 4} fontSize="11" textAnchor="end" fill="var(--color-ink-2)">
          {v}
        </text>
      ))}
      <polyline fill="none" stroke="var(--color-ink)" strokeWidth={2} points={items.map((s, i) => `${x(i)},${y(s.result.score)}`).join(" ")} />
      {items.map((s, i) => (
        <g key={s.id}>
          <circle cx={x(i)} cy={y(s.result.score)} r={5} fill="var(--color-ink)" stroke="var(--color-paper)" strokeWidth={2}>
            <title>{`${fmt(s.createdAt)} — score ${s.result.score.toFixed(2)}, ${s.result.grade_name}, ${s.result.referable ? "Refer" : "Not flagged"}`}</title>
          </circle>
          {/* a bigger, invisible hit target for the hover title */}
          <circle cx={x(i)} cy={y(s.result.score)} r={12} fill="transparent">
            <title>{`${fmt(s.createdAt)} — score ${s.result.score.toFixed(2)}, ${s.result.grade_name}, ${s.result.referable ? "Refer" : "Not flagged"}`}</title>
          </circle>
          <text x={x(i)} y={H - 12} fontSize="11" textAnchor="middle" fill="var(--color-ink-2)">
            {fmt(s.createdAt)}
          </text>
        </g>
      ))}
    </svg>
  );
}

export function HistoryView({ screenings }: { screenings: SavedScreening[] }) {
  const { t, lang } = useI18n();
  const [table, setTable] = useState(false);
  // "Now" is taken once per mount, so re-renders do not change the overdue verdict.
  const [now] = useState(() => Date.now());
  const byEye = EYES.map((eye) => ({
    eye,
    items: screenings.filter((s) => s.eye === eye).sort((a, b) => a.createdAt.localeCompare(b.createdAt)),
  })).filter((g) => g.items.length);

  const due = nextDue(screenings);
  const latestPerEye = byEye.map((g) => g.items[g.items.length - 1]);
  const referFirst = latestPerEye.some((s) => s.result.referable);
  const overdue = due !== null && due.getTime() < now;
  const fmtLong = (d: Date) => d.toLocaleDateString(lang === "ur" ? "ur-PK" : "en-GB", { day: "numeric", month: "long", year: "numeric" });

  return (
    <div className="space-y-6">
      {due && (
        <div className="card flex items-start gap-3 p-4">
          <CalendarClock aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-warm" />
          <div>
            {referFirst ? (
              <p className="font-bold">{t("history.refer_first")}</p>
            ) : (
              <>
                <p>
                  <span className="font-bold">{t("history.next_due")}: </span>
                  {fmtLong(due)}
                  {overdue && <span className="ms-2 rounded bg-amber px-1.5 py-0.5 text-[0.8rem] font-bold text-white">{t("history.overdue")}</span>}
                </p>
                <p className="mt-0.5 text-[0.9rem] text-ink-2">{t("history.interval_note")}</p>
              </>
            )}
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <p className="max-w-[70ch] text-[0.95rem] text-ink-2">{t("history.lead")}</p>
        <button type="button" className="btn-ghost px-3 py-1 text-[0.9rem]" onClick={() => setTable((v) => !v)}>
          {table ? t("history.chart") : t("history.table")}
        </button>
      </div>

      {byEye.map(({ eye, items }) => {
        const last = items[items.length - 1];
        const prev = items.length > 1 ? items[items.length - 2] : null;
        const worse = prev ? worsened(prev, last) : false;
        const change: Key | null = !prev
          ? null
          : last.result.grade > prev.result.grade
            ? "history.changed_up"
            : last.result.grade < prev.result.grade
              ? "history.changed_down"
              : "history.changed_same";
        return (
          <section key={eye} aria-labelledby={`eye-${eye}`} className="card p-5">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h3 id={`eye-${eye}`} className="text-lg font-bold">{t(`history.eye_${eye}` as Key)}</h3>
              <p className="text-[0.95rem] text-ink-2">
                {t("history.latest")}: <span className="font-bold text-ink">{last.result.grade_name}</span> ·{" "}
                {last.result.referable ? "Refer" : "Not flagged"} · <span className="ltr">{last.result.score.toFixed(2)}</span>
                {change && ` · ${t(change)}`}
              </p>
            </div>
            {worse && (
              <p role="status" className="mt-3 flex gap-2 notice-warn font-bold leading-snug">
                <AlertTriangle aria-hidden="true" className="mt-1 h-5 w-5 shrink-0" />
                {t("history.worsened")}
              </p>
            )}
            <div className="mt-3" dir="ltr">
              {table ? (
                <table className="w-full text-left text-[0.95rem]">
                  <thead className="text-ink-2">
                    <tr>
                      <th className="py-1 font-normal">{t("history.date")}</th>
                      <th className="py-1 font-normal">{t("history.score")}</th>
                      <th className="py-1 font-normal">{t("history.grade")}</th>
                      <th className="py-1 font-normal">{t("history.referral")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((s) => (
                      <tr key={s.id} className="border-t border-rule">
                        <td className="py-1">{new Date(s.createdAt).toLocaleDateString("en-GB")}</td>
                        <td className="py-1">{s.result.score.toFixed(2)}</td>
                        <td className="py-1">{s.result.grade_name}</td>
                        <td className="py-1">{s.result.referable ? "Refer" : "Not flagged"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <Chart items={items} lang={lang} />
              )}
            </div>
            {items.length === 1 && <p className="mt-2 text-[0.9rem] text-ink-2">{t("history.need_two")}</p>}
          </section>
        );
      })}
    </div>
  );
}

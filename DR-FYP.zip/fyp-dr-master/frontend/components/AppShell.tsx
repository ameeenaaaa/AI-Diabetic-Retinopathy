"use client";

// The page frame (DECISION-079).
//
//   signed in   white sidebar with the role's menu, a top bar with the page title,
//               language switch and the user; content on the soft grey page
//   visitor     a top bar with sign-in and create-account, full-width content
//
// The menu decides only what is SHOWN; every route checks the role on the server.

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Bot,
  CalendarCheck,
  ClipboardList,
  FolderHeart,
  Info,
  Languages,
  LayoutDashboard,
  LogOut,
  Menu,
  ScanEye,
  Stethoscope,
  Users,
  X,
  type LucideIcon,
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useI18n, type Key } from "@/lib/i18n";
import type { Role } from "@/lib/types";

type Item = { href: string; key: Key; icon: LucideIcon };

const MENU: Record<Role, Item[]> = {
  patient: [
    { href: "/", key: "nav.home", icon: LayoutDashboard },
    { href: "/screen", key: "nav.screen", icon: ScanEye },
    { href: "/records", key: "nav.records", icon: FolderHeart },
    { href: "/specialists", key: "nav.specialists", icon: Stethoscope },
    { href: "/assistant", key: "nav.assistant", icon: Bot },
    { href: "/about", key: "nav.about", icon: Info },
  ],
  specialist: [
    { href: "/", key: "nav.home", icon: LayoutDashboard },
    { href: "/specialist", key: "nav.review", icon: ClipboardList },
    { href: "/specialist/appointments", key: "nav.appointments", icon: CalendarCheck },
    { href: "/assistant", key: "nav.assistant", icon: Bot },
    { href: "/about", key: "nav.about", icon: Info },
  ],
  admin: [
    { href: "/admin", key: "nav.dashboard", icon: LayoutDashboard },
    { href: "/admin/users", key: "nav.users", icon: Users },
    { href: "/about", key: "nav.about", icon: Info },
  ],
};

export function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <Link href="/" onClick={onClick} className="flex items-center gap-2.5 text-ink">
      <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-indigo text-white shadow-sm shadow-brand/30">
        <ScanEye aria-hidden="true" className="h-5 w-5" />
      </span>
      <span className="ltr leading-tight">
        <span className="block text-[1.05rem] font-bold tracking-tight">Retinopathy Screening</span>
        <span className="block text-[0.72rem] text-ink-2">Diabetic eye care</span>
      </span>
    </Link>
  );
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
}

function LangButton({ compact = false }: { compact?: boolean }) {
  const { t, lang, setLang } = useI18n();
  return (
    <button
      type="button"
      onClick={() => setLang(lang === "en" ? "ur" : "en")}
      className="inline-flex items-center gap-1.5 rounded-xl border border-rule bg-sheet px-3 py-1.5 text-[0.9rem] text-ink-2 hover:border-brand/40 hover:text-brand"
      aria-label={lang === "en" ? "Switch to Urdu" : "Switch to English"}
    >
      <Languages aria-hidden="true" className="h-4 w-4" />
      {!compact && t("nav.language")}
    </button>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { state, user, logout } = useAuth();
  const { t } = useI18n();
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  // eslint-disable-next-line react-hooks/set-state-in-effect -- close the drawer on navigation
  useEffect(() => setOpen(false), [path]);

  const signOut = async () => {
    await logout();
    router.push("/");
  };

  // ---------------------------------------------------------------- visitor
  if (state.kind !== "user" || !user) {
    return (
      <>
        <header className="sticky top-0 z-40 border-b border-rule bg-sheet/90 backdrop-blur">
          <nav aria-label="Primary" className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-8">
            <Logo />
            <div className="flex items-center gap-2">
              <Link href="/about" className="hidden rounded-xl px-3 py-1.5 text-[0.95rem] text-ink-2 hover:text-brand sm:inline">
                {t("nav.about")}
              </Link>
              <LangButton compact />
              {state.kind === "guest" && (
                <>
                  <Link href="/login" className="rounded-xl px-3 py-1.5 text-[0.95rem] font-bold text-ink hover:text-brand">
                    {t("nav.signin")}
                  </Link>
                  <Link href="/register" className="btn-primary hidden px-4 py-1.5 sm:inline-flex">
                    {t("nav.register")}
                  </Link>
                </>
              )}
            </div>
          </nav>
        </header>
        <main id="main" className="mx-auto max-w-6xl px-4 py-8 sm:px-8 sm:py-12">
          {children}
        </main>
        <SiteFooter />
      </>
    );
  }

  // ---------------------------------------------------------------- signed in
  const items = MENU[user.role];
  const active = (href: string) =>
    href === "/"
      ? path === "/"
      : path === href || (path.startsWith(`${href}/`) && !items.some((l) => l.href.length > href.length && path.startsWith(l.href)));
  const current = items.find((i) => active(i.href));

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="px-5 py-5">
        <Logo onClick={() => setOpen(false)} />
      </div>
      <p className="px-6 pb-2 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-ink-2">{t(`role.${user.role}`)}</p>
      <nav aria-label="Primary" className="flex-1 space-y-1 px-3">
        {items.map(({ href, key, icon: Icon }) => {
          const on = active(href);
          return (
            <Link
              key={href}
              href={href}
              aria-current={on ? "page" : undefined}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[0.97rem] transition-colors ${
                on ? "bg-brand font-bold text-white shadow-sm shadow-brand/30" : "text-ink-2 hover:bg-brand-soft hover:text-brand-dark"
              }`}
            >
              <Icon aria-hidden="true" className="h-5 w-5 shrink-0" />
              {t(key)}
            </Link>
          );
        })}
      </nav>
      {user.role !== "admin" && (
      <div className="m-3 rounded-2xl bg-gradient-to-br from-brand to-indigo p-4 text-white">
        <p className="text-[0.9rem] font-bold">{t("shell.help_title")}</p>
        <p className="mt-1 text-[0.8rem] leading-snug text-white/85">{t("shell.help_body")}</p>
        <Link href="/assistant" className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-white/15 px-3 py-1.5 text-[0.85rem] font-bold hover:bg-white/25">
          <Bot aria-hidden="true" className="h-4 w-4" /> {t("nav.assistant")}
        </Link>
      </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[264px_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-screen border-e border-rule bg-sheet lg:block">{sidebar}</aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label={t("nav.menu")}>
          <button type="button" className="absolute inset-0 bg-ink/40" aria-label={t("nav.menu")} onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 start-0 w-72 bg-sheet shadow-xl">{sidebar}</aside>
        </div>
      )}

      <div className="flex min-h-screen min-w-0 flex-col">
        <header className="sticky top-0 z-40 border-b border-rule bg-sheet/90 backdrop-blur">
          <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <button type="button" className="rounded-xl p-2 text-ink-2 hover:bg-brand-soft lg:hidden" aria-label={t("nav.menu")} onClick={() => setOpen(true)}>
                {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
              <p className="truncate text-lg font-bold">{current ? t(current.key) : ""}</p>
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
              <LangButton />
              <div className="hidden items-center gap-2.5 sm:flex">
                <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-accent to-blue text-[0.85rem] font-bold text-white">
                  {initials(user.name)}
                </span>
                <span className="leading-tight">
                  <span className="block max-w-[16ch] truncate text-[0.92rem] font-bold">{user.name}</span>
                  <span className="block text-[0.75rem] text-ink-2">{t(`role.${user.role}`)}</span>
                </span>
              </div>
              <button type="button" onClick={signOut} className="rounded-xl p-2 text-ink-2 hover:bg-rose-soft hover:text-rose" aria-label={t("nav.signout")} title={t("nav.signout")}>
                <LogOut aria-hidden="true" className="h-5 w-5" />
              </button>
            </div>
          </div>
        </header>
        <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-8">
          {children}
        </main>
        <SiteFooter />
      </div>
    </div>
  );
}

function SiteFooter() {
  const { t } = useI18n();
  return (
    <footer className="border-t border-rule bg-sheet">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-[0.85rem] text-ink-2 sm:px-8">
        <span className="ltr">© 2026 Retinopathy Screening · Bahria University</span>
        <span>{t("shell.footer_note")}</span>
      </div>
    </footer>
  );
}

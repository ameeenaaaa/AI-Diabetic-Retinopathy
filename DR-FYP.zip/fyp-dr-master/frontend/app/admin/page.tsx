"use client";

import { useCallback } from "react";
import { RefreshCw } from "lucide-react";
import { RequireRole } from "@/lib/auth";
import { getJson, must } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { useRecords, announce } from "@/lib/store";
import type { Stats } from "@/lib/types";

export default function AdminPage() {
  return (
    <RequireRole roles={["admin"]}>
      <Dashboard />
    </RequireRole>
  );
}

const pct = (n: number, d: number) => (d ? `${Math.round((100 * n) / d)}%` : "—");
const SEV = ["bg-sev-0", "bg-sev-1", "bg-sev-2", "bg-sev-3", "bg-sev-4"];

// Filled tiles, hospital-dashboard style. Colour identifies the metric, never a verdict.
function Tile({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color: string }) {
  return (
    <div className={`relative overflow-hidden rounded-2xl p-4 text-white shadow-sm ${color}`}>
      <div aria-hidden="true" className="absolute -end-5 -top-5 h-20 w-20 rounded-full bg-white/10" />
      <p className="relative text-[0.88rem] text-white/85">{label}</p>
      <p className="relative mt-1 text-3xl font-bold leading-tight">{value}</p>
      {sub && <p className="relative mt-1 text-[0.8rem] text-white/80">{sub}</p>}
    </div>
  );
}

// Horizontal bars: label, bar, count and share. One hue unless a severity is being shown.
function Bars({ rows, total, colors }: { rows: [string, number][]; total: number; colors?: string[] }) {
  const max = Math.max(1, ...rows.map(([, v]) => v));
  return (
    <ul className="space-y-2.5">
      {rows.map(([label, v], i) => (
        <li key={label} className="grid grid-cols-[minmax(0,11rem)_minmax(0,1fr)_5.5rem] items-center gap-3 text-[0.95rem]" title={`${label}: ${v} (${pct(v, total)})`}>
          <span className="truncate">{label}</span>
          <span className="h-3 rounded-full bg-raised">
            <span
              className={`block h-3 rounded-full ${colors?.[i] ?? "bg-brand"}`}
              style={{ width: `${(100 * v) / max}%`, minWidth: v ? "4px" : 0 }}
            />
          </span>
          <span className="text-end tabular-nums text-ink-2">
            {v} · {pct(v, total)}
          </span>
        </li>
      ))}
    </ul>
  );
}

function Panel({ title, children, note }: { title: string; children: React.ReactNode; note?: string }) {
  return (
    <section className="card p-5">
      <h2 className="font-bold">{title}</h2>
      <div className="mt-4">{children}</div>
      {note && <p className="mt-4 text-[0.85rem] leading-snug text-ink-2">{note}</p>}
    </section>
  );
}

function Dashboard() {
  const { t } = useI18n();
  const load = useCallback(() => must(getJson<Stats>("/admin/stats")), []);
  const s = useRecords(load);

  if (s.kind === "loading") return <p className="text-ink-2">…</p>;
  if (s.kind === "error") return <p role="alert">{s.message}</p>;
  const d = s.data;
  const u = d.uploads;
  const sc = d.screenings;
  const declined = u.declined_not_fundus + u.declined_no_retina;
  const weeklyMax = Math.max(1, ...u.weekly);

  return (
    <div dir="ltr">
      <div className="flex flex-wrap items-baseline justify-between gap-4">
        <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("admin.title")}</h1>
        <button type="button" className="btn-ghost" onClick={announce}>
          <RefreshCw aria-hidden="true" className="h-4 w-4" /> Refresh
        </button>
      </div>
      <p className="mt-3 max-w-[70ch] text-lg leading-relaxed text-ink-2">{t("admin.lead")}</p>

      <div className="mt-7 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Tile color="bg-gradient-to-br from-brand to-brand-dark" label="Uploads" value={u.total} sub="every grading request" />
        <Tile color="bg-gradient-to-br from-accent to-[#0b7a70]" label="Graded" value={u.graded} sub={`${pct(u.graded, u.total)} of uploads`} />
        <Tile color="bg-gradient-to-br from-amber to-warm" label="Declined" value={declined} sub="not a fundus photo / no retina" />
        <Tile color="bg-gradient-to-br from-blue to-[#1d4ed8]" label="Referral rate" value={pct(u.referable, u.graded)} sub={`${u.referable} of ${u.graded} graded`} />
        <Tile color="bg-gradient-to-br from-indigo to-sev-4" label="Saved screenings" value={sc.saved} sub={`${sc.review_pending} waiting for review`} />
        <Tile color="bg-gradient-to-br from-rose to-[#be123c]" label="Specialist agreement" value={pct(sc.agreed, sc.reviewed)} sub={sc.reviewed ? `${sc.agreed} of ${sc.reviewed} reviews` : "no reviews yet"} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel
          title="Upload outcomes"
          note="Framing warnings are uploads outside the 61.4%–81.7% retinal coverage of the training images; the model is known to depend on framing. A rising share here is the in-use sign of the generalisation problem reported in the thesis."
        >
          <Bars
            total={u.total}
            rows={[
              ["Graded, framing in range", u.graded - u.framing_warning],
              ["Graded, framing warning", u.framing_warning],
              ["Graded, low image quality", u.poor_quality],
              ["Declined: not a fundus photo", u.declined_not_fundus],
              ["Declined: no retina", u.declined_no_retina],
            ]}
          />
        </Panel>

        <Panel title="Estimated grades of graded uploads" note="Model output on whatever was uploaded — not a prevalence figure and not a performance figure.">
          <Bars total={u.graded} rows={u.grade_names.map((n, i) => [n, u.grades[i]] as [string, number])} colors={SEV} />
        </Panel>

        <Panel title="Uploads per week (last 12 weeks)">
          <div className="flex h-36 items-end gap-1.5" role="img" aria-label={`Uploads per week: ${u.weekly.join(", ")}`}>
            {u.weekly.map((v, i) => (
              <div key={i} className="flex h-full flex-1 flex-col items-center justify-end gap-1" title={`${11 - i === 0 ? "This week" : `${11 - i} week(s) ago`}: ${v}`}>
                <span className="text-[0.7rem] tabular-nums text-ink-2">{v || ""}</span>
                <span className="block w-full max-w-6 rounded-t bg-brand" style={{ height: `${(80 * v) / weeklyMax}%`, minHeight: v ? 4 : 0 }} />
              </div>
            ))}
          </div>
          <div className="mt-1 flex justify-between text-[0.75rem] text-ink-2">
            <span>12 weeks ago</span>
            <span>this week</span>
          </div>
        </Panel>

        <Panel
          title="Model grade vs specialist grade (reviewed cases)"
          note="Rows: the model's grade. Columns: the grade the specialist recorded. Only cases patients chose to send for review, which lean towards flagged and warned images — so this is NOT a validation result."
        >
          {sc.reviewed === 0 ? (
            <p className="text-ink-2">No reviews yet.</p>
          ) : (
            <>
              <table className="w-full text-center text-[0.9rem] tabular-nums">
                <thead>
                  <tr>
                    <th className="p-1 text-left font-normal text-ink-2">model ↓ / specialist →</th>
                    {u.grade_names.map((n) => (
                      <th key={n} className="p-1 font-normal text-ink-2">{n}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {sc.table.map((row, i) => (
                    <tr key={i} className="border-t border-rule">
                      <th className="p-1 text-left font-normal">{u.grade_names[i]}</th>
                      {row.map((v, j) => (
                        <td key={j} className={`p-1 ${i === j ? "font-bold" : ""} ${v ? "" : "text-ink-2/50"}`}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="mt-3 text-[0.9rem]">
                Same referral decision: <span className="font-bold">{pct(sc.referral_agreed, sc.reviewed)}</span> ({sc.referral_agreed} of {sc.reviewed})
              </p>
            </>
          )}
        </Panel>

        <Panel title="Appointment requests">
          <Bars
            total={Object.values(d.appointments).reduce((a, b) => a + b, 0)}
            rows={(["requested", "confirmed", "declined", "completed", "cancelled"] as const).map((k) => [t(`appt.${k}`), d.appointments[k]])}
          />
        </Panel>

        <Panel title="Assistant replies" note="Outcome counts only; the questions themselves are not stored. 'Withheld' is a model draft the output check blocked.">
          <Bars
            total={Object.values(d.assistant).reduce((a, b) => a + b, 0)}
            rows={[
              ["Answered from sources", d.assistant.answered],
              ["Urgent-care reply", d.assistant.urgent],
              ["Refused (dose / diagnosis)", d.assistant.refused],
              ["Not in the sources", d.assistant.out_of_scope],
              ["Withheld by output check", d.assistant.blocked],
              ["Model unavailable", d.assistant.error],
            ]}
          />
        </Panel>
      </div>

      <p className="mt-6 text-[0.85rem] text-ink-2">
        Accounts: {d.users.patient} patients · {d.users.specialist} specialists · {d.users.admin} administrators · generated{" "}
        {new Date(d.generated_at).toLocaleString("en-GB")}
      </p>
    </div>
  );
}

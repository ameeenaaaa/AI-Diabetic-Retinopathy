"use client";

import { useCallback, useState } from "react";
import { RequireRole } from "@/lib/auth";
import { anyArray, getJson, must, problemText, sendJson } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { announce, useRecords } from "@/lib/store";
import type { User } from "@/lib/types";

export default function AdminUsersPage() {
  return (
    <RequireRole roles={["admin"]}>
      <Users />
    </RequireRole>
  );
}

function Users() {
  const { t } = useI18n();
  const load = useCallback(() => must(getJson<User[]>("/admin/users", anyArray)), []);
  const users = useRecords(load);
  const [error, setError] = useState<string | null>(null);

  const toggle = async (u: User) => {
    setError(null);
    const r = await sendJson(`/admin/users/${u.id}`, { active: !u.active }, "PATCH");
    if (r.kind !== "ok") setError(problemText(r));
    announce();
  };

  return (
    <div dir="ltr">
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("admin.users_title")}</h1>
      <div className="mt-7 grid gap-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] lg:items-start">
        <section>
          {error && <p role="alert" className="mb-3 alert">{error}</p>}
          {users.kind === "loading" ? (
            <p className="text-ink-2">…</p>
          ) : users.kind === "error" ? (
            <p role="alert">{users.message}</p>
          ) : (
            <div className="card overflow-x-auto">
              <table className="w-full text-left text-[0.95rem]">
                <thead className="text-ink-2">
                  <tr>
                    <th className="p-3 font-normal">Name</th>
                    <th className="p-3 font-normal">Role</th>
                    <th className="p-3 font-normal">Email</th>
                    <th className="p-3 font-normal"></th>
                  </tr>
                </thead>
                <tbody>
                  {users.data.map((u) => (
                    <tr key={u.id} className={`border-t border-rule ${u.active ? "" : "opacity-60"}`}>
                      <td className="p-3">
                        <span className="font-bold">{u.name}</span>
                        {u.clinic && <span className="block text-[0.85rem] text-ink-2">{u.clinic}</span>}
                      </td>
                      <td className="p-3">{t(`role.${u.role}`)}</td>
                      <td className="p-3 text-ink-2">{u.email}</td>
                      <td className="p-3 text-end">
                        <button type="button" className="btn-ghost px-3 py-1 text-[0.85rem]" onClick={() => toggle(u)}>
                          {u.active ? t("admin.switch_off") : t("admin.switch_on")}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <NewSpecialist />
      </div>
    </div>
  );
}

const SPECIALTIES = ["Vitreoretinal specialist", "Ophthalmologist", "Diabetic eye screening"];

function NewSpecialist() {
  const { t } = useI18n();
  const blank = { name: "", email: "", password: "", clinic: "", city: "", area: "", days: "Mon–Fri", services: "" };
  const [f, setF] = useState(blank);
  const [specs, setSpecs] = useState<string[]>(["Ophthalmologist"]);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof blank) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const r = await sendJson("/admin/specialists", {
      ...f,
      specialties: specs,
      services: f.services.split(",").map((x) => x.trim()).filter(Boolean),
      languages: ["Urdu", "English"],
    });
    setBusy(false);
    if (r.kind === "ok") {
      setMsg(`Created. ${f.name} can now sign in with ${f.email}.`);
      setF(blank);
      announce();
    } else setMsg(problemText(r));
  };

  return (
    <form onSubmit={submit} className="card space-y-3 p-5" noValidate>
      <h2 className="font-bold">{t("admin.new_specialist")}</h2>
      <p className="text-[0.9rem] text-ink-2">Creates the specialist&apos;s account and their clinic in the directory, so patients can send it appointment requests.</p>
      {(
        [
          ["name", "Name"],
          ["email", "Email"],
          ["password", "Temporary password"],
          ["clinic", "Clinic"],
          ["city", "City"],
          ["area", "Area"],
          ["days", "Days open"],
          ["services", "Services (comma-separated)"],
        ] as const
      ).map(([k, label]) => (
        <div key={k}>
          <label className="label" htmlFor={`ns-${k}`}>{label}</label>
          <input id={`ns-${k}`} className="field" type={k === "password" ? "password" : k === "email" ? "email" : "text"} value={f[k]} onChange={set(k)} />
        </div>
      ))}
      <fieldset>
        <legend className="label">Specialties</legend>
        {SPECIALTIES.map((s) => (
          <label key={s} className="flex items-center gap-2">
            <input type="checkbox" className="h-4 w-4 accent-[var(--color-sev-4)]" checked={specs.includes(s)} onChange={(e) => setSpecs(e.target.checked ? [...specs, s] : specs.filter((x) => x !== s))} />
            {s}
          </label>
        ))}
      </fieldset>
      {msg && <p role="status" className="rounded-lg bg-raised px-4 py-2">{msg}</p>}
      <button type="submit" className="btn-primary" disabled={busy}>{busy ? t("auth.working") : t("admin.create")}</button>
    </form>
  );
}

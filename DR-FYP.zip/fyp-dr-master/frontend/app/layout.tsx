import type { Metadata } from "next";
import { Atkinson_Hyperlegible_Next, Noto_Nastaliq_Urdu } from "next/font/google";
import { AppShell } from "@/components/AppShell";
import { Providers } from "@/components/Providers";
import "./globals.css";

// Designed by the Braille Institute for readers with low vision — the population
// diabetic retinopathy produces. Chosen for that reason, not as a neutral default.
const atkinson = Atkinson_Hyperlegible_Next({
  subsets: ["latin"],
  weight: "variable",
  variable: "--font-atkinson",
  display: "swap",
});

// Nastaliq, the script Urdu readers expect, used only when the page is switched to Urdu.
const nastaliq = Noto_Nastaliq_Urdu({
  subsets: ["arabic"],
  weight: ["400", "700"],
  variable: "--font-nastaliq",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Retinopathy Screening — diabetic eye care",
  description:
    "Estimates a diabetic retinopathy grade from a fundus photograph, gives referral guidance, an assistant that explains the result, specialist review and appointments. Not a medical device.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${atkinson.variable} ${nastaliq.variable}`}>
      <body className="min-h-screen">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-sheet focus:px-3 focus:py-2"
        >
          Skip to content
        </a>
        <Providers>
          <AppShell>{children}</AppShell>
        </Providers>
      </body>
    </html>
  );
}

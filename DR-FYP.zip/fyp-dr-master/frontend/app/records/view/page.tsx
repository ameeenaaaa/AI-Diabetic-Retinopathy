"use client";

import Link from "next/link";
import { Suspense, useCallback, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Trash2 } from "lucide-react";
import { guidanceForGraded } from "@/lib/guidance";
import { deleteScreening, getScreening, requestReview, useRecords } from "@/lib/store";
import { RequireRole } from "@/lib/auth";
import { downloadReport } from "@/lib/report";
import { AssistantPanel } from "@/components/AssistantPanel";
import { ReviewPanel } from "@/components/ReviewPanel";
import { Disclaimer } from "@/components/Disclaimer";
import { GuardNotice, QualityNotice } from "@/components/GuardNotice";
import { ImageViewer } from "@/components/ImageViewer";
import { Provenance } from "@/components/Provenance";
import { Readout } from "@/components/Readout";
import { ReferralGuidance } from "@/components/ReferralGuidance";
import { ReportActions } from "@/components/ReportActions";

export default function SavedScreeningPage() {
  return (
    <RequireRole roles={["patient"]}>
      <Suspense fallback={<p className="text-ink-2">Loading the report…</p>}>
        <SavedScreening />
      </Suspense>
    </RequireRole>
  );
}

const EYE = { left: "Left eye", right: "Right eye", unspecified: "Eye not specified" } as const;

function SavedScreening() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const load = useCallback(() => getScreening(id), [id]);
  const rec = useRecords(load);
  const [asking, setAsking] = useState(false);

  if (rec.kind === "loading") return <p className="text-ink-2">Loading the report…</p>;
  if (rec.kind === "error") return <p role="alert">{rec.message}</p>;
  if (!rec.data) {
    return (
      <div>
        <h1 className="text-3xl font-bold">This screening is not in your records</h1>
        <p className="mt-3 max-w-[60ch] text-ink-2">
          It may have been deleted, or it belongs to a different account.
        </p>
        <Link href="/records" className="btn-primary mt-6">Back to My records</Link>
      </div>
    );
  }

  const s = rec.data;
  const r = s.result;
  const warned = r.guard.status !== "ok";
  const g = guidanceForGraded(r.referable, r.guard, s.meta.reported_val_sens_at_spec95, r.quality);

  return (
    <div>
      <Link href="/records" className="inline-flex items-center gap-1.5 text-ink-2 hover:text-ink">
        <ArrowLeft aria-hidden="true" className="h-4 w-4" /> My records
      </Link>
      <div className="mt-4 flex flex-wrap items-baseline justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold leading-tight sm:text-4xl">Saved screening</h1>
          <p className="mt-1 text-ink-2">
            {new Date(s.createdAt).toLocaleString("en-GB", { dateStyle: "long", timeStyle: "short" })} · {EYE[s.eye]}
            {s.label ? ` · ${s.label}` : ""} · {s.fileName}
          </p>
        </div>
        {asking ? (
          <span className="inline-flex items-center gap-2">
            <button
              type="button"
              className="btn-ghost"
              onClick={async () => {
                await deleteScreening(s.id);
                router.push("/records");
              }}
            >
              Delete this screening
            </button>
            <button type="button" className="text-ink-2 underline underline-offset-4" onClick={() => setAsking(false)}>
              Keep
            </button>
          </span>
        ) : (
          <button type="button" className="btn-ghost" onClick={() => setAsking(true)}>
            <Trash2 aria-hidden="true" className="h-4 w-4" /> Delete
          </button>
        )}
      </div>

      <div className="mt-7 grid gap-10 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:items-start">
        <div className="order-2 lg:order-1">
          <ImageViewer preprocessed={r.preprocessed_png} overlay={r.overlay_png} fileName={s.fileName} />
        </div>
        <div className="order-1 space-y-6 lg:order-2">
          {warned && <GuardNotice guard={r.guard} />}
          <QualityNotice quality={r.quality} />
          <Readout r={r} />
          {!warned && <GuardNotice guard={r.guard} />}
          <ReviewPanel review={s.review} onRequest={() => requestReview(s.id)} />
          <Disclaimer items={r.disclaimer} />
        </div>
      </div>

      <h2 className="mt-12 text-2xl font-bold">Next steps</h2>
      <div className="mt-4 grid gap-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:items-start">
        <ReferralGuidance
          g={g}
          specialistHref={`/specialists?screening=${s.id}${r.referable ? "&referable=1" : ""}`}
        />
        <ReportActions draft={s} saved />
      </div>

      <div className="mt-8">
        <AssistantPanel screeningId={s.id} onDownloadReport={() => downloadReport(s)} />
      </div>

      <Provenance meta={s.meta} />
    </div>
  );
}

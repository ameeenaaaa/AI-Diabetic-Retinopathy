"use client";

import Link from "next/link";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CalendarCheck, Download, FileText, ImagePlus, Trash2 } from "lucide-react";
import { RequireRole } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { downloadReport } from "@/lib/report";
import {
  deleteScreening,
  getScreening,
  listAppointments,
  listScreenings,
  setAppointmentStatus,
  useRecords,
  type Appointment,
  type SavedScreening,
} from "@/lib/store";
import { HistoryView } from "@/components/HistoryView";
import { ReviewBadge } from "@/components/ReviewPanel";
import { StatusPill } from "@/components/StatusPill";

type Tab = "screenings" | "history" | "appointments";
const TABS: Tab[] = ["screenings", "history", "appointments"];

export default function RecordsPage() {
  return (
    <RequireRole roles={["patient"]}>
      <Suspense fallback={<p className="text-ink-2">…</p>}>
        <Records />
      </Suspense>
    </RequireRole>
  );
}

function Records() {
  const { t } = useI18n();
  const params = useSearchParams();
  const router = useRouter();
  const tab: Tab = TABS.includes(params.get("tab") as Tab) ? (params.get("tab") as Tab) : "screenings";
  const screenings = useRecords(listScreenings);
  const appts = useRecords(listAppointments);

  const nS = screenings.kind === "ok" ? screenings.data.length : 0;
  const nA = appts.kind === "ok" ? appts.data.filter((a) => a.status === "requested" || a.status === "confirmed").length : 0;
  const go = (x: Tab) => router.replace(x === "screenings" ? "/records" : `/records?tab=${x}`, { scroll: false });
  const label: Record<Tab, string> = {
    screenings: `${t("records.tab_screenings")} (${nS})`,
    history: t("records.tab_history"),
    appointments: `${t("records.tab_appointments")} (${nA})`,
  };

  return (
    <div>
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("records.title")}</h1>
      <p className="mt-3 max-w-[62ch] text-lg leading-relaxed text-ink-2">{t("records.lead")}</p>

      <div role="tablist" aria-label={t("records.title")} className="mt-7 inline-flex flex-wrap rounded-xl border border-rule bg-sheet p-1">
        {TABS.map((x) => (
          <button
            key={x}
            role="tab"
            type="button"
            aria-selected={tab === x}
            onClick={() => go(x)}
            className={`rounded-lg px-4 py-1.5 text-[0.95rem] ${tab === x ? "bg-brand font-bold text-white shadow-sm" : "text-ink-2 hover:text-brand"}`}
          >
            {label[x]}
          </button>
        ))}
      </div>

      <div className="mt-6" role="tabpanel">
        {tab === "appointments" ? (
          appts.kind === "loading" ? (
            <p className="text-ink-2">…</p>
          ) : appts.kind === "error" ? (
            <p role="alert">{appts.message}</p>
          ) : (
            <AppointmentList items={appts.data} screenings={screenings.kind === "ok" ? screenings.data : []} />
          )
        ) : screenings.kind === "loading" ? (
          <p className="text-ink-2">…</p>
        ) : screenings.kind === "error" ? (
          <p role="alert">{screenings.message}</p>
        ) : tab === "history" ? (
          screenings.data.length ? (
            <HistoryView screenings={screenings.data} />
          ) : (
            <Empty icon={<ImagePlus aria-hidden="true" className="h-8 w-8 text-ink-2" />} text={t("records.empty_screenings")} href="/screen" action={t("home.start")} />
          )
        ) : (
          <ScreeningList items={screenings.data} />
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ screenings
function ScreeningList({ items }: { items: SavedScreening[] }) {
  const { t, lang } = useI18n();
  if (!items.length) {
    return <Empty icon={<ImagePlus aria-hidden="true" className="h-8 w-8 text-ink-2" />} text={t("records.empty_screenings")} href="/screen" action={t("home.start")} />;
  }
  const eyeKey = { left: "history.eye_left", right: "history.eye_right", unspecified: "history.eye_unspecified" } as const;
  return (
    <ul className="space-y-3">
      {items.map((s) => (
        <li key={s.id} className="card flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
          {s.result.preprocessed_png ? (
            /* eslint-disable-next-line @next/next/no-img-element -- stored data URI */
            <img src={s.result.preprocessed_png} alt="" className="h-20 w-20 shrink-0 rounded-lg bg-viewer" />
          ) : (
            <div className="h-20 w-20 shrink-0 rounded-lg bg-viewer" />
          )}
          <div className="min-w-0 flex-1">
            <p className="text-[0.9rem] text-ink-2">
              {new Date(s.createdAt).toLocaleString(lang === "ur" ? "ur-PK" : "en-GB", { dateStyle: "medium", timeStyle: "short" })} · {t(eyeKey[s.eye])}
              {s.label ? ` · ${s.label}` : ""}
            </p>
            <dl className="mt-1 flex flex-wrap gap-x-6 gap-y-1" dir="ltr">
              <div className="flex gap-2">
                <dt className="text-ink-2">Estimated grade</dt>
                <dd className="font-bold">{s.result.grade_name}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="text-ink-2">Referral</dt>
                <dd className="font-bold">{s.result.referable ? "Refer" : "Not flagged"}</dd>
              </div>
            </dl>
            <div className="mt-1.5 flex flex-wrap gap-2">
              <ReviewBadge review={s.review} />
              {s.result.guard.status !== "ok" && <span className="chip-warn">Framing warning</span>}
              {s.result.quality?.status === "poor_capture_quality" && <span className="chip-warn">Low image quality</span>}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link href={`/records/view?id=${s.id}`} className="btn-ghost">
              <FileText aria-hidden="true" className="h-4 w-4" /> {t("records.open")}
            </Link>
            <button
              type="button"
              className="btn-ghost"
              onClick={async () => {
                // The list omits the overlay to stay small; fetch the full record for the PDF.
                const full = await getScreening(s.id);
                if (full) await downloadReport(full);
              }}
            >
              <Download aria-hidden="true" className="h-4 w-4" /> {t("records.pdf")}
            </button>
            <ConfirmDelete onConfirm={() => deleteScreening(s.id)} />
          </div>
        </li>
      ))}
    </ul>
  );
}

// ------------------------------------------------------------------ appointments
const SLOT = { morning: "Morning", afternoon: "Afternoon", evening: "Evening" } as const;

function AppointmentList({ items, screenings }: { items: Appointment[]; screenings: SavedScreening[] }) {
  const { t } = useI18n();
  if (!items.length) {
    return <Empty icon={<CalendarCheck aria-hidden="true" className="h-8 w-8 text-ink-2" />} text={t("records.empty_appts")} href="/specialists" action={t("nav.specialists")} />;
  }
  const open = items.filter((a) => a.status === "requested" || a.status === "confirmed").sort((a, b) => a.preferredDate.localeCompare(b.preferredDate));
  const closed = items.filter((a) => !(a.status === "requested" || a.status === "confirmed"));

  return (
    <div className="space-y-8">
      <section aria-labelledby="open-h">
        <h2 id="open-h" className="text-lg font-bold">{t("records.upcoming")}</h2>
        {open.length ? (
          <ul className="mt-3 space-y-3">{open.map((a) => <AppointmentRow key={a.id} a={a} screenings={screenings} />)}</ul>
        ) : (
          <p className="mt-2 text-ink-2">{t("records.nothing_pending")}</p>
        )}
      </section>
      {closed.length > 0 && (
        <section aria-labelledby="closed-h">
          <h2 id="closed-h" className="text-lg font-bold">{t("records.past")}</h2>
          <ul className="mt-3 space-y-3">{closed.map((a) => <AppointmentRow key={a.id} a={a} screenings={screenings} />)}</ul>
        </section>
      )}
    </div>
  );
}

function AppointmentRow({ a, screenings }: { a: Appointment; screenings: SavedScreening[] }) {
  const { t, lang } = useI18n();
  const [error, setError] = useState<string | null>(null);
  const linked = a.screeningId ? screenings.find((s) => s.id === a.screeningId) : undefined;
  const date = new Date(`${a.preferredDate}T00:00:00`).toLocaleDateString(lang === "ur" ? "ur-PK" : "en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
  const isOpen = a.status === "requested" || a.status === "confirmed";

  return (
    <li className={`card p-4 ${isOpen ? "" : "opacity-75"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-bold">{a.specialistName}</p>
          <p className="text-[0.95rem] text-ink-2">
            {a.city} · {date}, {SLOT[a.slot].toLowerCase()} · {a.patientName}
          </p>
        </div>
        <StatusPill status={a.status} />
      </div>
      {a.notes && <p className="mt-2 text-[0.95rem] leading-snug">{a.notes}</p>}
      {a.specialistNote && (
        <p className="mt-2 rounded-lg bg-raised px-3 py-2 text-[0.95rem] leading-snug">
          <span className="font-bold">{t("records.clinic_note")}: </span>
          {a.specialistNote}
        </p>
      )}
      {a.screeningId && (
        <p className="mt-2 text-[0.9rem] text-ink-2">
          {t("records.attached")}:{" "}
          {linked ? (
            <Link className="underline underline-offset-4 hover:text-ink" href={`/records/view?id=${linked.id}`}>
              {new Date(linked.createdAt).toLocaleDateString("en-GB")} — {linked.result.grade_name}, {linked.result.referable ? "Refer" : "Not flagged"}
            </Link>
          ) : (
            "deleted"
          )}
        </p>
      )}
      {isOpen && (
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            className="btn-ghost"
            onClick={() => setAppointmentStatus(a, "cancelled").catch((e: Error) => setError(e.message))}
          >
            {t("records.cancel")}
          </button>
        </div>
      )}
      {error && <p role="alert" className="mt-2 text-[0.9rem]">{error}</p>}
    </li>
  );
}

// ------------------------------------------------------------------ shared
function ConfirmDelete({ onConfirm }: { onConfirm: () => Promise<void> }) {
  const { t } = useI18n();
  const [asking, setAsking] = useState(false);
  if (!asking) {
    return (
      <button type="button" className="btn-ghost" onClick={() => setAsking(true)} aria-label={t("records.delete")}>
        <Trash2 aria-hidden="true" className="h-4 w-4" />
      </button>
    );
  }
  return (
    <span className="inline-flex items-center gap-2">
      <button type="button" className="btn-ghost" onClick={onConfirm}>{t("records.delete")}</button>
      <button type="button" className="text-[0.95rem] text-ink-2 underline underline-offset-4" onClick={() => setAsking(false)}>{t("records.keep")}</button>
    </span>
  );
}

function Empty({ icon, text, href, action }: { icon: React.ReactNode; text: string; href: string; action: string }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      {icon}
      <p className="mt-3 max-w-[48ch] text-ink-2">{text}</p>
      <Link href={href} className="btn-primary mt-5">{action}</Link>
    </div>
  );
}

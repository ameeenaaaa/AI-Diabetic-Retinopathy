"use client";

import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { HOME_FOR, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { safeNext } from "@/lib/safeNext";

export default function RegisterPage() {
  return (
    <Suspense fallback={null}>
      <Register />
    </Suspense>
  );
}

function Register() {
  const { t } = useI18n();
  const { register, state } = useAuth();
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const [f, setF] = useState({ name: "", email: "", password: "", city: "", phone: "" });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (state.kind === "user") router.replace(next ?? HOME_FOR[state.user.role]);
  }, [state, next, router]);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(await register({ ...f, name: f.name.trim(), email: f.email.trim() }));
    setBusy(false);
  };

  return (
    <div className="mx-auto max-w-xl">
      <h1 className="text-4xl font-bold leading-tight">{t("auth.register_title")}</h1>
      <p className="mt-3 text-lg leading-relaxed text-ink-2">{t("auth.register_lead")}</p>
      <form onSubmit={submit} className="mt-7 space-y-4" noValidate>
        <div>
          <label className="label" htmlFor="name">{t("auth.name")}</label>
          <input id="name" autoComplete="name" className="field" value={f.name} onChange={set("name")} />
        </div>
        <div>
          <label className="label" htmlFor="email">{t("auth.email")}</label>
          <input id="email" type="email" autoComplete="email" className="field ltr" value={f.email} onChange={set("email")} />
        </div>
        <div>
          <label className="label" htmlFor="password">{t("auth.password")}</label>
          <input id="password" type="password" autoComplete="new-password" className="field ltr" aria-describedby="pw-hint" value={f.password} onChange={set("password")} />
          <p id="pw-hint" className="mt-1 text-[0.85rem] text-ink-2">{t("auth.password_hint")}</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="city">{t("auth.city")} <span className="font-normal text-ink-2">{t("auth.optional")}</span></label>
            <input id="city" autoComplete="address-level2" className="field" value={f.city} onChange={set("city")} />
          </div>
          <div>
            <label className="label" htmlFor="phone">{t("auth.phone")} <span className="font-normal text-ink-2">{t("auth.optional")}</span></label>
            <input id="phone" type="tel" autoComplete="tel" className="field ltr" value={f.phone} onChange={set("phone")} />
          </div>
        </div>
        {error && <p role="alert" className="alert">{error}</p>}
        <button type="submit" className="btn-primary" disabled={busy}>
          {busy ? t("auth.working") : t("auth.register_btn")}
        </button>
      </form>
      <p className="mt-6 text-ink-2">
        {t("auth.have_account")}{" "}
        <Link href={`/login${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="text-ink underline underline-offset-4">
          {t("nav.signin")}
        </Link>
      </p>
    </div>
  );
}

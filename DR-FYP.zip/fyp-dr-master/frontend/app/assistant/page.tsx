"use client";

import { useState } from "react";
import { RequireRole, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { listScreenings, useRecords, type SavedScreening } from "@/lib/store";
import { AssistantPanel } from "@/components/AssistantPanel";

export default function AssistantPage() {
  return (
    <RequireRole roles={["patient", "specialist"]}>
      <AssistantView />
    </RequireRole>
  );
}

function AssistantView() {
  const { t } = useI18n();
  const { user } = useAuth();
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("chat.title")}</h1>
      <p className="mt-3 text-lg leading-relaxed text-ink-2">{t("chat.lead_general")}</p>
      {user?.role === "patient" ? <WithScreenings /> : <div className="mt-6"><AssistantPanel general /></div>}
      <HowItWorks />
    </div>
  );
}

function WithScreenings() {
  const { t } = useI18n();
  const screenings = useRecords(listScreenings);
  const [id, setId] = useState("");
  const list: SavedScreening[] = screenings.kind === "ok" ? screenings.data : [];
  return (
    <>
      {list.length > 0 && (
        <div className="mt-6">
          <label htmlFor="pick" className="label">{t("chat.pick_screening")}</label>
          <select id="pick" className="field max-w-md" value={id} onChange={(e) => setId(e.target.value)}>
            <option value="">{t("chat.no_screening")}</option>
            {list.map((s) => (
              <option key={s.id} value={s.id}>
                {new Date(s.createdAt).toLocaleDateString("en-GB")} — {s.result.grade_name}, {s.result.referable ? "Refer" : "Not flagged"}
                {s.label ? ` — ${s.label}` : ""}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="mt-6">
        {id ? <AssistantPanel key={id} screeningId={id} /> : <AssistantPanel general />}
      </div>
    </>
  );
}

// For the panel and for the write-up: what happens to a question, in order.
function HowItWorks() {
  const steps = [
    ["Safety rules first", "Questions about sudden changes in sight get an urgent-care reply at once. Questions about medicine doses, and 'do I have it / am I fine?' questions, get a fixed reply. No language model is involved in any of these."],
    ["Search the sources", "The question is matched against a small set of passages written from NHS and published clinical sources and from this app's own documentation. If nothing matches, the assistant says so instead of guessing."],
    ["Write the answer", "A language model words a short answer from the matched passages and, if you are asking about a result, from that result itself. Without a model, the passages are quoted directly."],
    ["Check the answer", "Before you see it, the draft is checked again. A draft that diagnoses, reassures, gives a percentage of certainty or names a dose is withheld."],
  ];
  return (
    <section aria-labelledby="how-h" className="mt-10">
      <h2 id="how-h" className="text-xl font-bold">How the assistant answers</h2>
      <ol className="mt-4 grid gap-3 sm:grid-cols-2" dir="ltr">
        {steps.map(([h, b], i) => (
          <li key={h} className="card p-4">
            <p className="font-bold">{i + 1}. {h}</p>
            <p className="mt-1 text-[0.95rem] leading-snug text-ink-2">{b}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}

"use client";

import { Suspense, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CalendarPlus, Info, MapPin, Search } from "lucide-react";
import { AppointmentForm } from "@/components/AppointmentForm";
import Link from "next/link";
import { listSpecialists, SPECIALTIES, type Specialist, type Specialty } from "@/lib/specialists";
import { useRecords } from "@/lib/store";
import { useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";

export default function SpecialistsPage() {
  return (
    <Suspense fallback={<p className="text-ink-2">Loading the directory…</p>}>
      <Directory />
    </Suspense>
  );
}

function Directory() {
  const params = useSearchParams();
  const screeningId = params.get("screening");
  const referable = params.get("referable") === "1";

  const { t } = useI18n();
  const { user, state } = useAuth();
  const directory = useRecords(listSpecialists);
  const all = useMemo(() => (directory.kind === "ok" ? directory.data : []), [directory]);
  const cities = useMemo(() => Array.from(new Set(all.map((s) => s.city))), [all]);
  const [q, setQ] = useState("");
  const [city, setCity] = useState(params.get("city") ?? "all");
  const [spec, setSpec] = useState<Specialty | "all">("all");
  const [booking, setBooking] = useState<Specialist | null>(null);

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return all.filter(
      (s) =>
        (city === "all" || s.city === city) &&
        (spec === "all" || s.specialties.includes(spec)) &&
        (!needle ||
          [s.clinic, s.city, s.area, ...s.services, ...s.specialties].some((t) => t.toLowerCase().includes(needle))),
    );
  }, [all, q, city, spec]);

  return (
    <div>
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("nav.specialists")}</h1>
      <p className="mt-3 max-w-[62ch] text-lg leading-relaxed text-ink-2">
        Choose a clinic and send an appointment request. The clinic&apos;s specialist confirms or
        declines it in the app, and you can follow it under My records.
      </p>

      <p className="mt-5 flex max-w-[80ch] gap-3 rounded-xl border border-warm/50 bg-sheet px-4 py-3 text-[0.95rem] leading-snug">
        <Info aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0 text-warm" />
        <span>
          <strong>Demo directory.</strong> Clinics marked Demo are invented for the prototype and
          have no contact details. The administrator can add real clinics; replace the demo ones
          with a verified directory before real use.
        </span>
      </p>

      {referable && (
        <p className="mt-4 max-w-[80ch] rounded-xl border-l-4 border-brand bg-brand-soft px-4 py-3 leading-snug">
          Your screening was flagged for referral. A vitreoretinal (retina) specialist or a general
          ophthalmologist can assess it.
        </p>
      )}

      <div className="mt-6 grid gap-3 sm:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <div className="relative">
          <label htmlFor="q" className="sr-only">Search</label>
          <Search aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-2" />
          <input id="q" className="field pl-9" placeholder="Search clinic, service or area" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div>
          <label htmlFor="city" className="sr-only">City</label>
          <select id="city" className="field" value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="all">All cities</option>
            {cities.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="spec" className="sr-only">Specialty</label>
          <select id="spec" className="field" value={spec} onChange={(e) => setSpec(e.target.value as Specialty | "all")}>
            <option value="all">All specialties</option>
            {SPECIALTIES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
      </div>

      <p className="mt-4 text-[0.95rem] text-ink-2" aria-live="polite">
        {list.length} {list.length === 1 ? "clinic" : "clinics"}
      </p>

      <ul className="mt-3 grid gap-4 md:grid-cols-2">
        {list.map((s) => (
          <li key={s.id} className="card flex flex-col p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold leading-snug">{s.clinic}</h2>
                <p className="text-[0.95rem] text-ink-2">{s.lead}</p>
              </div>
              {s.demo && (
                <span className="shrink-0 rounded border border-rule px-1.5 py-0.5 text-[0.7rem] uppercase tracking-wider text-ink-2">
                  Demo
                </span>
              )}
            </div>
            <p className="mt-2 inline-flex items-center gap-1.5 text-[0.95rem]">
              <MapPin aria-hidden="true" className="h-4 w-4 text-ink-2" />
              {s.area}, {s.city}
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {s.specialties.map((t) => (
                <span key={t} className="rounded-full bg-raised px-2.5 py-0.5 text-[0.8rem]">
                  {t}
                </span>
              ))}
            </div>
            <p className="mt-3 text-[0.9rem] leading-snug text-ink-2">{s.services.join(" · ")}</p>
            <p className="mt-1 text-[0.9rem] text-ink-2">
              {s.days} · {s.languages.join(", ")}
            </p>
            <div className="mt-auto pt-4">
              {!s.bookable ? (
                <p className="text-[0.9rem] text-ink-2">This clinic does not take requests through the app.</p>
              ) : user?.role === "patient" ? (
                <button type="button" className="btn-primary" onClick={() => setBooking(s)}>
                  <CalendarPlus aria-hidden="true" className="h-4 w-4" />
                  Request appointment
                </button>
              ) : state.kind === "guest" ? (
                <Link href="/login?next=/specialists" className="btn-ghost">
                  Sign in to request an appointment
                </Link>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
      {directory.kind === "error" && <p role="alert" className="mt-6">{directory.message}</p>}
      {directory.kind === "ok" && list.length === 0 && (
        <p className="mt-6 text-ink-2">No clinic matches those filters. Widen the city or specialty.</p>
      )}

      {booking && <AppointmentForm specialist={booking} screeningId={screeningId} onClose={() => setBooking(null)} />}
    </div>
  );
}

"use client";

import Link from "next/link";
import { Suspense, useCallback, useState } from "react";
import { useSearchParams } from "next/navigation";
import { ArrowLeft, Download } from "lucide-react";
import { RequireRole } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { downloadReport } from "@/lib/report";
import { getScreening, submitReview, useRecords, type SavedScreening } from "@/lib/store";
import { GRADE_NAMES } from "@/lib/types";
import { GuardNotice, QualityNotice } from "@/components/GuardNotice";
import { ImageViewer } from "@/components/ImageViewer";
import { Readout } from "@/components/Readout";
import { ReviewPanel } from "@/components/ReviewPanel";

export default function ReviewPage() {
  return (
    <RequireRole roles={["specialist"]}>
      <Suspense fallback={<p className="text-ink-2">…</p>}>
        <Review />
      </Suspense>
    </RequireRole>
  );
}

function Review() {
  const id = useSearchParams().get("id") ?? "";
  const load = useCallback(() => getScreening(id), [id]);
  const rec = useRecords(load);

  if (rec.kind === "loading") return <p className="text-ink-2">…</p>;
  if (rec.kind === "error") return <p role="alert">{rec.message}</p>;
  if (!rec.data) {
    return (
      <div>
        <h1 className="text-3xl font-bold">This screening is not in your review list</h1>
        <Link href="/specialist" className="btn-primary mt-6">Back to the queue</Link>
      </div>
    );
  }
  return <ReviewView s={rec.data} />;
}

function ReviewView({ s }: { s: SavedScreening }) {
  const { t, lang } = useI18n();
  const r = s.result;
  const warned = r.guard.status !== "ok";

  return (
    <div>
      <Link href="/specialist" className="inline-flex items-center gap-1.5 text-ink-2 hover:text-ink">
        <ArrowLeft aria-hidden="true" className="h-4 w-4 rtl:rotate-180" /> {t("spec.title")}
      </Link>
      <div className="mt-4 flex flex-wrap items-baseline justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold leading-tight sm:text-4xl">{s.patient?.name ?? t("spec.patient")}</h1>
          <p className="mt-1 text-ink-2">
            {new Date(s.createdAt).toLocaleString(lang === "ur" ? "ur-PK" : "en-GB", { dateStyle: "long", timeStyle: "short" })} · {s.eye} eye
            {s.label ? ` · ${s.label}` : ""}
          </p>
        </div>
        <button type="button" className="btn-ghost" onClick={() => downloadReport(s)}>
          <Download aria-hidden="true" className="h-4 w-4" /> PDF
        </button>
      </div>

      <div className="mt-7 grid gap-10 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:items-start">
        <ImageViewer preprocessed={r.preprocessed_png} overlay={r.overlay_png} fileName={s.fileName} />
        <div className="space-y-6" dir="ltr">
          {warned && <GuardNotice guard={r.guard} />}
          <QualityNotice quality={r.quality} />
          <Readout r={r} />
          {!warned && <GuardNotice guard={r.guard} />}
          {s.review?.status === "reviewed" ? <ReviewPanel review={s.review} /> : <ReviewForm s={s} />}
        </div>
      </div>
    </div>
  );
}

function ReviewForm({ s }: { s: SavedScreening }) {
  const { t } = useI18n();
  const r = s.result;
  const [agrees, setAgrees] = useState(true);
  const [grade, setGrade] = useState<number>(r.grade);
  const [refer, setRefer] = useState<boolean>(r.referable);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await submitReview(s.id, agrees ? { agrees: true, note } : { agrees: false, grade, refer, note });
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="card space-y-4 p-5">
      <h2 className="text-lg font-bold">{t("spec.your_reading")}</h2>
      <fieldset className="space-y-2">
        <legend className="sr-only">{t("spec.your_reading")}</legend>
        <label className="flex items-center gap-3">
          <input type="radio" name="agree" checked={agrees} onChange={() => setAgrees(true)} className="h-4 w-4 accent-[var(--color-sev-4)]" />
          {t("spec.agree")}
        </label>
        <label className="flex items-center gap-3">
          <input type="radio" name="agree" checked={!agrees} onChange={() => setAgrees(false)} className="h-4 w-4 accent-[var(--color-sev-4)]" />
          {t("spec.disagree")}
        </label>
      </fieldset>
      {!agrees && (
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="rv-grade" className="label">{t("spec.grade")}</label>
            <select id="rv-grade" className="field" value={grade} onChange={(e) => setGrade(Number(e.target.value))}>
              {GRADE_NAMES.map((n, i) => (
                <option key={n} value={i}>{i} — {n}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="rv-refer" className="label">{t("spec.refer")}</label>
            <select id="rv-refer" className="field" value={refer ? "1" : "0"} onChange={(e) => setRefer(e.target.value === "1")}>
              <option value="1">{t("spec.refer_yes")}</option>
              <option value="0">{t("spec.refer_no")}</option>
            </select>
          </div>
        </div>
      )}
      <div>
        <label htmlFor="rv-note" className="label">{t("spec.note")} <span className="font-normal text-ink-2">{t("auth.optional")}</span></label>
        <textarea id="rv-note" rows={3} maxLength={1000} className="field" value={note} onChange={(e) => setNote(e.target.value)} placeholder="What you saw, and what the patient should do next" />
      </div>
      {error && <p role="alert" className="alert">{error}</p>}
      <button type="submit" className="btn-primary" disabled={busy}>{busy ? t("auth.working") : t("spec.submit")}</button>
      <p className="text-[0.85rem] leading-snug text-ink-2">
        Reviewing from one 224 × 224 photograph is not an examination. Your review is stored beside the model&apos;s answer and both are shown to the patient.
      </p>
    </form>
  );
}

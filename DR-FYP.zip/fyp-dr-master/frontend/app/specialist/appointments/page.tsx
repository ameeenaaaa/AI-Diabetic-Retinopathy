"use client";

import Link from "next/link";
import { useState } from "react";
import { CalendarCheck } from "lucide-react";
import { RequireRole } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { listAppointments, setAppointmentStatus, useRecords, type Appointment } from "@/lib/store";
import { StatusPill } from "@/components/StatusPill";

const SLOT = { morning: "Morning", afternoon: "Afternoon", evening: "Evening" } as const;

export default function SpecialistAppointmentsPage() {
  return (
    <RequireRole roles={["specialist"]}>
      <Appointments />
    </RequireRole>
  );
}

function Appointments() {
  const { t } = useI18n();
  const items = useRecords(listAppointments);
  return (
    <div>
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("spec.appts_title")}</h1>
      <p className="mt-3 max-w-[66ch] text-lg leading-relaxed text-ink-2">{t("spec.appts_lead")}</p>
      <div className="mt-6">
        {items.kind === "loading" ? (
          <p className="text-ink-2">…</p>
        ) : items.kind === "error" ? (
          <p role="alert">{items.message}</p>
        ) : items.data.length === 0 ? (
          <div className="card flex flex-col items-center px-6 py-12 text-center">
            <CalendarCheck aria-hidden="true" className="h-8 w-8 text-ink-2" />
            <p className="mt-3 text-ink-2">{t("records.empty_appts")}</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {items.data.map((a) => (
              <Row key={a.id} a={a} />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function Row({ a }: { a: Appointment }) {
  const { t, lang } = useI18n();
  const [note, setNote] = useState(a.specialistNote);
  const [error, setError] = useState<string | null>(null);
  const date = new Date(`${a.preferredDate}T00:00:00`).toLocaleDateString(lang === "ur" ? "ur-PK" : "en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
  const act = (s: "confirmed" | "declined" | "completed" | "cancelled") =>
    setAppointmentStatus(a, s, note).catch((e: Error) => setError(e.message));
  const open = a.status === "requested" || a.status === "confirmed";

  return (
    <li className={`card p-4 ${open ? "" : "opacity-75"}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-bold">{a.patientName}</p>
          <p className="text-[0.95rem] text-ink-2">
            {date}, {SLOT[a.slot].toLowerCase()} · <span className="ltr">{a.phone}</span>
          </p>
        </div>
        <StatusPill status={a.status} />
      </div>
      {a.notes && <p className="mt-2 text-[0.95rem] leading-snug">{a.notes}</p>}
      {a.screeningId && (
        <p className="mt-2 text-[0.9rem]">
          <Link href={`/specialist/review?id=${a.screeningId}`} className="underline underline-offset-4">
            {t("records.attached")}
          </Link>
        </p>
      )}
      {open && (
        <div className="mt-3 space-y-2">
          <label htmlFor={`note-${a.id}`} className="sr-only">{t("spec.note")}</label>
          <input id={`note-${a.id}`} className="field" maxLength={500} value={note} placeholder={t("spec.note_placeholder")} onChange={(e) => setNote(e.target.value)} />
          <div className="flex flex-wrap gap-2">
            {a.status === "requested" && (
              <>
                <button type="button" className="btn-primary" onClick={() => act("confirmed")}>{t("spec.confirm")}</button>
                <button type="button" className="btn-ghost" onClick={() => act("declined")}>{t("spec.decline")}</button>
              </>
            )}
            {a.status === "confirmed" && (
              <>
                <button type="button" className="btn-primary" onClick={() => act("completed")}>{t("spec.complete")}</button>
                <button type="button" className="btn-ghost" onClick={() => act("cancelled")}>{t("records.cancel")}</button>
              </>
            )}
          </div>
        </div>
      )}
      {!open && a.specialistNote && <p className="mt-2 text-[0.9rem] text-ink-2">{t("records.clinic_note")}: {a.specialistNote}</p>}
      {error && <p role="alert" className="mt-2 text-[0.9rem]">{error}</p>}
    </li>
  );
}

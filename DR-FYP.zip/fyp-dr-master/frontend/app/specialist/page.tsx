"use client";

import Link from "next/link";
import { useCallback, useState } from "react";
import { ClipboardList } from "lucide-react";
import { RequireRole } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { reviewQueue, useRecords, type SavedScreening } from "@/lib/store";
import { ReviewBadge } from "@/components/ReviewPanel";

export default function SpecialistQueuePage() {
  return (
    <RequireRole roles={["specialist"]}>
      <Queue />
    </RequireRole>
  );
}

function Queue() {
  const { t } = useI18n();
  const [tab, setTab] = useState<"pending" | "reviewed">("pending");
  const load = useCallback(() => reviewQueue(tab), [tab]);
  const items = useRecords(load);

  return (
    <div>
      <h1 className="text-4xl font-bold leading-tight tracking-tight">{t("spec.title")}</h1>
      <p className="mt-3 max-w-[66ch] text-lg leading-relaxed text-ink-2">{t("spec.lead")}</p>

      <div role="tablist" className="mt-7 inline-flex rounded-xl border border-rule bg-sheet p-1">
        {(["pending", "reviewed"] as const).map((x) => (
          <button
            key={x}
            role="tab"
            type="button"
            aria-selected={tab === x}
            onClick={() => setTab(x)}
            className={`rounded-lg px-4 py-1.5 text-[0.95rem] ${tab === x ? "bg-brand font-bold text-white shadow-sm" : "text-ink-2 hover:text-brand"}`}
          >
            {t(x === "pending" ? "spec.tab_pending" : "spec.tab_reviewed")}
          </button>
        ))}
      </div>

      <div className="mt-6" role="tabpanel">
        {items.kind === "loading" ? (
          <p className="text-ink-2">…</p>
        ) : items.kind === "error" ? (
          <p role="alert">{items.message}</p>
        ) : items.data.length === 0 ? (
          <div className="card flex flex-col items-center px-6 py-12 text-center">
            <ClipboardList aria-hidden="true" className="h-8 w-8 text-ink-2" />
            <p className="mt-3 text-ink-2">{t(tab === "pending" ? "spec.empty_pending" : "spec.empty_reviewed")}</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {items.data.map((s) => (
              <QueueRow key={s.id} s={s} />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function QueueRow({ s }: { s: SavedScreening }) {
  const { t, lang } = useI18n();
  const r = s.result;
  return (
    <li className="card flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
      {r.preprocessed_png ? (
        /* eslint-disable-next-line @next/next/no-img-element -- data URI */
        <img src={r.preprocessed_png} alt="" className="h-20 w-20 shrink-0 rounded-lg bg-viewer" />
      ) : (
        <div className="h-20 w-20 shrink-0 rounded-lg bg-viewer" />
      )}
      <div className="min-w-0 flex-1">
        <p className="font-bold">
          {s.patient?.name ?? t("spec.patient")}
          {s.patient?.city ? <span className="font-normal text-ink-2"> · {s.patient.city}</span> : null}
        </p>
        <p className="text-[0.9rem] text-ink-2">
          {new Date(s.createdAt).toLocaleString(lang === "ur" ? "ur-PK" : "en-GB", { dateStyle: "medium", timeStyle: "short" })} · {s.eye} eye
        </p>
        <p className="mt-1" dir="ltr">
          Model: <span className="font-bold">{r.grade_name}</span>, <span className="font-bold">{r.referable ? "Refer" : "Not flagged"}</span>
          <span className="text-ink-2"> · score {r.score.toFixed(2)}</span>
        </p>
        <div className="mt-1.5 flex flex-wrap gap-2">
          <ReviewBadge review={s.review} />
          {r.guard.status !== "ok" && <span className="chip-warn">Framing warning</span>}
          {r.quality?.status === "poor_capture_quality" && <span className="chip-warn">Low image quality</span>}
        </div>
      </div>
      <Link href={`/specialist/review?id=${s.id}`} className="btn-primary">
        {t("spec.open")}
      </Link>
    </li>
  );
}

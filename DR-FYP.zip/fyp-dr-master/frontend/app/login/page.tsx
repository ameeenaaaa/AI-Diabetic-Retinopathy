"use client";

import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { HOME_FOR, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { safeNext } from "@/lib/safeNext";

// The demo logins created by backend/seed.py. Shown so the panel can sign in as each role;
// they are public by design and only exist on a local demonstration server.
const DEMO = [
  { role: "role.patient", email: "patient@demo.pk", password: "Patient@1234" },
  { role: "role.specialist", email: "s05@clinic.demo.pk", password: "Doctor@1234", note: "Lahore" },
  { role: "role.specialist", email: "s01@clinic.demo.pk", password: "Doctor@1234", note: "Islamabad" },
  { role: "role.admin", email: "admin@demo.pk", password: "Admin@1234" },
] as const;

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <Login />
    </Suspense>
  );
}

function Login() {
  const { t } = useI18n();
  const { login, state } = useAuth();
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (state.kind === "user") router.replace(next ?? HOME_FOR[state.user.role]);
  }, [state, next, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(await login(email.trim(), password));
    setBusy(false);
  };

  return (
    <div className="mx-auto grid max-w-4xl gap-10 md:grid-cols-[minmax(0,1fr)_minmax(0,0.9fr)]">
      <div>
        <h1 className="text-4xl font-bold leading-tight">{t("auth.signin_title")}</h1>
        <p className="mt-3 text-lg leading-relaxed text-ink-2">{t("auth.signin_lead")}</p>
        <form onSubmit={submit} className="mt-7 space-y-4" noValidate>
          <div>
            <label className="label" htmlFor="email">{t("auth.email")}</label>
            <input id="email" type="email" autoComplete="email" className="field ltr" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="password">{t("auth.password")}</label>
            <input id="password" type="password" autoComplete="current-password" className="field ltr" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error && <p role="alert" className="alert">{error}</p>}
          <button type="submit" className="btn-primary" disabled={busy || !email || !password}>
            {busy ? t("auth.working") : t("auth.signin_btn")}
          </button>
        </form>
        <p className="mt-6 text-ink-2">
          {t("auth.no_account")}{" "}
          <Link href={`/register${next ? `?next=${encodeURIComponent(next)}` : ""}`} className="text-ink underline underline-offset-4">
            {t("nav.register")}
          </Link>
        </p>
      </div>

      <aside className="card h-fit p-5">
        <h2 className="font-bold">{t("auth.demo_title")}</h2>
        <p className="mt-1 text-[0.9rem] text-ink-2">{t("auth.demo_note")}</p>
        <ul className="mt-4 space-y-2">
          {DEMO.map((d) => (
            <li key={d.email}>
              <button
                type="button"
                onClick={() => {
                  setEmail(d.email);
                  setPassword(d.password);
                  setError(null);
                }}
                className="w-full rounded-lg border border-rule px-3 py-2 text-start hover:border-ink-2 hover:bg-raised"
              >
                <span className="block font-bold">
                  {t(d.role)}
                  {"note" in d ? ` · ${d.note}` : ""}
                </span>
                <span className="ltr block text-[0.85rem] text-ink-2">{d.email} · {d.password}</span>
              </button>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}

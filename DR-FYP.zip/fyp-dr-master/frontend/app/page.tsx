"use client";

import Link from "next/link";
import { useCallback } from "react";
import {
  ArrowRight,
  Bot,
  CalendarCheck,
  CalendarClock,
  ClipboardCheck,
  ClipboardList,
  FileText,
  FolderHeart,
  Languages,
  LineChart,
  ScanEye,
  ShieldCheck,
  Stethoscope,
  type LucideIcon,
} from "lucide-react";
import { HOME_FOR, useAuth } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { useMeta } from "@/lib/useMeta";
import { listAppointments, listScreenings, reviewQueue, useRecords } from "@/lib/store";
import { nextDue } from "@/components/HistoryView";
import { FlowDiagram } from "@/components/FlowDiagram";

export default function HomePage() {
  const { state, user } = useAuth();
  if (state.kind === "loading") return null;
  if (!user) return <Landing />;
  if (user.role === "patient") return <PatientHome name={user.name} />;
  if (user.role === "specialist") return <SpecialistHome name={user.name} />;
  return <AdminHome name={user.name} />;
}

// ------------------------------------------------------------------ shared pieces
function Banner({ name, cta, sub }: { name: string; cta: { href: string; label: string }; sub?: string }) {
  const { t } = useI18n();
  return (
    <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-indigo to-blue px-6 py-8 text-white sm:px-10 sm:py-10">
      <div aria-hidden="true" className="absolute -end-16 -top-16 h-64 w-64 rounded-full bg-white/10" />
      <div aria-hidden="true" className="absolute -bottom-20 end-24 h-48 w-48 rounded-full bg-white/10" />
      <p className="relative text-[0.9rem] text-white/80">{t("home.welcome_back")}</p>
      <h1 className="relative mt-1 text-3xl font-bold leading-tight sm:text-4xl">{name}</h1>
      {sub && <p className="relative mt-2 max-w-[60ch] text-white/85">{sub}</p>}
      <Link href={cta.href} className="relative mt-6 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-2.5 font-bold text-brand-dark shadow-sm hover:bg-brand-soft">
        {cta.label} <ArrowRight aria-hidden="true" className="h-4 w-4 rtl:rotate-180" />
      </Link>
    </section>
  );
}

// Filled stat tile in the style of a hospital dashboard. Colours mark WHICH metric it is,
// never how good or bad a result is.
function Tile({ icon: Icon, label, value, sub, color, href }: { icon: LucideIcon; label: string; value: string | number; sub?: string; color: string; href?: string }) {
  const body = (
    <div className={`relative h-full overflow-hidden rounded-2xl p-5 text-white shadow-sm ${color}`}>
      <div aria-hidden="true" className="absolute -end-6 -top-6 h-24 w-24 rounded-full bg-white/10" />
      <span className="icon-circle relative bg-white/20">
        <Icon aria-hidden="true" className="h-5 w-5" />
      </span>
      <p className="relative mt-3 text-[0.9rem] text-white/85">{label}</p>
      <p className="relative mt-0.5 text-2xl font-bold leading-tight">{value}</p>
      {sub && <p className="relative mt-1 text-[0.82rem] text-white/80">{sub}</p>}
    </div>
  );
  return href ? (
    <Link href={href} className="block transition-transform hover:-translate-y-0.5">
      {body}
    </Link>
  ) : (
    body
  );
}

function Action({ href, icon: Icon, title, body, tint }: { href: string; icon: LucideIcon; title: string; body: string; tint: string }) {
  return (
    <Link href={href} className="card flex items-start gap-4 p-5 transition-shadow hover:shadow-md">
      <span className={`icon-circle ${tint}`}>
        <Icon aria-hidden="true" className="h-5 w-5" />
      </span>
      <span>
        <span className="block font-bold">{title}</span>
        <span className="mt-0.5 block text-[0.92rem] leading-snug text-ink-2">{body}</span>
      </span>
    </Link>
  );
}

// ------------------------------------------------------------------ patient
function PatientHome({ name }: { name: string }) {
  const { t, lang } = useI18n();
  const screenings = useRecords(listScreenings);
  const appts = useRecords(listAppointments);
  const list = screenings.kind === "ok" ? screenings.data : [];
  const latest = list[0];
  const due = nextDue(list);
  const open = appts.kind === "ok" ? appts.data.filter((a) => a.status === "requested" || a.status === "confirmed").length : 0;
  const reviewed = list.filter((s) => s.review?.status === "reviewed").length;
  const pending = list.filter((s) => s.review?.status === "pending").length;
  const loc = lang === "ur" ? "ur-PK" : "en-GB";

  return (
    <div className="space-y-8">
      <Banner name={name} sub={t("home.patient_sub")} cta={{ href: "/screen", label: t("home.start") }} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Tile icon={FolderHeart} color="bg-gradient-to-br from-brand to-brand-dark" label={t("home.tile_saved")} value={list.length} href="/records" />
        <Tile icon={CalendarCheck} color="bg-gradient-to-br from-accent to-[#0b7a70]" label={t("home.tile_appts")} value={open} href="/records?tab=appointments" />
        <Tile icon={ClipboardCheck} color="bg-gradient-to-br from-blue to-[#1d4ed8]" label={t("home.tile_reviews")} value={reviewed} sub={pending ? `${pending} ${t("home.waiting")}` : undefined} href="/records" />
        <Tile
          icon={CalendarClock}
          color="bg-gradient-to-br from-indigo to-sev-4"
          label={t("history.next_due")}
          value={latest?.result.referable ? t("home.see_specialist") : due ? due.toLocaleDateString(loc, { day: "numeric", month: "short", year: "numeric" }) : "—"}
          href="/records?tab=history"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
        <section className="card p-6">
          <h2 className="text-lg font-bold">{t("home.latest_title")}</h2>
          {latest ? (
            <div className="mt-4 flex flex-col gap-5 sm:flex-row">
              {latest.result.preprocessed_png && (
                /* eslint-disable-next-line @next/next/no-img-element -- stored data URI */
                <img src={latest.result.preprocessed_png} alt="" className="h-32 w-32 shrink-0 rounded-2xl bg-viewer" />
              )}
              <div className="min-w-0 flex-1">
                <p className="text-[0.9rem] text-ink-2">{new Date(latest.createdAt).toLocaleString(loc, { dateStyle: "medium", timeStyle: "short" })}</p>
                <dl className="mt-2 grid grid-cols-2 gap-4" dir="ltr">
                  <div>
                    <dt className="text-[0.85rem] text-ink-2">Estimated grade</dt>
                    <dd className="text-2xl font-bold">{latest.result.grade_name}</dd>
                  </div>
                  <div>
                    <dt className="text-[0.85rem] text-ink-2">Referral</dt>
                    <dd className="text-2xl font-bold">{latest.result.referable ? "Refer" : "Not flagged"}</dd>
                  </div>
                </dl>
                <Link href={`/records/view?id=${latest.id}`} className="btn-ghost mt-4">
                  {t("records.open")}
                </Link>
              </div>
            </div>
          ) : (
            <div className="mt-4 rounded-2xl bg-raised p-6 text-center">
              <p className="text-ink-2">{t("records.empty_screenings")}</p>
              <Link href="/screen" className="btn-primary mt-4">{t("home.start")}</Link>
            </div>
          )}
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">{t("home.quick_title")}</h2>
          <Action href="/screen" icon={ScanEye} tint="bg-brand-soft text-brand" title={t("nav.screen")} body={t("home.q_screen")} />
          <Action href="/assistant" icon={Bot} tint="bg-accent-soft text-accent" title={t("nav.assistant")} body={t("home.q_assistant")} />
          <Action href="/specialists" icon={Stethoscope} tint="bg-blue-soft text-blue" title={t("nav.specialists")} body={t("home.q_specialists")} />
          <Action href="/records?tab=history" icon={LineChart} tint="bg-sev-0 text-indigo" title={t("records.tab_history")} body={t("home.q_history")} />
        </section>
      </div>
    </div>
  );
}

function AdminHome({ name }: { name: string }) {
  const { t } = useI18n();
  return <Banner name={name} cta={{ href: HOME_FOR.admin, label: t("home.dashboard") }} />;
}

// ------------------------------------------------------------------ specialist
function SpecialistHome({ name }: { name: string }) {
  const { t } = useI18n();
  const loadP = useCallback(() => reviewQueue("pending"), []);
  const loadR = useCallback(() => reviewQueue("reviewed"), []);
  const pending = useRecords(loadP);
  const reviewed = useRecords(loadR);
  const appts = useRecords(listAppointments);
  const n = (x: { kind: string; data?: unknown[] }) => (x.kind === "ok" && Array.isArray(x.data) ? x.data.length : "—");
  const openAppts = appts.kind === "ok" ? appts.data.filter((a) => a.status === "requested").length : "—";
  return (
    <div className="space-y-8">
      <Banner name={name} sub={t("home.specialist_sub")} cta={{ href: "/specialist", label: t("home.queue") }} />
      <div className="grid gap-4 sm:grid-cols-3">
        <Tile icon={ClipboardList} color="bg-gradient-to-br from-brand to-brand-dark" label={t("spec.tab_pending")} value={n(pending as never)} href="/specialist" />
        <Tile icon={ClipboardCheck} color="bg-gradient-to-br from-blue to-[#1d4ed8]" label={t("spec.tab_reviewed")} value={n(reviewed as never)} href="/specialist" />
        <Tile icon={CalendarCheck} color="bg-gradient-to-br from-accent to-[#0b7a70]" label={t("home.tile_requests")} value={openAppts} href="/specialist/appointments" />
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ visitor
function Landing() {
  const { t } = useI18n();
  const [meta] = useMeta();
  const features: { icon: LucideIcon; tint: string; title: string; body: string }[] = [
    { icon: ScanEye, tint: "bg-brand-soft text-brand", title: t("land.f1_t"), body: t("land.f1_b") },
    { icon: ShieldCheck, tint: "bg-warm-soft text-warm", title: t("land.f2_t"), body: t("land.f2_b") },
    { icon: Bot, tint: "bg-accent-soft text-accent", title: t("land.f3_t"), body: t("land.f3_b") },
    { icon: ClipboardCheck, tint: "bg-blue-soft text-blue", title: t("land.f4_t"), body: t("land.f4_b") },
    { icon: LineChart, tint: "bg-sev-0 text-indigo", title: t("land.f5_t"), body: t("land.f5_b") },
    { icon: Languages, tint: "bg-rose-soft text-rose", title: t("land.f6_t"), body: t("land.f6_b") },
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand via-indigo to-blue px-6 py-12 text-white sm:px-12 sm:py-16">
        <div aria-hidden="true" className="absolute -end-24 -top-24 h-80 w-80 rounded-full bg-white/10" />
        <div aria-hidden="true" className="absolute -bottom-28 end-40 h-64 w-64 rounded-full bg-white/10" />
        <div className="relative grid items-center gap-10 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]">
          <div>
            <p className="inline-flex rounded-full bg-white/15 px-3 py-1 text-[0.8rem] font-bold uppercase tracking-[0.12em]">{t("home.kicker")}</p>
            <h1 className="mt-4 max-w-[20ch] text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl">{t("home.title")}</h1>
            <p className="mt-4 max-w-[58ch] text-lg leading-relaxed text-white/90">{t("home.lead")}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-bold text-brand-dark shadow-sm hover:bg-brand-soft">
                {t("home.register")} <ArrowRight aria-hidden="true" className="h-4 w-4 rtl:rotate-180" />
              </Link>
              <Link href="/login" className="inline-flex items-center gap-2 rounded-xl border border-white/50 px-5 py-3 font-bold text-white hover:bg-white/10">
                {t("home.signin")}
              </Link>
            </div>
          </div>
          <div className="rounded-3xl bg-white/95 p-6 text-ink shadow-xl">
            <p className="font-bold">{t("land.panel_title")}</p>
            <ul className="mt-4 space-y-3">
              {[
                [ScanEye, "bg-brand-soft text-brand", t("land.p1")],
                [FileText, "bg-accent-soft text-accent", t("land.p2")],
                [Stethoscope, "bg-blue-soft text-blue", t("land.p3")],
                [CalendarCheck, "bg-sev-0 text-indigo", t("land.p4")],
              ].map(([Icon, tint, text]) => {
                const I = Icon as LucideIcon;
                return (
                  <li key={text as string} className="flex items-center gap-3">
                    <span className={`icon-circle h-9 w-9 ${tint}`}>
                      <I aria-hidden="true" className="h-4 w-4" />
                    </span>
                    <span className="text-[0.95rem]">{text as string}</span>
                  </li>
                );
              })}
            </ul>
            {meta.kind === "ok" && (
              <div className="mt-5 grid grid-cols-2 gap-3 border-t border-rule pt-4" dir="ltr">
                <div>
                  <p className="text-2xl font-bold text-brand">{meta.data.reported_val_qwk.toFixed(3)}</p>
                  <p className="text-[0.78rem] leading-snug text-ink-2">agreement with graders (QWK, validation)</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-brand">{(meta.data.reported_val_sens_at_spec95 * 100).toFixed(1)}%</p>
                  <p className="text-[0.78rem] leading-snug text-ink-2">referable cases flagged — below the 80% reference</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      <section aria-labelledby="features-h">
        <h2 id="features-h" className="text-center text-3xl font-bold tracking-tight">{t("land.features_title")}</h2>
        <p className="mx-auto mt-2 max-w-[60ch] text-center text-ink-2">{t("land.features_lead")}</p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({ icon: Icon, tint, title, body }) => (
            <div key={title} className="card p-6">
              <span className={`icon-circle h-12 w-12 ${tint}`}>
                <Icon aria-hidden="true" className="h-6 w-6" />
              </span>
              <h3 className="mt-4 text-lg font-bold">{title}</h3>
              <p className="mt-1 text-[0.95rem] leading-snug text-ink-2">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section aria-labelledby="how" className="card px-4 py-10 sm:px-10">
        <h2 id="how" className="text-center text-3xl font-bold tracking-tight">{t("land.how_title")}</h2>
        <div className="mt-8">
          <FlowDiagram />
        </div>
      </section>

      <section className="rounded-2xl border border-indigo/20 bg-sev-0/40 px-6 py-5 text-[0.95rem] leading-relaxed text-ink-2" dir="ltr">
        <p>
          <strong className="text-ink">Not a medical device.</strong> Retinopathy Screening estimates a grade from one
          photograph; it does not examine the eye
          {meta.kind === "ok" &&
            `, and on validation images it did not flag about ${Math.round((1 - meta.data.reported_val_sens_at_spec95) * 100)}% of the cases that needed referral`}
          . The full limits are shown with every upload and result, and on the{" "}
          <Link href="/about" className="font-bold text-brand underline underline-offset-4">About</Link> page.
        </p>
      </section>
    </div>
  );
}

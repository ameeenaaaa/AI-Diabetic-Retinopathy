"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ImagePlus, RotateCcw } from "lucide-react";
import { API_BASE, predict, type ApiResult } from "@/lib/api";
import type { Meta, PredictGraded, PredictResponse } from "@/lib/types";
import { useMeta } from "@/lib/useMeta";
import { guidanceForDeclined, guidanceForGraded } from "@/lib/guidance";
import { snapshotMeta, type SavedScreening } from "@/lib/store";
import { RequireRole } from "@/lib/auth";
import { useI18n } from "@/lib/i18n";
import { downloadReport } from "@/lib/report";
import { AssistantPanel } from "@/components/AssistantPanel";
import { Disclaimer } from "@/components/Disclaimer";
import { GuardNotice, QualityNotice } from "@/components/GuardNotice";
import { ImageViewer } from "@/components/ImageViewer";
import { Provenance } from "@/components/Provenance";
import { Readout } from "@/components/Readout";
import { ReferralGuidance } from "@/components/ReferralGuidance";
import { ReportActions } from "@/components/ReportActions";

type Flow =
  | { kind: "idle" }
  | { kind: "grading"; file: File; url: string }
  | { kind: "done"; file: File; url: string; result: ApiResult<PredictResponse> };

export default function ScreenPage() {
  return (
    <RequireRole roles={["patient"]}>
      <Screen />
    </RequireRole>
  );
}

function Screen() {
  const [meta, reloadMeta] = useMeta();
  const [flow, setFlow] = useState<Flow>({ kind: "idle" });
  const urlRef = useRef<string | null>(null);

  // The preview URL of the upload is released as soon as it is replaced or left.
  useEffect(() => () => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
  }, []);

  const grade = useCallback(async (file: File) => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    const url = URL.createObjectURL(file);
    urlRef.current = url;
    setFlow({ kind: "grading", file, url });
    const result = await predict(file);
    setFlow({ kind: "done", file, url, result });
  }, []);

  const reset = useCallback(() => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    urlRef.current = null;
    setFlow({ kind: "idle" });
  }, []);

  if (meta.kind === "loading") {
    return <p className="text-ink-2" role="status">Connecting to the grading service…</p>;
  }

  if (meta.kind !== "ok") {
    return (
      <ServiceProblem
        title="The grading service is not reachable"
        body={`This page reads the model's reported figures and its limits from the service at ${API_BASE}, so it cannot be used until the service responds. Saved records and the specialist directory still work.`}
        detail={meta.kind === "http" ? `HTTP ${meta.status}: ${meta.detail}` : meta.message}
        action="Try again"
        onAction={reloadMeta}
        hint="Start it with: uvicorn backend.app:app --port 8000"
      />
    );
  }

  if (flow.kind === "idle") return <UploadView meta={meta.data} onFile={grade} />;

  if (flow.kind === "grading") {
    return (
      <div role="status" aria-live="polite">
        <Steps at={2} />
        <h1 className="mt-6 text-3xl font-bold leading-tight">Screening {flow.file.name}</h1>
        <p className="mt-2 text-ink-2">
          The image is being preprocessed, checked for framing, graded, and explained. The page
          will update when the estimate is ready.
        </p>
        <div className="mt-6 h-1.5 w-full max-w-md overflow-hidden rounded-full bg-raised" aria-hidden="true">
          <div className="h-full w-1/3 animate-pulse rounded-full bg-sev-3" />
        </div>
        <div className="mt-8">
          <Disclaimer items={meta.data.disclaimer} />
        </div>
        <Provenance meta={meta.data} />
      </div>
    );
  }

  return <ResultView meta={meta.data} flow={flow} onAgain={reset} onFile={grade} />;
}

// ------------------------------------------------------------------ progress strip
const STEP_NAMES = ["Upload", "Screening", "Report & guidance", "Specialist"];
function Steps({ at }: { at: 1 | 2 | 3 }) {
  return (
    <ol aria-label="Progress" className="flex flex-wrap gap-x-2 gap-y-1 text-[0.85rem]">
      {STEP_NAMES.map((n, i) => (
        <li
          key={n}
          aria-current={i + 1 === at ? "step" : undefined}
          className={`rounded-full border px-3 py-1 ${
            i + 1 === at ? "border-brand bg-brand text-white font-bold" : i + 1 < at ? "border-rule text-ink" : "border-rule text-ink-2"
          }`}
        >
          {i + 1}. {n}
        </li>
      ))}
    </ol>
  );
}

// ------------------------------------------------------------------ upload
function UploadView({ meta, onFile }: { meta: Meta; onFile: (f: File) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  return (
    <div>
      <Steps at={1} />
      <h1 className="mt-6 max-w-[24ch] text-4xl font-bold leading-[1.1] tracking-tight sm:text-5xl">
        Upload a retinal photograph
      </h1>
      <p className="mt-4 max-w-[62ch] text-lg leading-relaxed text-ink-2">
        It is cropped and normalised the way the training images were and checked for framing.
        You get an estimated grade, a separate referral decision, the image the model actually
        graded, a map of which regions moved the score, and guidance on what to do next.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] lg:items-start">
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setOver(true);
          }}
          onDragLeave={() => setOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setOver(false);
            const f = e.dataTransfer.files?.[0];
            if (f) onFile(f);
          }}
          className={`flex min-h-72 flex-col items-center justify-center rounded-xl border-2 border-dashed p-6 text-center ${
            over ? "border-sev-4 bg-sev-0" : "border-rule bg-sheet"
          }`}
        >
          <ImagePlus aria-hidden="true" className="h-10 w-10 text-ink-2" />
          <p className="mt-3 text-xl font-bold">Drop a fundus photograph here</p>
          <p className="mt-1 text-ink-2">JPEG or PNG, one image at a time, up to 20 MB.</p>
          <button type="button" onClick={() => input.current?.click()} className="btn-primary mt-5">
            Choose a photograph
          </button>
          <input
            ref={input}
            type="file"
            accept="image/*"
            className="sr-only"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = "";
              if (f) onFile(f);
            }}
          />
        </div>

        <Disclaimer items={meta.disclaimer} />
      </div>

      <Provenance meta={meta} />
    </div>
  );
}

// ------------------------------------------------------------------ result
function ResultView({
  meta,
  flow,
  onAgain,
  onFile,
}: {
  meta: Meta;
  flow: Extract<Flow, { kind: "done" }>;
  onAgain: () => void;
  onFile: (f: File) => void;
}) {
  const { result, file, url } = flow;

  if (result.kind === "http") {
    const tooBig = result.status === 413;
    return (
      <ServiceProblem
        title={tooBig ? "The file is larger than the upload limit" : result.status === 400 ? `${file.name} could not be graded` : `The grading service returned an error (HTTP ${result.status})`}
        body={tooBig ? "Choose a smaller photograph and upload it again." : result.status === 400 ? "Choose a JPEG or PNG fundus photograph and upload it again." : "Try the upload again. If it keeps failing, check the service log."}
        detail={result.detail}
        action="Choose another photograph"
        onAction={onAgain}
        meta={meta}
      />
    );
  }
  if (result.kind === "network") {
    return (
      <ServiceProblem
        title="The grading service stopped responding"
        body="The upload did not reach the service, so no estimate was produced."
        detail={result.message}
        action="Try this photograph again"
        onAction={() => onFile(file)}
        meta={meta}
        hint="If the service was restarted, wait for it to finish loading the model."
      />
    );
  }
  if (result.kind === "malformed") {
    return (
      <ServiceProblem
        title="The grading service sent a response this page does not recognise"
        body="No estimate is shown, because a partial response could be misread."
        detail={result.message}
        action="Choose another photograph"
        onAction={onAgain}
        meta={meta}
      />
    );
  }

  const r = result.data;

  // Declined: no retina. There is no grade to show, by design.
  if (!r.graded) {
    return (
      <div>
        <Steps at={3} />
        <h1 className="mt-6 text-3xl font-bold leading-tight sm:text-4xl">
          {r.guard.status === "not_a_fundus_photograph" ? "Not a usable retinal photograph" : "No grade produced"}
        </h1>
        <div className="mt-5 grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:items-start">
          <div className="flex items-start gap-4">
            {/* eslint-disable-next-line @next/next/no-img-element -- local object URL */}
            <img src={url} alt={`Uploaded file ${file.name}`} className="h-28 w-28 shrink-0 rounded-lg bg-viewer object-contain" />
            <p className="text-[0.95rem] leading-snug text-ink-2">Uploaded file: {file.name}</p>
          </div>
          <div className="space-y-6">
            <div role="status" className="notice-warn">
              <p className="max-w-[68ch] text-lg leading-snug">{r.guard.message}</p>
            </div>
            <button type="button" onClick={onAgain} className="btn-primary">
              <RotateCcw aria-hidden="true" className="h-4 w-4" />
              Upload a different image
            </button>
            <ReferralGuidance g={guidanceForDeclined(r.guard.status)} specialistHref="/specialists" />
            <AssistantPanel general />
            <Disclaimer items={r.disclaimer} />
          </div>
        </div>
        <Provenance meta={meta} />
      </div>
    );
  }

  return <GradedView meta={meta} r={r} file={file} url={url} onAgain={onAgain} />;
}

function GradedView({
  meta,
  r,
  file,
  url,
  onAgain,
}: {
  meta: Meta;
  r: PredictGraded;
  file: File;
  url: string;
  onAgain: () => void;
}) {
  const warned = r.guard.status !== "ok";
  const { lang } = useI18n();
  const [savedId, setSavedId] = useState<string | null>(null);

  // The record the PDF is built from, and what saving would keep.
  const draft = useMemo<SavedScreening>(
    () => ({
      id: r.result_id ?? "unsaved",
      createdAt: new Date().toISOString(),
      fileName: file.name,
      label: "",
      eye: "unspecified",
      result: r,
      meta: snapshotMeta(meta),
    }),
    [r, file.name, meta],
  );

  const g = guidanceForGraded(r.referable, r.guard, meta.reported_val_sens_at_spec95, r.quality);
  const specialistHref = `/specialists${savedId ? `?screening=${savedId}` : ""}${
    r.referable ? `${savedId ? "&" : "?"}referable=1` : ""
  }`;

  return (
    <div>
      <Steps at={3} />
      <div className="mt-6 flex flex-wrap items-baseline justify-between gap-4">
        <h1 className="text-3xl font-bold leading-tight sm:text-4xl">Estimate for {file.name}</h1>
        <button type="button" onClick={onAgain} className="btn-ghost">
          <RotateCcw aria-hidden="true" className="h-4 w-4" />
          Screen another image
        </button>
      </div>

      <div className="mt-7 grid gap-10 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:items-start">
        <div className="order-2 lg:order-1">
          <ImageViewer preprocessed={r.preprocessed_png} overlay={r.overlay_png} originalUrl={url} fileName={file.name} />
        </div>

        <div className="order-1 space-y-6 lg:order-2">
          {lang === "ur" && (
            <p className="rounded-lg border border-rule px-3 py-2 text-[0.9rem] text-ink-2">
              گریڈنگ سروس کے پیغامات انگریزی میں ہی، بالکل ویسے دکھائے جاتے ہیں جیسے لکھے گئے ہیں۔
            </p>
          )}
          {warned && <GuardNotice guard={r.guard} />}
          <QualityNotice quality={r.quality} />
          <Readout r={r} />
          {!warned && <GuardNotice guard={r.guard} />}
          <Disclaimer items={r.disclaimer} />
        </div>
      </div>

      <h2 className="mt-12 text-2xl font-bold">Next steps</h2>
      <div className="mt-4 grid gap-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:items-start">
        <ReferralGuidance g={g} specialistHref={specialistHref} />
        <ReportActions draft={draft} saved={savedId !== null} onSaved={(rec) => setSavedId(rec.id)} />
      </div>

      <div className="mt-8">
        {savedId ? (
          <AssistantPanel screeningId={savedId} onDownloadReport={() => downloadReport(draft)} />
        ) : (
          <AssistantPanel resultId={r.result_id} onDownloadReport={() => downloadReport(draft)} />
        )}
      </div>

      <Provenance meta={meta} />
    </div>
  );
}

// ------------------------------------------------------------------ problems
function ServiceProblem({
  title,
  body,
  detail,
  action,
  onAction,
  hint,
  meta,
}: {
  title: string;
  body: string;
  detail: string;
  action: string;
  onAction: () => void;
  hint?: string;
  meta?: Meta;
}) {
  return (
    <div role="alert">
      <h1 className="max-w-[30ch] text-3xl font-bold leading-tight">{title}</h1>
      <p className="mt-3 max-w-[62ch] text-lg leading-relaxed">{body}</p>
      <p className="mt-3 max-w-[70ch] border-l-4 border-rule pl-4 text-[0.95rem] text-ink-2">
        Service said: {detail}
      </p>
      {hint && <p className="mt-2 text-[0.95rem] text-ink-2">{hint}</p>}
      <button type="button" onClick={onAction} className="btn-primary mt-6">
        {action}
      </button>
      {meta && (
        <>
          <div className="mt-10">
            <Disclaimer items={meta.disclaimer} />
          </div>
          <Provenance meta={meta} />
        </>
      )}
    </div>
  );
}

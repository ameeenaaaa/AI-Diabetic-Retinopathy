# Architecture Decision Record

ADR-style log of every non-obvious choice. Format: date, decision, alternatives
considered, rationale, who approved.

**Rule:** any deviation from `docs/proposal.pdf` is logged here *and* flagged to the user.
Any data rows excluded from the pipeline are listed here, never dropped silently.

---

## DECISION-001 — Streamlit replaced by FastAPI + Next.js

- **Date:** 2026-08-20
- **Status:** **APPROVED** — supervisor confirmed 2026-08-24. No longer a pending
  deviation; the proposal's §9 and §5.10/Month 8 Streamlit references are superseded
  and the thesis states the change and its reasons rather than flagging it as open.
- **Deviates from proposal:** Yes — §9 (Tools and Technologies) and §5.10/Month 8
  (Milestones) name Streamlit.

**Decision.** The web-based diagnostic interface is built as a proper client/server
application — FastAPI + Uvicorn backend, Next.js (TypeScript) + Tailwind frontend — rather
than a Streamlit script.

**Alternatives considered.**
1. *Streamlit as proposed.* Fastest to build; but produces a script, not assessable
   software engineering work, and offers no API surface.
2. *Gradio.* Same class of limitation as Streamlit.
3. *FastAPI + a server-rendered Jinja template.* Lighter than Next.js, but gives up the
   component model and the TypeScript type-safety story.

**Rationale.**
- Separation of concerns between inference and presentation.
- A documented REST API that a hospital system could in principle consume.
- Real request handling, error states, and file-upload validation (MIME type, magic bytes,
  size and dimension limits) rather than a notebook-grade upload widget.
- A UI that can be assessed as software engineering work.
- Auto-generated OpenAPI docs at `/docs` — a thesis figure in its own right.

**The objective is unchanged.** The proposal's stated objective is "a web-based diagnostic
interface"; only the implementation is upgraded. Scope §6.1 ("Web-based deployment") is
satisfied either way.

**Approval.** User approved 2026-08-20 and will obtain written confirmation from
Mr. Ubaid Ur Rahman before Phase 7 begins. Phases 1–6 do not depend on the frontend and
proceed regardless.

---

## DECISION-002 — Python 3.12 toolchain (local 3.12.10 / Kaggle 3.12.13)

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No (proposal does not pin a Python version)

**Decision.** The project targets **CPython 3.12**. The recorded version pair is:

| Environment | Version | ABI tag | Compute |
|---|---|---|---|
| Local (Windows 11) | **3.12.10** | `cp312` | CPU only |
| Kaggle Notebooks (Linux) | **3.12.13** | `cp312` | CUDA (T4×2 / P100) |

The virtualenv is built with `py -3.12 -m venv .venv`. `requirements.txt` pins versions
that resolve on `cp312` for **both** win_amd64 and manylinux.

**Rationale.**
- The machine's *system default* interpreter is 3.12's successor, 3.14, which Kaggle does
  not run and which parts of the CV/DL stack do not yet ship wheels for. Building against
  it would break R6 (reproducibility) on day one.
- Patch-level differences within 3.12 (10 vs 13) do not affect wheel compatibility — both
  build as `cp312` — so the local/Kaggle pair is genuinely interchangeable for
  dependency resolution.

**Constraint recorded.** The system default 3.14 interpreter is **not to be modified or
referenced in any config file.** All local execution goes through `.venv`.

---

## DECISION-003 — No local GPU acceleration; Kaggle-first is absolute

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No (proposal §7.2 already names Colab/Kaggle GPU)

**Decision.** The local machine is treated as a **code-editing, split-inspecting, and
web-app-demo machine only.** All preprocessing, training, evaluation, and Grad-CAM
generation run on Kaggle Notebooks.

**Measured environment.** Intel Arc Pro Graphics; no NVIDIA adapter, no CUDA runtime,
`nvidia-smi` absent. 31.4 GB system RAM, 797 GB free disk.

**Alternatives considered.**
1. *Intel XPU / IPEX backend for PyTorch.* **Explicitly rejected by the user.** Would add a
   second, divergent compute path to debug and maintain, with worse `timm` coverage, in
   exchange for acceleration that is still far below a T4.
2. *Download EyePACS locally and train on CPU.* Disk space is actually sufficient
   (797 GB free), so the original disk-based rationale does not apply — but CPU-only
   training on 35k images across 5 ablation arms is not viable on any timeline.

**Rationale.** With no CUDA device, the Kaggle-first mandate is compulsory rather than a
convenience. This is why every script must read its dataset and output roots from config
(`configs/kaggle.yaml` vs `configs/local.yaml`) and never hardcode a path.

---

## DECISION-004 — APTOS author-provided split discarded

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No (proposal does not specify an APTOS split)

**Decision.** The `mariaherrerot/aptos2019` redistribution ships its own `test.csv` (and
sibling split files). **These splits are ignored.** All ~3,662 labelled APTOS images are
pooled and used as a single held-out external test set.

**Rationale.** The partitioning rule behind that redistribution is undocumented. Adopting
it would silently import an unknown split into a project whose headline contribution is
partitioning rigour. Pooling is both simpler and honest.

**Related limitation (to document in the thesis, not hide).** APTOS `id_code` values are
anonymised hashes with no recoverable patient linkage. Each image is therefore treated as
its own patient (`patient_id = f"aptos_{id_code}"`). This means APTOS cannot support a
patient-level split at all — a further reason to use it only as an external test set.

---

## DECISION-005 — Image size fixed at 224×224 for headline results

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No — proposal §5.1/§5.3 specify 224×224.

**Decision.** All headline results use **224×224**. A config switch for 384×384 is built
but runs only as an optional ablation, and only if GPU quota survives Phase 4.

**Rationale.** Matching the approved proposal keeps the contract intact. 384 would roughly
triple training cost per run against a fixed weekly GPU quota that must first cover five
imbalance arms across two architectures.

---

## DECISION-006 — Rare-class test support is thin; report intervals, not point estimates

- **Date:** 2026-08-20
- **Status:** Accepted — **known limitation, to be stated in the thesis**
- **Deviates from proposal:** No

**The limitation.** Only 445 patients in all of EyePACS have max grade 4. A 15% patient-level
test split therefore yields, measured from the generated splits:

| Split | grade-3 images | grade-4 images | max-grade-3 patients | max-grade-4 patients |
|---|---:|---:|---:|---:|
| train | 607 | 502 | 349 | 312 |
| val | 133 | 108 | 75 | 67 |
| **test** | **133** | **98** | **75** | **66** |

**Consequence.** 98 grade-4 and 133 grade-3 test images are enough to populate a confusion
matrix and to compute a stable QWK (which is dominated by the bulk classes). They are
**not** enough for a tight interval on per-class recall. A bootstrap 95% CI on grade-4
recall over n=98 will be wide — on the order of ±10 percentage points — and a difference of
a few points between two arms on that metric is **not** evidence that one arm is better.

**Decision.** For grades 3 and 4, `eval-analyst` reports **bootstrap 95% confidence
intervals, never bare point estimates**, in every table, figure, and sentence. Any claim of
an improvement on rare-class recall must be justified by non-overlapping intervals, not by
a difference in point estimates. This is briefed in `.claude/agents/eval-analyst.md`.

**Alternatives considered and rejected.**
1. *A larger test fraction (e.g. 25%) to thicken the rare classes.* Rejected — it would
   deviate from the proposal's stated 70/15/15 and shrink training data for the classes
   that most need it.
2. *Stratified k-fold cross-validation.* Would give tighter intervals, but multiplies GPU
   cost by k across 6 arms × 2–3 architectures against a fixed weekly quota. Recorded as
   future work.

**This is a good thesis paragraph, not a weakness to hide.** Honest interval reporting on a
thin rare class is a stronger methodological result than a confident point estimate.

---

## DECISION-007 — APTOS pooled as Arm F; all-or-nothing, never severity-selective

- **Date:** 2026-08-20
- **Status:** Accepted
- **Origin:** Supervisor feedback suggesting APTOS could help with class imbalance
- **Deviates from proposal:** Extends it. Proposal §5.1 names EyePACS only; APTOS was
  already scoped in `BOOTSTRAP.md` §3.2 as external validation.

**The question.** Would pooling APTOS into training materially relieve the class imbalance?
Settled with measured numbers rather than argument.

**Measured APTOS distribution** (from the labels CSVs only — no images downloaded; all
three author split files pooled per DECISION-004, 3,662 rows, 0 duplicate `id_code`):

| Grade | Count | Percent | EyePACS percent |
|---|---:|---:|---:|
| 0 | 1,805 | **49.29%** | 73.48% |
| 1 | 370 | 10.10% | 6.96% |
| 2 | 999 | 27.28% | 15.07% |
| 3 | 193 | 5.27% | 2.48% |
| 4 | 295 | 8.06% | 2.02% |
| **Total** | **3,662** | | |

Imbalance ratio 9.35:1, versus EyePACS's 36.45:1.

**Finding.** The user's prior was correct almost exactly: APTOS is imbalanced **in the same
direction** as EyePACS — 49.29% grade 0, adding 193 grade-3 and 295 grade-4 images against
1,805 additional grade-0. It is *less* skewed than EyePACS, but it is not a rare-class
supplement.

**Effect on the Arm F training pool** (EyePACS train + APTOS train):

| Grade | EyePACS train | + APTOS train | = Arm F | share before → after |
|---|---:|---:|---:|---|
| 0 | 18,073 | 1,264 | 19,337 | 73.51% → 71.23% |
| 1 | 1,728 | 259 | 1,987 | 7.03% → 7.32% |
| 2 | 3,676 | 699 | 4,375 | 14.95% → 16.11% |
| 3 | 607 | 135 | 742 | 2.47% → **2.73%** |
| 4 | 502 | 206 | 708 | 2.04% → **2.61%** |
| **Total** | 24,586 | 2,563 | 27,149 | |

**So: pooling barely moves the proportions** — grade 4 goes 2.04% → 2.61% — but it does add
real absolute rare-class data: **+41% more grade-4 images and +22% more grade-3 images.**
Whether that extra absolute volume outweighs the added domain shift is an empirical
question, which is precisely why it becomes an arm rather than an argument.

**Arm F definition.**
- **Train:** `data/splits/train.csv` + `data/splits/aptos_train.csv`
- **Validate:** `data/splits/val.csv` + `data/splits/aptos_val.csv`
- **Test:** `data/splits/test.csv` (**EyePACS only**), so Arm F stays directly comparable
  to arms A–E on an identical test set.
- APTOS is split by the **same procedure and the same seed**, treated as one image per
  patient (no linkage exists — DECISION-004).

**Constraint: all-or-nothing pooling.** If APTOS is pooled, **all of it is pooled.** Adding
only grades 3 and 4 is explicitly forbidden.

*Reasoning:* APTOS and EyePACS were captured on different camera hardware under different
acquisition protocols, so dataset origin is visible in the image — colour balance, field of
view, illumination, compression. If only grades 3–4 were imported, **dataset origin would
correlate with severity**, and the model could reach a high score by learning "this looks
like an APTOS camera" as a proxy for "this is severe." That is a domain artefact
masquerading as a clinical finding: it would inflate rare-class recall on any test set
containing APTOS images and collapse on EyePACS-only data.

> **CORRECTION, 2026-08-20 (leakage audit).** This decision originally said "pooling
> everything keeps origin uncorrelated with label." **That is wrong, and the table above
> refutes it.** APTOS is 8.06% grade 4 against EyePACS's 2.02%, which *guarantees* a
> correlation. Measured on the committed arm-F pooled training split:
>
> | grade | n | of which APTOS | P(aptos \| grade) |
> |---|---:|---:|---:|
> | 0 | 19,337 | 1,264 | 0.065 |
> | 1 | 1,987 | 259 | 0.130 |
> | 2 | 4,375 | 699 | 0.160 |
> | 3 | 742 | 135 | 0.182 |
> | 4 | 708 | 206 | **0.291** |
> | marginal | 27,149 | 2,563 | 0.094 |
>
> Monotonic, a 4.4x spread. All-or-nothing pooling **bounds** the correlation — importing
> only grades 3-4 would put it near 1.0 — but it does not remove it.
>
> **The balanced sampler amplifies the payoff.** One real balanced epoch (seed 7) lifts
> grade 4 from 2.6% of the gradient to about 20%, and 29% of those draws are APTOS. So
> "APTOS camera implies severe" is a shortcut worth several times more under arm F WITH
> the sampler than under arm F alone. The sampler is behaving exactly as §2.1 specifies;
> the confound is in the arm, not the mechanism.
>
> **Consequences, all binding:**
> 1. `describe_balance` emits a `p_aptos` column for pooled frames, so every arm-F run log
>    shows the correlation rather than leaving it to be rediscovered.
> 2. Arm F evaluation **must** report metrics broken down by source dataset. That is what
>    `DRDataset`'s returned index is for.
> 3. **Cross-arm selection uses arm F's val QWK restricted to the EyePACS val rows.**
>    Arm F's pooled val is a different population — n=5,818 with 9.5% APTOS, against
>    n=5,268 for arms A-E — and QWK is distribution-sensitive, so the pooled number is not
>    comparable to A-E's. Log both; select on the EyePACS-only one.
> 4. If arm F wins, the write-up must show the gain survives the per-origin breakdown.

`xai-engineer`'s Grad-CAM sanity check is the second line of defence here.

**Consequence — the trade-off to defend in the write-up.** Under Arm F, APTOS is consumed
as **training** data, so it **cannot also serve as the Phase 6 external validation set**
for that arm. There is no version of this where APTOS is both.

- **Arms A–E:** Phase 6 is unchanged — trained on EyePACS only, externally validated on all
  of APTOS. This remains the stronger thesis result, because a held-out *external* test set
  measures generalisation across domains.
- **Arm F:** gains rare-class training volume, loses its external validation set. It can
  only be evaluated on the EyePACS test set.

The write-up must state this explicitly and defend whichever is chosen as the headline
model. If Arm F wins on validation QWK, the honest framing is that it trades a
generalisation claim for in-domain performance.

---

## DECISION-008 — Split generated and audited

- **Date:** 2026-08-20
- **Status:** Accepted
- **Seed:** 42 (`configs/base.yaml` → `split.seed`, and written into each split CSV header)

**Decision.** Patient-level 70/15/15 split, stratified on each patient's max grade,
generated by `src/data/split.py` and committed as `data/splits/*.csv`.

**Result.** 17,563 patients → 12,293 train / 2,634 val / 2,636 test. All 35,126 images
assigned exactly once. Val and test retain the natural distribution (max drift from natural
< 0.6 pp on any class).

**Verification.** `tests/test_no_leakage.py` — **38 tests, all passing.**

### `leakage-auditor` verdict: **PASS** — cleared to commit

Independently re-verified from scratch (100 assertions, 0 failures), *without* relying on
`tests/test_no_leakage.py`, which was run only as a cross-check.

- **0 patient overlaps** across all six split pairs (EyePACS ×3, APTOS ×3). 0 image-path
  overlaps. All 17,563 patients carry exactly 2 rows, both in the same split.
- **35,126/35,126** EyePACS images reconciled by set-equality against
  `trainLabels.csv` — 0 missing, 0 extra. **3,662/3,662** APTOS images likewise; the
  author-provided split is genuinely dissolved (source-file × our-split crosstab is fully
  mixed, not diagonal).
- **Stratification confirmed on patient max-grade.** The counter-hypotheses — min grade,
  left-eye grade, floor(mean grade) — were each tested and *ruled out* by exact per-stratum
  counts. All **2,240** asymmetric patients are co-located; maximum-spread cases
  spot-checked (e.g. patient `10321`, left=4/right=0, both in `val`).
- **Natural distribution retained.** Max drift from natural: train 0.00114, val 0.00212,
  test 0.00640 — all < 0.01. Majority share > 0.73 in every split.
- **Determinism.** Two fresh re-runs produced byte-identical bodies (SHA-256 of
  comment-stripped content); the only diff is the `# generated:` timestamp. Seed 43 changes
  46.8% of assignments, so the seed is load-bearing.
- **Code review of `split.py`.** Index coverage/overlap brute-forced for n = 0…3,000;
  rounding brute-forced for n = 0…200,000 across 11 fraction triples. No defect found.

### Actions taken on the auditor's non-blocking observations

Four were fixed before this commit rather than deferred:

1. **Small-strata hole (fixed).** `assign_splits` had no minimum-per-split guarantee — at
   70/15/15 any stratum with n < 4 patients silently produced an empty val *and* test,
   i.e. an all-zero confusion-matrix column. Harmless today (smallest real stratum is 445
   patients) but a filtered subset or debug sample would have hit it quietly. Now raises
   `SystemExit`; verified to fire on a synthetic 3-patient stratum.
2. **Venv was off-spec (fixed).** The splits were first generated under `numpy 2.5.2` /
   `pandas 3.0.5` while `requirements.txt` pins `2.2.6` / `2.3.3` — an R6 gap, and
   `pandas` 3.0 changes exactly the copy-on-write and string-dtype machinery the manifest
   builder relies on. The venv was corrected and **the splits regenerated**. Assignments
   are byte-identical across the change (auditor's spot-checked patients land in the same
   splits), so only the provenance header differs.
3. **Version provenance (fixed).** numpy's `Generator` stream is not contractually stable
   across versions (NEP 19). Each split CSV header now records
   `# python: … numpy: … pandas: …`.
4. **Test-suite blind spots (fixed).** The suite checked totals against a *hardcoded
   integer*, so a complete-but-mislabelled manifest would have passed. Added: set-equality
   and label reconciliation against `trainLabels.csv`; an independent re-parse of
   `patient_id`/`eye`; a stratification test that *rules out* min-grade rather than merely
   asserting max-grade; an asymmetric-patient co-location test; a subprocess re-run
   determinism test; and seed-header checks extended to the three `aptos_*.csv` files.
   29 tests → **38**.

Remaining observation, accepted without change: `patient_id` dtype inference. EyePACS ids
are bare digits and would infer as `int64` while APTOS ids are strings, so an Arm F concat
could produce a mixed-type column. Already handled — `src/data/manifest.py` forces
`dtype={"patient_id": "string"}` alongside `comment='#'`, and it is the only supported
reader.

**Note for all readers of the split CSVs.** They carry a `#` provenance header recording the
seed, generator, git SHA, fractions, and class distribution. **Every reader must use
`pandas.read_csv(..., comment='#')`** or the header will be parsed as data.

---

## DECISION-009 — Ben Graham's local average is a normalised convolution over the retina mask

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No — the proposal specifies Ben Graham enhancement; this
  fixes *how* it is computed at the retina boundary.

**The defect.** Ben Graham's method is `alpha*img + beta*blur(img) + gamma` with
`alpha=4, beta=-4, gamma=128`. Computed naively, the Gaussian window near the edge of the
retina straddles the black surround, so `blur` is dragged toward zero while `img` is not.
`4*img - 4*blur` then blows up, ringing every image in a **white halo brighter than any
lesion**. Measured on the QA sample: mean brightness in the 0.85–0.99r annulus was
**1.44×** the inner-disc mean, and on grade-4 examples the halo washed out lesions that
are plainly visible once it is removed.

**Why it matters beyond appearance.** The halo is a constant artefact at a constant
location. A CNN can key on it, and Grad-CAM will light it up — which would corrupt the
Phase 5 sanity gate ("heatmaps on lesions, not borders").

**The fix.** The local average is computed as a normalised convolution over the retina
mask, `blur(img*mask) / blur(mask)`, so it averages only over pixels that were actually
imaged. Variants compared visually on 5 images (ideal-circle mask + plain blur, real mask
+ plain blur, real mask + normalised convolution); the last was clearly best and is what
`src/data/preprocess.py:ben_graham` implements.

Locked in by `tests/test_preprocess.py::test_ben_graham_does_not_ring_the_retina_edge`,
which fails if the edge/inner brightness ratio returns above 1.15.

---

## DECISION-010 — Square crop centred on the retina, not bounding-box-then-pad

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No — implementation detail of "circle crop".

EyePACS retinas are routinely **truncated top and bottom** by the sensor, so the
non-black bounding box is wider than it is tall. Padding that box to a square leaves
black bars inside the frame, and the retina then fills a fraction of the output that
depends on the **camera's aspect ratio rather than on the eye** — so the apparent scale
of a lesion varies by camera model, which is a spurious cue correlated with acquisition
site.

`square_crop` instead takes a square of side 2r centred on the retina, where r is its
larger half-extent, so the retina occupies a consistent fraction of every 224×224 output.
The mask is carried through the crop so image and mask cannot drift out of registration.

---

## DECISION-011 — Large-sigma Gaussian computed on a downscaled copy

- **Date:** 2026-08-20
- **Status:** Accepted
- **Deviates from proposal:** No — a performance optimisation with a measured error bound.

**The problem.** Ben Graham's sigma is `width/10`, so a 2560px-wide image needs sigma 256
and `cv2.GaussianBlur` builds a ~1537-tap separable kernel. **Measured: 30.8 s for one
image**, ~35 s/image over the QA sample, which projects to roughly **340 hours** for
35,126 images. The cache would never have been built.

**The fix.** A Gaussian that wide is pure low frequency, so it is computed on a copy
downscaled until sigma is 48px and then scaled back. Because sigma is itself proportional
to width, the working image is always ~480px wide regardless of source size.

**Measured error** on a 1920×2560 image, after the full `4*img - 4*blur + 128` (which
amplifies any blur error fourfold): **max 4/255, mean 0.29** — below JPEG q95 quantisation
noise, and smooth by construction, so it cannot add or remove lesion-scale detail.
Speed-up 145×. Re-measured by `tests/test_preprocess.py::test_large_sigma_blur_approximates_the_exact_blur`
rather than trusted from this note.

---

## DECISION-012 — Preprocessed cache is flat and split-agnostic

- **Date:** 2026-08-20
- **Status:** Accepted — **required by `leakage-auditor` before the cache build**
- **Deviates from proposal:** No

The cache is written as:

```
{processed_root}/eyepacs/{patientID}_{eye}.jpg
{processed_root}/aptos/aptos_{id_code}.jpg
```

**Deliberately NOT** `train/`, `val/`, `test/` subdirectories. Split membership is
resolved only from `data/splits/*.csv` at `Dataset` construction time. A split-shaped
cache would silently mismatch the CSVs after any re-split, and no existing test would
catch it.

The APTOS source path `train_images/train_images/{id}.png` is flattened for the same
reason: that directory structure **is** the author-provided split which DECISION-004
discards, and preserving it would smuggle a discarded partition back into the project.
The `aptos_` prefix prevents hash-named APTOS files from colliding with EyePACS
`{patientID}_{eye}` names in a flat namespace.

Enforced by `tests/test_preprocess.py::test_cache_layout_is_flat_and_carries_no_split_name`
and `::test_aptos_cache_path_discards_the_author_split_and_is_namespaced`.

---

## DECISION-013 — Quality flags are advisory, with fixed absolute thresholds

- **Date:** 2026-08-20
- **Status:** Accepted — **required by `leakage-auditor` before the cache build**
- **Deviates from proposal:** No

`scan_quality()` computes per-image pixel statistics (brightness, retina fraction,
clipping, darkness, centroid offset, saturation, focus, contrast) and `flags()` labels
suspect images.

Two constraints, both binding:

1. **Thresholds are fixed absolute constants, never percentiles over the dataset.** A
   percentile cutoff computed across all 35,126 images would let val and test influence
   which train images are flagged. They were calibrated against the 20-image QA sample,
   which is **drawn from the train split only**.
2. **Nothing is dropped.** Flags are advisory and exist to direct human attention. No
   image is excluded from any split without an entry in this file — see
   "Excluded data rows" below, which remains **None**.

**Focus had to be made resolution-independent.** A Laplacian is a per-pixel operator, so
on the same scene a higher-resolution capture scores *lower*. Measured natively across
the QA sample's 0.1–16 MP range, a 4.9 MP image scored 152.0 and a 16.1 MP image 1.9, and
a single absolute threshold flagged **19 of 20 images as blurred**, including obviously
sharp ones. The measure now resamples the retina core to a fixed 512px width first.
After that fix, `laplacian_var` separated cleanly: **0.5 / 1.6 / 1.9** for the three
known-degraded images against **4.3** for the lowest good one, so the threshold is 3.0.

That the pixel statistics independently rank the same three images last as *file size*
did — two criteria sharing no inputs — is a genuine cross-check on both.

---

## DECISION-014 — The retina mask keeps only the largest connected component

- **Date:** 2026-08-20
- **Status:** Accepted — raised by `code-reviewer`
- **Deviates from proposal:** No

The mask started as a plain brightness threshold, so any bright non-retinal object joined
the retina in the region whose extent `square_crop` centres on. Measured on a synthetic
fundus with a small specular blob in one corner, the crop side went **606 → 902 px** and
the retina fraction **0.788 → 0.364**: the retina rendered at roughly **0.67×** its proper
scale, shrinking every lesion by a third of its pixels. `status` stayed `"ok"` and the
output looked plausible — a scale error is invisible when there is nothing beside it at
the correct scale.

Effective lesion size in pixels is the single feature this pipeline exists to preserve, and
an inconsistent one across images is a scale nuisance variable the model would have to
learn around.

`retina_mask` now keeps only the largest connected component. The discarded area fraction
is recorded per image as `off_disc_bright_fraction` and raises a `bright-artefact` flag
above 0.15, so a *genuinely* split retina (a lens shadow cutting the disc in two) is
reported rather than silently halved. On the 20-image QA sample exactly one image trips
it — `3829_left`, which is the near-black one that has almost no retina to find.

`tests/test_preprocess_plumbing.py::test_bright_artefact_does_not_shrink_the_retina` locks
the crop side to within 4 px of the clean image's.

---

## DECISION-015 — The contact sheet renders the real cache file, at a matched retina scale

- **Date:** 2026-08-20
- **Status:** Accepted — raised by `code-reviewer`
- **Deviates from proposal:** No

The sheet is the artefact the user approves the whole 35,126-image cache from, so it must
show what will actually be on disk. The first version did neither of those things:

1. **The "before" panel was downsampled below the "after" panel.** The original was fitted
   into the panel box while the processed image was a native 224 px; measured across the
   sample the retina occupied **139–203 px** against 224, so every pair was biased
   **0.62×–0.91×** in preprocessing's favour. Some of the apparent gain in sharpness was
   just the left panel being smaller. The original is now square-cropped from native pixels
   and rendered at the same retina scale.
2. **The "after" panel was an in-memory recomputation, not the cached JPEG.** Measured, the
   q95 round-trip costs mean **3.60/255** and max **64/255**, and lifts **39.3%** of the
   masked surround off exact zero. The sheet approved a file that was never written.
   `--cache-root` is now required and the panel is the decoded cache file.

A third panel was added: a 3× detail crop, original above processed, so the fine structure
the enhancement is meant to reveal can be judged rather than inferred from a 224 px
thumbnail.

---

## DECISION-016 — The retina mask is eroded 2.5% before the final re-mask

- **Date:** 2026-08-20
- **Status:** Accepted — user decision at the Phase 2 sign-off gate
- **Deviates from proposal:** No

### The artefact

Ben Graham's enhancement subtracts a local mean at sigma = width/10. The retina's own
optical vignetting falls off far faster than that, so the enhancement amplifies the
boundary falloff into a bright rim. Measured over the 20 cached QA images, mean
|pixel − 128| in the outer annulus (0.90–1.00 r) against the interior (< 0.85 r) was
**1.61× on average and up to 2.83×** (`1776_left`).

This is **not** the halo DECISION-009 fixed. `code-reviewer` confirmed the normalised
convolution matches the exact masked form to within 1/255. The rim is real optical
structure in the source, amplified by design.

### The three options

| Option | Rim | Area cost | Verdict |
|---|---|---|---|
| **Leave it** | 1.61× | 0 | A high-contrast ring at a fixed radius in all 38,788 images, uncorrelated with grade. A CNN can learn to ignore it, but it is the strongest edge in the frame and spends capacity. |
| **Ben Graham's 0.9 r mask** | 1.32× | **19% of retinal area** | Rejected. Grade 4 is already the thinnest class — 98 test images (DECISION-006) — and proliferative disease appears in the periphery, which is exactly what a fixed 0.9 r cut discards. |
| **Erode 2.5% of the equivalent radius** | see below | **3.2%** | **Chosen.** |

**Rationale (user, 2026-08-20):** full 0.9 r masking costs 19% of retinal area including
the periphery where proliferative disease appears, and grade 4 is already the thinnest
class at 98 test images. Erosion removes the vignetted pixels themselves rather than a
fixed fraction, so the cost tracks the artefact.

### Residual — the number the user asked to be recorded, and it is not the flattering one

**A fixed 0.90–1.00 r annulus barely moves: 1.610 → 1.516 at 2.5% erosion.** That metric
is degenerate under erosion, because trimming the boundary also moves which pixels fall
into a fixed radial band — the rim follows the boundary inward.

Measured properly, as a profile of mean |pixel − 128| against **depth from the actual
retina edge** in units of the equivalent radius, over the same 20 images:

| depth from edge | mean \|dev\| | vs interior |
|---|---|---|
| 0.000–0.010 | 76.10 | **2.61×** |
| 0.010–0.025 | 54.29 | 1.86× |
| 0.025–0.050 | 46.36 | 1.59× |
| 0.050–0.075 | 39.63 | 1.36× |
| 0.075–0.100 | 33.08 | 1.14× |
| 0.100–0.150 | 26.53 | 0.91× |
| > 0.150 | 22.9–29.1 | ≈ 1.00× |

So the excess is steep and shallow: it decays to the interior level by roughly **10% of
the radius**. Erosion at 2.5% removes the two worst bands — the outermost pixels drop from
**2.61× to ≈1.59×**, about **63% of the peak excess** — but leaves a ≈1.6× edge at the new
boundary. It suppresses the peak; it does not eliminate the rim. Eliminating it entirely
needs the ~10% cut that is Ben Graham's 0.9 r, at the area cost that was rejected.

**This was reported to the user before the cache build**, as they asked. 2.5% stands.
The knee of the profile is at 0.05 (1.36×, ~9.5% area) if the trade is ever reopened.
**It will not be reopened on aesthetics** — only on evidence, and the specified evidence
is the Phase 5 Grad-CAM sanity check showing the model keying on the rim.

### Implementation

`erode_mask(mask, frac)` uses a **distance transform**, not `cv2.erode` with a fixed
kernel: EyePACS retinas are routinely truncated top and bottom, and a distance transform
peels a constant depth off whatever shape is actually present. It also scales with the
image, so a 400px source and a 4928px source lose the same *fraction*.

Two properties are test-locked:

- **The erosion applies only to the final re-mask.** The normalised convolution still
  averages over the full mask, so every retained pixel is bit-identical to what it would
  have been with no erosion (`test_erosion_only_trims_and_never_alters_a_retained_pixel`).
  Erosion removes; it never alters.
- `scan_quality` still measures the **un-eroded** mask, so DECISION-013's fixed absolute
  thresholds keep the calibration they were set with.

One accepted cost: on a retina truncated by the sensor, the erosion also trims ~2.5% along
the straight cut edge, where the pixels are valid retina rather than vignetting. At 224px
that is a ~3px strip, and special-casing it would mean detecting which boundary segments
are optical and which are the sensor — complexity out of proportion to the loss.

`configs/base.yaml` → `preprocess.mask_erode_frac: 0.025`.

---

## DECISION-017 — Partitioning invariants are enforced at every layer, not documented at one

- **Date:** 2026-08-20
- **Status:** Accepted — `leakage-auditor` returned **FAIL / CHANGES REQUIRED** on the
  Phase 3 data layer
- **Deviates from proposal:** No

The audit found four blockers, three of them demonstrated by execution rather than
inferred. All are fixed and each has a regression test.

**1. `reconcile_cache` certified a leaking partition with exit code 0.** Its R1 check
compared *cache paths* across splits. A patient with the left eye in train and the right
eye in test produces two different filenames, two different cache files, zero collisions
and zero orphans — so the check passed, and the tool the auditor had mandated as the
pre-training gate blessed the textbook R1 violation. **No count of files can see this**;
patient identity has to be compared directly. There is now a check on `patient_id`, run
first, comparing split *roles* so that arm F's `train` + `aptos_train` are correctly
treated as one side of the boundary.

**2. The sampler's val/test guard was a substring blocklist, and it failed open.**
Measured: `holdout`, `development`, `tuning`, `screening_2026` were all accepted; a frame
with the `split` column dropped skipped the check entirely; an all-NaN column emptied the
set via `dropna()` and also skipped it. The last two were live, not hypothetical, because
`DRDataset` requires only `{image_path, label, dataset}` — a frame that was a valid
Dataset input was a frame with no guard. Replaced by an **allowlist**,
`TRAIN_SPLIT_NAMES = {"train", "aptos_train"}`, with a missing column and a NaN value both
counted as violations. A blocklist fails open on every name nobody thought of.

**3. `build_loaders` never checked R1, and the test suite's headline fixture violated it.**
`load_arm_splits` checks patient disjointness, but every path that calls `load_split`
directly bypasses it. `build_loaders` is the one function that sees all three frames at
once. It now asserts the three pairwise `patient_id` intersections. The audit also found
that `tests/test_dataset.py` **constructed a 100-patient overlap as its R2 fixture and was
green** — which is itself the proof the assertion was missing. The fixtures now use
disjoint patients, and `test_loaders_refuse_a_partition_that_shares_patients` locks it.

**4. Arm F's origin/severity correlation is real and was documented as absent.** See the
correction inside DECISION-007.

Also fixed, from the same audit:

- **R3:** `build_loaders(include_test=False)` by default. `load_arm_splits` returns three
  frames, so the natural call passed three and a live test loader existed for the whole of
  training. Touching the test set should be an act, not an inheritance.
- **The returned index was positional but sold as a join key.** Against a caller frame
  with a shuffled index, `.loc[idx]` returned a different row than the model saw
  (measured: `ds[5]` reported `5_left.jpeg`, the row actually loaded was `142_left.jpeg`).
  `DRDataset` now refuses a non-RangeIndex frame; the documented join is
  `loader.dataset.df.iloc[idx]`.
- **Physical oversampling was accepted in silence.** `pd.concat([train] + [rare] * 8)`
  produced 256 duplicated rows inside a Dataset with no complaint, while the module
  docstring claimed the forbidden operations were "not expressible." §2.1 forbids
  duplicated rows *in any manifest*; `tests/test_no_leakage.py` enforced that on the
  committed CSVs only. `DRDataset` now asserts `image_path` uniqueness, and the
  overclaiming docstring is gone — a safety claim that is not true tells the next reviewer
  not to check.
- **NaN labels** survived construction and failed at the first draw of the first epoch, on
  Kaggle. Refused at construction.
- **Half-specified normalisation** (`mean` without `std`) silently reverted *both* to
  ImageNet, discarding the caller's explicit value. Now raises.
- **Cache provenance.** `reconcile_cache` was content-blind: only `image_size` was
  verified, so a cache half-built before DECISION-016 and half after — two different
  `mask_erode_frac` values, two image domains in one directory — reconciled perfectly
  clean. `preprocess.py` now appends a `_cache_provenance.json` sidecar (full config, git
  SHA, source root, count) per invocation, and reconciliation compares every field.
- The stats CSVs are now **set-compared** against the split rows rather than read only for
  a status column, the split headers are checked to share a seed (DECISION-008), and the
  decode sample is **stratified by dataset** — unstratified, APTOS got ~9% of the checks
  purely for being ~9% of the cache, and APTOS is the half whose source format differs.

**The principle.** Every one of these passed review at the layer where it was written and
failed at the layer where it was used. Invariants get asserted at the point of use, by
code, with a test that fails when the assertion is removed.

---

## DECISION-018 — Four images have no detectable retina; all four stay in their splits

- **Date:** 2026-08-21
- **Status:** Accepted
- **Deviates from proposal:** No

The full cache build finished with **38,784 of 38,788 images at `status: ok`** and four at
`ok:no-retina`. `retina_mask` found no illuminated region in these frames, so
`preprocess_image` took its documented fallback: the image is resized to 224x224 **without
the square crop, without Ben Graham, and without the surround mask**.

| image | split | patient | eye | label |
|---|---|---|---|---:|
| `32253_right` | **train** | 32253 | right | 1 |
| `34689_left` | **train** | 34689 | left | 0 |
| `43457_left` | **train** | 43457 | left | 1 |
| `1986_left` | **val** | 1986 | left | 0 |

All four patients have both eyes in the same split, so R1 is untouched. The other eye of
each patient processed normally.

**They stay in their splits.** Dropping a row is never a neutral act here: removing
`1986_left` would silently rebalance the validation split, which is an R2 violation by
omission, and it would make the val set a slightly different population from the one every
other arm is measured on. The "Excluded data rows" section below therefore still reads
**None**.

**What this costs.** Those four cache entries are in a different image domain from the
other 38,784 — unenhanced, uncropped, aspect-distorted. Three are in train, where they are
four images out of 24,586 and will be treated as noise. The one that matters is
**`1986_left` in val**: it is a validation image the model will almost certainly get wrong,
and it is 1 of 5,268, so it can move validation accuracy by at most 0.019 percentage
points. That is far below the noise floor of the QWK bootstrap and changes no decision.

**Do not "fix" these by re-running with a lower mask threshold.** The threshold is a fixed
absolute constant by the leakage auditor's binding condition (DECISION-013); tuning it
until four specific images pass is fitting a preprocessing parameter to individual images,
and those images are in the data the model is selected on.

They are worth looking at again in Phase 5: if the Grad-CAM panel includes one, it will
show the model attending to something that is not a retina, which is a useful negative
example for the write-up rather than a defect.

---

## DECISION-019 — Pins follow the Kaggle image, and the image is the environment of record

- **Date:** 2026-08-21
- **Status:** Accepted
- **Deviates from proposal:** No

The first real Kaggle run measured the CPU image and it does not match what
`requirements.txt` pinned:

| package | was pinned | Kaggle CPU image (2026-08-21) | Kaggle **GPU** image (2026-08-22) | now pinned |
|---|---|---|---|---|
| numpy | 2.2.6 | **2.0.2** | 2.0.2 | 2.0.2 |
| pandas | 2.3.3 | 2.3.3 | 2.3.3 | 2.3.3 |
| opencv | 4.12.0.88 | **4.13.0** | 4.13.0 | 4.13.0.92 |
| torch | 2.9.1 | **2.10.0+cpu** | **2.10.0+cu128** | 2.10.0 |
| torchvision | 0.24.1 | **0.25.0** | **0.25.0+cu128** | 0.25.0 |
| timm | 1.0.28 | **1.0.26** | 1.0.26 | 1.0.26 |

**The GPU image measured 2026-08-22 matches the CPU image version for version**, differing
only in the CUDA build tags (`+cu128`). That is the good case and it means one set of pins
describes both environments; it was not safe to assume in advance, which is why every
notebook prints its versions.

**The Kaggle image wins.** Never `pip install` torch over the preinstalled build — it is
built against that image's CUDA and replacing it is the fastest way to lose a session to
a broken driver stack. So the pins move to match the image, and the local machine installs
the same versions, which is what makes a locally-inspected result and a Kaggle result the
same artefact (R6).

The cache was built under the image's versions, not under the old pins. That is fine and
does not require a rebuild: the preprocessing output is deterministic per image and the
provenance sidecar records the config, which is the thing that governs the pixels.

**The GPU image was measured on 2026-08-22 and did not differ** — see the column above.
Cell 1 of every notebook still prints its versions, and if a future image differs this
table gains a column rather than the pins being edited from memory. What must not happen is a pin being
edited from memory instead of from a printed version report.

`timm` 1.0.26 vs 1.0.28 is the one worth watching: `normalisation()` reads
`default_cfg` at runtime rather than hardcoding constants, so a change in timm's metadata
is picked up automatically instead of silently disagreeing with a literal in a config.

---

## DECISION-020 — Kaggle input mounts are resolved, not assumed

- **Date:** 2026-08-21
- **Status:** Accepted
- **Deviates from proposal:** No

Kaggle changed where attached datasets appear. Measured on the Phase 2 build:

    was:  /kaggle/input/{slug}/
    now:  /kaggle/input/datasets/{owner}/{slug}/

and `/kaggle/input` is read-only, so nothing can be symlinked *into* it — the workaround
during the build was to symlink into `/kaggle/working/inputs/`.

Hardcoding either layout is how the next notebook breaks. `src/data/kaggle_paths.py`
resolves a dataset by trying the known layouts in order and raising with the actual
directory listing when none matches, so a third layout costs one line here instead of a
lost session. `configs/kaggle.yaml` records the current canonical paths, and the resolver
is what code actually calls.

This is exactly the class of thing CLAUDE.md S3 means by "every script is path-agnostic":
the dataset root belongs in config and, where the platform can move it, behind a resolver.

---

## DECISION-021 — The cache is published as ONE verified archive, never a loose tree

- **Date:** 2026-08-21
- **Status:** Accepted — forced by a real failure
- **Deviates from proposal:** No

### What happened

The Phase 2 build ran correctly. All 38,788 images were written, reconciliation passed,
the leakage tests were green, and the measured size was 0.836 GB. **Kaggle caps a
notebook's saved OUTPUT at 500 files**, so the publish step kept **499 of 38,788 images**
— 1.3% — and said nothing. `/kaggle/working` is wiped between sessions, so the other
38,289 were gone, along with 2.5 hours of compute. `fyp-dr-eyepacs-224` never existed.

**The build was right and the packaging was wrong**, which is why every in-session check
passed. Reconciliation ran against the live tree, before the boundary where the loss
happened. Nothing in the pipeline was looking at the artefact that would actually survive.

### The rule

**Pack to one file, verify the archive, then delete the source — in that order, inside the
same session.**

1. `src/data/archive_cache.py pack` zips the cache with `ZIP_STORED` (the payload is
   38,788 JPEGs; deflate spends minutes to save low single digits) into
   `fyp-dr-eyepacs-224.zip`, with `splits/`, both stats CSVs and
   `_cache_provenance.json` inside it, so the published dataset describes itself.
2. It **refuses to pack a short source tree** — the expected image count is checked before
   a byte is written. Packing a short tree and verifying the archive against that same
   short tree would agree with itself perfectly.
3. `verify_archive` then reads the **central directory back** and checks the image count,
   the sidecars, zero-byte entries, and the total size against 0.836 GB. That is what a
   consumer reads, and it is exactly the check that would have caught 499.
4. Only after verification passes does the notebook delete the loose tree. If verification
   fails, the tree is still there and the session must not end.
5. One file is under any file-count cap, and the count is asserted again at the end of the
   cell: if `/kaggle/working` holds more than 400 files, it warns.

Training reverses it: `unpack` extracts to `/kaggle/working` and **re-counts the extracted
images**, because "the archive was complete" and "the extraction completed" are different
claims, and training depends on the second.

`tests/test_archive.py` includes the regression directly — an archive rebuilt holding 5 of
20 images, which `verify_archive` must reject.

### Kaggle API vs notebook output — considered, and the notebook output wins

Pushing straight to a dataset from the notebook via `kaggle datasets create` was the
obvious alternative. It needs, and cell 5 does not:

- **Internet ON** for the whole build session, which is otherwise unnecessary — the
  preprocessing pipeline has no network dependency at all.
- **Credentials in the notebook**, via Add-ons → Secrets (`KAGGLE_USERNAME`, `KAGGLE_KEY`).
  Never `kaggle.json` in the repo, which `.gitignore` already forbids.

Its one real advantage is that the notebook can confirm the dataset landed **while the
session is still alive**, instead of trusting a UI step afterwards — which is precisely
what failed. That is a genuine argument, and it is why the API version is kept as an
optional cell 5b rather than dismissed.

**The manual publish is still the recommendation**, because the archive removes the
failure mode the API was going to protect against: once the output is a single verified
file, the cap cannot truncate it, and "create a dataset from one file" is a step with
nothing to silently drop. Adding a credential and a network dependency to a 2.5-hour
CPU-only job buys a confirmation that a verified single file no longer needs. The API
route also has upload behaviour this project has not tested — in particular whether Kaggle
re-extracts an uploaded archive into the dataset — and the middle of a rebuild is the
wrong time to find out.

**Revisit if** the manual publish ever fails again, or once arms A–F make dataset
publishing a routine step rather than a one-off.

### The general lesson, worth more than the fix

Every check in Phase 2 ran against the artefact **in the session**, and the thing that
broke was the artefact **that left the session**. A verification that does not run on the
bytes that survive is a verification of something else.

---

## DECISION-022 — No notebook command line runs before something has executed it

- **Date:** 2026-08-21
- **Status:** Accepted — forced by a third lost session
- **Deviates from proposal:** No

### What happened

The Phase 2 rebuild ran for **8.1 hours** and died in cell 5 with:

    archive_cache.py: error: argument cmd: invalid choice: '/kaggle/working/processed'

A missing `pack` subcommand, rejected by argparse in 0.0 seconds — after the build was
finished, after reconciliation had passed, after `READY TO ARCHIVE` had printed.
`/kaggle/working` is wiped, so all of it went.

**Three sessions, about 13 hours, none of it lost to the modelling.** DECISION-021 fixed
the truncation and this failed one layer further out: the fix itself was invoked wrongly.
Both copies in the repo — `notebooks/phase2_build_cache.py` and the runbook — contain
`pack`, so what ran had drifted from what was written, and nothing anywhere would have
noticed either way.

### The actual defect

**Notebook cells were the only executable code in this project that nothing imported,
nothing type-checked, and no test ran.** `archive_cache.py` had 13 unit tests. Its CLI had
never once been invoked the way the notebook invoked it. Every other layer here is
defended by tests that run on every change; the cells are strings in a docstring, and they
are simultaneously the code that runs **last**, **once**, **after hours of compute**, on a
machine that then erases itself. That is the worst possible combination, and it was the
least defended.

### The rule

**Every command line a notebook will run is validated against the real parser of the
module it calls, and the packaging path is executed for real, before any long work
starts.**

Four parts, and each covers a hole the others do not:

1. **`build_parser()` is split out of `main()`** in `preprocess`, `reconcile_cache`,
   `archive_cache` and `train`. A parser that only exists inside `main()` cannot be
   checked without running the program.
2. **`src/data/notebook_check.py`** reads `CELLS` out of every `notebooks/*.py`, extracts
   each `[sys.executable, "-m", ...]` list — including one assigned to a variable and run
   from another cell — substitutes a placeholder for values only known at runtime, and
   feeds the rest to the target module's parser. It also binds every direct call into
   `src.*` (`unpack(...)`, `resolve_input(...)`) against the real signature, because not
   every mistake is a subprocess and argparse never sees those.
3. **`--self-test` runs pack → verify → unpack for real** on a three-file temporary
   directory. This is the part that matters: an inspection proves the arguments are
   shaped right; only an execution proves the path works. It takes about a second.
4. **`tests/test_notebook_cells.py`** runs all of it on every test run, and includes the
   8.1-hour failure verbatim as a negative case — a `src.data.archive_cache` invocation
   with the subcommand removed, which `check()` must reject. A checker that cannot fail
   proves nothing.

### The paste is what runs, so the paste is what gets checked

The repo's copy of a cell is not what executes on Kaggle — a **paste** is, and the paste
is what drifted. Two things follow, and both are now in place:

- **Cell 1 of every notebook runs `notebook_check --all --self-test`.** It costs seconds
  and it happens before anything expensive.
- **The archive command is built and validated in cell 1, as `PACK_CMD`, and cell 5 runs
  only the variable.** The list that executes is the list that was checked, in the same
  pasted notebook, in minute one. Retyping the command in cell 5 is exactly how the
  subcommand went missing, so cell 5 no longer contains a command to retype.

### The general rule, which outlives this bug

Each of the last three failures was in the layer *around* the work rather than the work
itself: output packaging, then mount layout, then an argument list. The pattern is that
**the glue is the least-tested and most expensive part of the system**, because it runs
once, at the end, where a failure costs everything before it. Anything that runs last
gets tested first, and anything that cannot be tested cheaply gets executed cheaply on a
toy input before it is trusted with a real one.

---

## DECISION-023 — The cache root is found by shape, never by path

- **Date:** 2026-08-21
- **Status:** Accepted
- **Deviates from proposal:** No

### What happened

The Phase 2 rebuild worked. `ARCHIVE VERIFIED`, 38,797 entries, 0.852 GB, reconciliation
clean, published as `rah098/fyp-dr-eyepacs-224` v1 at 918.08 MB.

**Kaggle then auto-extracted the archive when it created the dataset.** The single
verified `.zip` that DECISION-021 exists to produce is not a `.zip` once it is mounted:
the dataset shows a `fyp-dr-eyepacs-224/` folder holding 38.8k files, with
`aptos_stats.csv` and `processed_stats.csv` beside it. Phase 3's cell 1 looked for
`MOUNT/*.zip` and then fell back to `MOUNT/processed`, and the real tree is neither.

That would have failed at the top of the training notebook rather than after hours of
work, so it was cheap this time. It is the same class of mistake as the last three.

### The rule

**Three layouts have now been observed for one artefact**, because the platform reshaped
it each time:

| | layout |
|---|---|
| The build writes | `/kaggle/working/processed/{eyepacs,aptos,splits}` |
| The archive holds | `processed/...` inside one `.zip` |
| The published dataset mounts | `fyp-dr-eyepacs-224/processed/...`, zip gone, CSVs beside it |

Predicting the fourth is a bet with a session on it, so the code stops predicting.
`find_cache_root` searches for the **shape** — a directory with `eyepacs/` and `aptos/`
under it that actually contain images — breadth-first from the mount, shallowest match
wins, and raises with the real directory listing when nothing matches. `resolve_cache`
wraps it: extract if there is a zip, otherwise locate in place, and **verify the image
count either way** before returning a path.

This is the same principle as DECISION-020's mount resolver, one level further in. Both
exist because a hosting platform's directory conventions are not a stable interface, and
`cache_relpath` is: it writes `eyepacs/<stem>.jpg` and `aptos/aptos_<stem>.jpg`, so the
cache root is definitionally the directory those sit under. That fact survives any
renaming or re-nesting done around it.

`python -m src.data.archive_cache locate --mount <path>` answers "where is it, and is it
complete" from a shell, without a notebook.

`tests/test_archive.py` covers every observed layout by name, including the one Kaggle
actually published, plus a nested copy (shallowest wins), a half-extracted tree with the
right directory names and no images, and a short cache that must be refused rather than
returned.

---

## DECISION-024 — Every arm's real path is exercised, not just its components

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No

The arm A smoke run failed twelve seconds in:

    AttributeError: 'RandomSampler' object has no attribute 'weights'
        src/data/sampler.py:168 in describe_balance, from src/train/train.py:187

`describe_balance` tested `if sampler is None` to decide whether to model a weighted draw.
That is the wrong question. `build_sampler` returns `None` for an unbalanced arm, but
`build_loaders` then passes `shuffle=True` and **`DataLoader` substitutes a
`RandomSampler`** — so what reaches `describe_balance` is a sampler object with no
weights, not `None`.

**Arm A is the only arm that never gets a weighted sampler.** Every existing test called
`build_sampler` directly and passed its return value straight to `describe_balance`, so
the `None` branch was well covered and the branch that actually runs under arm A had never
executed. The diagnostic print was the only thing broken; everything before it was correct
— 11.18M parameters 100% trainable, timm normalisation, sane class counts, leakage gate
green.

`describe_balance` now duck-types on `.weights`: anything that cannot reweight draws the
natural distribution by definition. The table also states which sampler it saw and notes
`drawn == natural` explicitly, because an arm whose sampler silently did nothing and an
arm that correctly draws naturally otherwise produce identical tables.

**The audit that followed.** Every branch on arm configuration in the train/eval path,
and whether it had ever run:

| Branch | Arms | Was it exercised? |
|---|---|---|
| `describe_balance` weighted vs natural | A/C/E vs B/D/F | **No** — the bug |
| `predictions_from` softmax vs ordinal | A-D,F vs **E** | Unit-tested, never inside `fit`/`evaluate` |
| `build_loss` weighted CE | **C** | Unit-tested, never inside `fit` |
| `metrics_by_dataset` pooled origins | **F** | Never — and arm F runs last, so it would have first executed at the end of the whole ablation |
| `build_loaders` `shuffle=(sampler is None)` | all | Yes |
| `build_loss` weights+sampler refusal | all | Yes |

Four of six branches were reachable only by an arm that had not been run. All four now
have end-to-end tests through the real call chain — `build_loaders` → `loader.sampler` →
`describe_balance`, and `fit`/`evaluate` with the ordinal head and with a weighted loss.
`metrics_by_dataset` was extracted out of `main()` to make it testable at all, and its
test includes a shuffled evaluation order, because that index is positional and joining it
with `.loc` would silently mix the two origins.

**The rule.** A component tested in isolation is not the same thing as an arm's path
tested end to end. Where behaviour branches on configuration, the test parametrises over
the real configs rather than over hand-built arguments — `tests/test_train.py` reads
`configs/arm_*.yaml` and asserts the sampler kind it finds, so a config change that
invalidates the test fails loudly instead of quietly bypassing it.

This is the same shape as DECISION-022: the least-run path is the most expensive one, and
it is cheapest to run it deliberately on synthetic data first.

---

## DECISION-025 — `train.main()` runs end to end locally before any session starts

- **Date:** 2026-08-22
- **Status:** Accepted — forced by the third consecutive failure inside `main()`
- **Deviates from proposal:** No

### What happened

Three Kaggle sessions in a row died inside `src/train/train.py`, each one step further in:

    1. describe_balance   AttributeError: 'RandomSampler' object has no attribute 'weights'
    2. yaml.safe_dump     RepresenterError: cannot represent an object '2.10.0+cu128'

`torch.__version__` is a `TorchVersion`, a `str` **subclass**, and `yaml.SafeDumper`
dispatches on **exact type**, not `isinstance` — so it refuses. Same for torchvision's.

The fix is not to special-case torch. **Nothing reaches `safe_dump` unless it is a
primitive**: `to_primitive` recursively coerces the whole run config, because the next
exotic type will be a numpy scalar from a YAML file, a `Path`, or an enum from a library
nobody has added yet.

### The actual defect, again

Every one of these was in `main()`, past where the unit tests reach. `fit`, `evaluate`,
`build_loaders`, `build_loss`, `describe_balance`, the metrics — all green, all along.
**`main()` itself had never once executed start to finish.** It was the only substantial
function in the project with no test, and it was the function every session ran first.

That is the same shape as DECISION-022, where notebook cells were the untested glue. The
common thread across five failures now: **the least-tested code is whatever runs last and
costs most, because it is the code that is hardest to run cheaply — which is exactly why
it has to be made cheap to run.**

### The rule

`python -m src.train.smoke` builds a throwaway 90-image cache and a patient-disjoint split
trio with real provenance headers, then calls **the real `main()` through its real argv**
and checks that `config.yaml` and `metrics.json` come out well-formed. About 20 seconds
per arm on CPU, no network, no GPU, no real data.

Three flags on `train.py` make it possible, and all three are recorded in the run config
so a smoke run can never be mistaken for a result:

| flag | why |
|---|---|
| `--splits-root` | point the real `main()` at a synthetic partition; `train.py` prints a loud warning and `config.yaml` records the path |
| `--no-pretrained` | no network in the test; it changes what a run measures, so it sets `is_smoke_run` |
| `--limit-train` | already existed; same treatment |

`config.yaml` gains `is_smoke_run` and `metrics.json` gains `is_smoke_test`, both true if
any of the three was used.

**It runs in three places**: `tests/test_train_smoke.py` (arms A and F, ~1 min, the
slowest tests in the suite and worth it), cell 1 of the Phase 3 notebook before anything
is spent, and `--all-arms` by hand before a real session.

**Arm A and arm F are the pair that matters.** A has no sampler and one origin; F has a
weighted sampler and two. Between them they touch every branch in `main()`. Arms B–E are
covered at unit level and by `--all-arms`.

### What building the fixture immediately caught

Arm F could not run at all: the fixture had no APTOS splits. Arm F is the last arm in the
ablation, so the real first execution of that path would have come after five other arms'
worth of GPU time. The fixture now writes `aptos_{train,val,test}` too, with hash-like ids
and one image per patient per DECISION-004, and the arm-F smoke shows the `p_aptos` column
DECISION-007 requires.

### What it deliberately does not do

It asserts **nothing about the score**. Twelve images per class cannot produce a meaningful
QWK, and asserting one would make this a flaky test instead of a wiring check. It asserts
the pipeline runs and its artefacts are readable. The collapse detector fires on every
smoke run, correctly, and that is expected rather than a failure.

---

## DECISION-026 — The collapse rule is severity-aware; Phase 3 acceptance follows it

- **Date:** 2026-08-22
- **Status:** Accepted — user challenge to a blocking verdict, upheld
- **Deviates from proposal:** No. CLAUDE.md §2 says "stop and diagnose", and this is the
  diagnosis. The rule's *trigger* is refined; its purpose is unchanged.

### What prompted it

The Phase 3 baseline (arm A, ResNet18, 8 epochs, best at epoch 6) produced:

| | |
|---|---|
| val QWK | **0.6138** [0.5859, 0.6421] |
| accuracy | 0.7965 (majority rate 0.7369, so **+6.0 pp**) |
| balanced accuracy | 0.4163 |
| referable sensitivity / specificity | 0.5131 / 0.9804 |
| per-class recall | 0.982 / **0.000** / 0.376 / 0.316 / 0.407 |
| predicted counts | 4657 / **0** / 478 / 68 / 65 |
| grade 3 recall | 0.316 [0.241, 0.396] |
| grade 4 recall | 0.407 [0.324, 0.504] |

QWK by epoch: 0.025, 0.511, 0.549, 0.546, 0.597, 0.595, 0.614, 0.614.

The rule reported a collapse and Phase 3 acceptance failed, because grade 1 was never
predicted.

### The assessment

**That is not a collapse, and the user was right to challenge it — but not quite for the
reason given.** "Four of five grades are predicted" is not the principle. Consider the
same shape with grade 4 unpredicted instead: also four of five, also a healthy QWK, and
**catastrophic**, because proliferative disease is the thing this system exists to catch
and a model that cannot emit that grade cannot flag it even in principle.

The principle is **whether the missing grade changes a referral**:

- The referable threshold is **grade ≥ 2** (`configs/base.yaml`). Grade 1 is Mild DR,
  **below** it. Folding grade 1 into grade 0 moves 357 val images (6.8%) between two
  labels that are *both non-referable*, so the clinical decision the deployed system
  makes is **unchanged**.
- QWK weights a 1-called-0 error at **1/16** of a 4-called-0 error, so the primary metric
  already prices this correctly.
- The degenerate failure the rule exists for — learning the prior and nothing else —
  scores 0.7369 accuracy and **0.0 QWK**. This run scores 0.6138 with a CI nowhere near
  zero, and its per-epoch curve rose monotonically from 0.025. It learned the ordering.

Absorbing a rare middle grade under plain cross-entropy at 6.8% prevalence is the
**expected behaviour of an unbalanced baseline**, and it is the specific deficiency arms
B–E exist to fix. Blocking the phase on it would block the pipeline for demonstrating the
problem the thesis is about.

### The rule, restated

`detect_collapse` now returns one of three levels. **Fatal**, meaning stop and diagnose:

1. Predictions concentrated in a **single class** — the degenerate case.
2. Accuracy within 0.02 of the **majority-class rate**.
3. A grade **at or above the referable threshold** never predicted while it has support.

**Warning**, reported everywhere but not blocking:

4. A grade **below** the referable threshold never predicted.

The threshold comes from `eval.referable_threshold` rather than being hardcoded, so a
project that moved the referral line would move this rule with it. An all-zero *row* is
still not reported at all: that is a property of the evaluation set, not the model.

Warnings reach `metrics.json` (`collapse.level`, `collapse.warnings`), `train_log.csv`
(`val_collapse_level`, `val_collapse_warnings`) and the per-epoch console line. A warning
that nothing records is the same as no rule at all.

### Phase 3 acceptance

Was: *val QWK CI excludes zero, and every grade predicted.*
Now: **val QWK CI excludes zero, and no FATAL collapse** — i.e. not single-class, not at
the majority rate, and every referable grade reachable.

### What this run does not excuse

The baseline is **correct**, not good, and the write-up must not blur those:

- **Referable sensitivity is 0.5131.** Roughly half of referable cases are missed. That is
  the number arms B–F have to move, and it is the clinically meaningful headline.
- **Balanced accuracy 0.4163** against accuracy 0.7965 is the imbalance, stated plainly.
- Grade 3 recall 0.316 [0.241, 0.396] and grade 4 recall 0.407 [0.324, 0.504] — wide
  intervals on thin support, exactly as DECISION-006 anticipated.
- QWK was still rising at epoch 7 (0.614 for two epochs, best at 6). Eight epochs is a
  short schedule; Phase 4 should not read this as converged.

---

## DECISION-027 — Kaggle transport: the CLI first, and the auth trap that cost an hour

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No

Fetching the Phase 3 artefacts needed three things fixed, none of them obvious from the
error:

1. **The `kaggle` package had to go 1.7.4.5 → 2.2.4.** The older pin does not expose
   `KaggleApi` where `fetch_run` imported it from. `requirements.txt` now pins 2.2.4.
2. **`kaggle auth login`** is the current mechanism — the OAuth flow, not an API token.
3. **A legacy `~/.kaggle/kaggle.json` SHADOWS the newer OAuth credentials.** This is the
   trap. The symptom is a flat `401 Unauthenticated` with no indication that a second
   credential source exists or that the one being used is the stale one. Renaming that
   file out of the way is what fixed it.

**`fetch_run` now shells out to the CLI first and falls back to the library**, on the
user's observation that the import path is the fragile part — and it is: the import
broke across a minor version bump, while `kaggle kernels output` did not change. The CLI
is also what knows how to use `kaggle auth login`'s credentials. Both transports are
tried, and **both failures are reported together** rather than the first hiding the
second, which is precisely what made this hour expensive.

The verification layer is unchanged and transport-independent — what makes a fetched run
trustworthy is that the three artefacts parse and agree with each other, not how the
bytes arrived.

**Kernel slug for the Phase 3 baseline: `rah098/fyp-dr-phase3-baseline`.**

### A provenance gap the fetched artefact revealed

`runs/phase3_baseline_resnet18/config.yaml` records `git: unknown`. On Kaggle the code
arrives as an unzipped Dataset, not a git checkout, so `git rev-parse` fails — and the
run cannot name the commit that produced it, which is an R6 weakness.

`make_bundle` already writes the SHA into `BUNDLE.txt` for exactly this reason.
`_git_sha()` now falls back to reading it, so every Phase 4 run records its code version.
The baseline's `unknown` stands: it is what that run recorded.

---

## DECISION-028 — Nothing under `notebooks/` runs at import time, and the gate survives one that does

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No

Phase 4 cell 1 died on Kaggle before any GPU time, in the gate itself:

    FileNotFoundError: 'runs/phase3_baseline_resnet18/metrics.json'
      gen_experiments.py line 15, during importlib.import_module("notebooks.gen_experiments")

`notebook_check` imports every module under `notebooks/` to collect the command lines its
cells will run. `gen_experiments.py` read the Phase 3 artefacts at **module level** — it
had been lifted out of a throwaway script without moving its body into `main()`. `runs/`
is not in the code bundle, so the import raised, and `notebook_check` exited 1 **before
checking anything**.

Two separate defects, and both are worth fixing.

**1. A module under `notebooks/` must not touch the filesystem at import time.** Those
modules exist to be imported by tooling — that is the whole mechanism `notebook_check`
relies on. `gen_experiments` now does all its work inside `main()`, exposes
`build_parser()`, and derives its root from `__file__` rather than `Path(".")`; the
cwd-dependence was a second latent bug in the same six lines.

**2. The gate must not be brought down by one module.** A checker that dies on the first
bad input tells you nothing about the other inputs — and it failed *closed* in the worst
possible way here, reporting a single import error while 21 command lines across three
notebooks went unexamined. `notebook_import_errors()` now reports a failing module as a
finding, and `collect_invocations` / `collect_api_calls` skip it and carry on. The failure
is reported **first and loudest**, because the consequence is specific and severe: that
notebook's cells are **UNCHECKED**, which is worse than any single bad command line.

`tests/test_notebook_cells.py` pins both halves. One test imports every module under
`notebooks/` fresh from a working directory with **no `runs/`, no `data/`, no `docs/`** —
the Kaggle condition, the code bundle and nothing else. Another plants a module that
raises on import and asserts the gate names it *and* still collects every other
notebook's invocations.

### The pattern, for the fifth time

Cell 1 exists because three sessions were lost to unvalidated glue. This failure was **in
the validator**, which is the same shape one level up: the thing that runs first, once,
protecting something expensive, was itself the least-exercised code. It is now exercised
by tests that reproduce the environment it actually runs in rather than the one it was
written in.

Everything downstream of it had already passed on Kaggle before it fell over — cache
38,788 verified, Tesla T4, bundle git `456444a`, pretrained weights OK.

---

## DECISION-029 — The collapse rule's accuracy test needs both halves

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No

Phase 4 stage 1 reported `collapse: collapsed` for **four of the five arms that ran** —
B, D, E and F — including arm E, which posted the ablation's **highest QWK, 0.7081**.
That is a false positive, and its cause is arithmetic:

| arm | accuracy | ≤ majority + 0.02 (0.7569)? | QWK |
|---|---:|---|---:|
| A | 0.8050 | no | 0.6823 |
| B | 0.6902 | **yes** | 0.5841 |
| D | 0.6327 | **yes** | 0.5538 |
| E | 0.7272 | **yes** | 0.7081 |
| F | 0.6695 | **yes** | 0.5617 |

**Rebalancing deliberately trades accuracy for rare-class recall**, so an arm with a
weighted sampler sits at or below the 0.7369 majority rate *by design*. The bare accuracy
test therefore fires on exactly the thing the ablation exists to measure.

The failure the test is for is "respectable-looking accuracy, no actual learning", and
its signature is accuracy near the majority rate **and QWK near zero**. A model with a
real QWK is by definition not predicting one class for everything — and that case is
already caught by rule (1). So the test now requires **both halves**, with `qwk_floor`
defaulting to 0.10. When accuracy is low but QWK is healthy it emits a *warning* saying
so, because the observation is still worth printing.

**A second, separate fix.** An existing test asserted that never predicting grade 0 is
fatal, and it passed only because the accuracy heuristic happened to catch it. That is
not a reason. Never predicting the **majority grade** is now fatal in its own right:
on a 73.7%-grade-0 population it means referring every patient, so specificity collapses
and the screen is useless — even though grade 0 sits below the referral line.

**No model changes.** This is a reporting fix; nothing about any trained arm is affected,
and the corrected verdicts are re-derived from the committed confusion matrices when
`docs/EXPERIMENTS.md` is regenerated.

---

## DECISION-030 — QWK selects the mechanism; a sensitivity floor gates deployment

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** Extends it. The proposal names QWK as the primary metric
  and that is unchanged; this adds a feasibility constraint on the *deployed* model.

### The tension, in the measured numbers

| arm | val QWK | referable sensitivity |
|---|---:|---:|
| E (ordinal) | **0.7081** (best) | **0.5598** (worst) |
| A (baseline) | 0.6823 | 0.6404 |
| B (sampler) | 0.5841 | 0.6725 |
| D (focal+sampler) | 0.5538 | 0.6307 |
| F (pooled) | 0.5617 (EyePACS-only) | **0.6917** (best) |

The ranking by QWK is close to the **inverse** of the ranking by referable sensitivity.
Spearman ρ = −0.40 across the five arms — with n=5 that is **not statistically
significant** (p = 0.51) and must not be reported as a correlation. What is not in doubt
is the concrete pair: the arm with the best QWK has the worst sensitivity, and the arm
with the best sensitivity is near the bottom on QWK.

That is not noise, it is a real trade-off. QWK rewards agreement across the whole ordinal
scale; referable sensitivity rewards catching disease at the 2+ boundary and is
indifferent to everything else. Optimising one does not optimise the other.

### The decision

**1. The ablation's selection metric stays validation QWK.** It is pre-registered in
CLAUDE.md §5 and the proposal. Changing it *after seeing the results* would be
criterion-shopping, and the comparison would no longer mean what it claims. This is not a
close call.

**2. QWK alone must not choose the deployed model.** A screening system is defined by its
operating characteristic. The headline model must additionally meet a **referable
sensitivity floor at an operating point chosen on validation** (R3), reported with its
specificity. Selecting a grading mechanism and choosing an operating point are two
different decisions and the project was conflating them.

**3. Arm E cannot be compared on sensitivity yet, and this is the important caveat.**
Arm E is an ordinal head whose grades come from cut points, and it is currently using the
**untuned defaults `[0.5, 1.5, 2.5, 3.5]`**. `configs/arm_e.yaml` says those are to be
optimised on validation; `src/eval/thresholds.py` does not exist yet. Its 0.5598 is a
property of an arbitrary cut point, not of the arm. Moving the grade-2 threshold trades
sensitivity for specificity directly — which is an **advantage** of the ordinal head, not
a defect: it is the only arm whose operating point is a free dial. Comparing it against
softmax arms on sensitivity before turning that dial is not a fair comparison in either
direction.

**4. None of these models is deployable as a screen.** Published DR screening standards
ask for roughly **80%+ sensitivity for referable disease at ≥95% specificity**
(figure from the literature, not measured here — the supervisor should confirm the
standard that applies). Every arm sits at 0.56–0.69. That gap is an honest finding for
the write-up, not something to be smoothed over, and it is what Phase 4's remaining work
and Phase 5 exist to address.

### What happens next, in order

1. Build `src/eval/thresholds.py` and optimise arm E's cut points on **validation only**.
2. Re-report every arm's sensitivity/specificity at a matched operating point.
3. Apply the floor to the headline model, not to the ablation ranking.

---

## DECISION-031 — Pooling APTOS is a null result on the target domain

- **Date:** 2026-08-22
- **Status:** Accepted — this is the measured answer to the supervisor's suggestion
- **Deviates from proposal:** No. DECISION-007 set this up as an empirical question.

### The comparison that was nearly made, and why it is wrong

Arm F's EyePACS-only QWK is **0.5617** against arm A's **0.6823** — an apparent loss of
0.12 from pooling. **That comparison is invalid.** Arm F uses the weighted sampler and
arm A does not, so F-vs-A confounds *pooling* with *sampling*.

The comparison that isolates pooling is **F vs B**, which share the sampler and differ
only in the training data:

| | sampler | training data | EyePACS-only val QWK |
|---|---|---|---:|
| B | weighted | EyePACS | 0.5841 [0.5574, 0.6108] |
| F | weighted | EyePACS + APTOS | **0.5617** |

**−0.0224, and F's value sits inside B's 95% interval.** Pooling APTOS has **no
detectable effect** on EyePACS grading. The large effect in the table belongs to the
sampler, not the data: B − A = −0.098.

### Is the domain artefact visible?

Partly, and less conclusively than the raw numbers suggest.

**Arm F scores 0.8609 on APTOS and 0.5617 on EyePACS.** That gap is *not* by itself
evidence of a shortcut: APTOS is intrinsically easier — 49.3% grade 0 against EyePACS's
73.5%, so QWK is mechanically higher on it — and its validation set is n=550 against
5,268. A large APTOS/EyePACS gap is the expected result even for a model using no domain
cue at all.

What **is** demonstrated is the inflation DECISION-007 predicted: F's **pooled** QWK is
0.6192 against 0.5617 EyePACS-only, so **+0.058 of arm F's headline number comes purely
from including easier APTOS images**. That is exactly why DECISION-007 mandated
EyePACS-only selection for this arm, and it is now measured rather than anticipated.

Whether the model is *using* a camera cue as a severity proxy remains open. The
`p_aptos` column shows the correlation is present in the training draw; establishing
that the model exploits it needs the Phase 5 Grad-CAM comparison by origin, or an arm F
run without the sampler. Neither has been done, and the claim should not be made until
one of them has.

### The answer to the supervisor

The suggestion was that APTOS could relieve the class imbalance. The measured answer:
**it does not improve grading on the target domain.** Against the correct comparator it
is a null result within the confidence interval, while it adds a domain confound and
inflates the arm's own headline metric.

That is a real contribution rather than a disappointment — a reasonable idea, tested
properly with the right comparator, and reported honestly. The write-up should state the
F-vs-B comparison explicitly, because F-vs-A is the comparison a reader will reach for
and it is the wrong one.

**Caveat: one seed.** F is in the stage 2 top three, so the null result will be repeated
at seeds 43 and 44 before it is claimed.

---

## DECISION-032 — The sensitivity floor is 80% at 95% specificity, from the UK screening standard

- **Date:** 2026-08-22
- **Status:** Accepted, **pending supervisor confirmation of the applicable standard**
- **Deviates from proposal:** Extends it. Implements the floor DECISION-030 called for.

### The proposed floor

**Referable-DR sensitivity ≥ 0.80 at specificity ≥ 0.95**, on validation, at an operating
point chosen on validation only (R3).

Both halves are required and the pair is the standard, not either number alone.
Sensitivity by itself is trivially satisfiable by referring every patient — the model that
scores 1.00 sensitivity and 0.00 specificity is the one that refers everybody, and it is
useless. `choose_operating_point` therefore reports the joint point, and separately what
each constraint costs when the other binds.

### The basis, with citations

**Primary — the UK standard.** Diabetic retinopathy screening programmes in the UK are
held to a minimum of **≥80% sensitivity, ≥95% specificity, and ≤5% technical failure
rate**. The figures originate with the British Diabetic Association (now Diabetes UK) and
are carried into NICE guidance and NHS Diabetic Eye Screening Programme standards.
Verified 2026-08-22 against:

- [Screening for diabetic retinopathy — GPnotebook](https://gpnotebook.com/pages/ophthalmology/screening-for-diabetic-retinopathy)
- [Diabetic eye screening programme — PrimaryCareNotebook](https://primarycarenotebook.com/pages/ophthalmology/diabetic-eye-screening-programme)

**Secondary — what a cleared autonomous AI device achieves.** The FDA-authorised IDx-DR
system reported **87.2% sensitivity and 90.7% specificity** (with 96.1% imageability) for
more-than-mild DR in its pivotal trial, exceeding all pre-specified superiority endpoints:

- Abràmoff MD, Lavin PT, Birch M, Shah N, Folk JC. *Pivotal trial of an autonomous
  AI-based diagnostic system for detection of diabetic retinopathy in primary care
  offices.* **npj Digital Medicine** 2018;1:39.
  [nature.com/articles/s41746-018-0040-6](https://www.nature.com/articles/s41746-018-0040-6)
  · summary confirmed via [PMC8120059](https://pmc.ncbi.nlm.nih.gov/articles/PMC8120059/)

### What is NOT verified, and must be before it is written up

Three things were **not** confirmed and must not be stated as fact in the thesis:

1. **The exact numeric values of IDx-DR's pre-specified endpoints.** The trial "exceeded
   all pre-specified superiority endpoints" is confirmed; the specific thresholds
   (commonly quoted as 85% sensitivity / 82.5% specificity) were **not** verifiable — the
   FDA De Novo document DEN180001 returned 404 and the Nature article is behind an
   authentication redirect. Cite the achieved figures, not the endpoints, unless the
   primary source is obtained.
2. **The precise NICE guideline number and clause.** The 80/95 figures are corroborated
   by multiple secondary sources, but the primary NICE/NHS DESP document was not read
   directly. **Obtain the primary source before it goes in the thesis.**
3. **Whether mtmDR maps exactly onto this project's referable definition.** "More than
   mild DR" is ETDRS-based; this project's referable line is `grade >= 2` on the
   EyePACS/ICDR-like 0–4 scale. They are closely aligned in intent — grade 2 is Moderate
   NPDR — but they are not the same instrument, and UK DESP referable criteria also
   include maculopathy, which these labels do not encode at all.

**This is a benchmark, not a like-for-like requirement**, and the write-up should say so.
The value is that it anchors the number to a named external standard instead of leaving
"sensitivity 0.64" floating without a reference point.

### Where this project stands against it

| arm | referable sensitivity | specificity |
|---|---:|---:|
| standard | **≥ 0.80** | **≥ 0.95** |
| IDx-DR (cleared device) | 0.872 | 0.907 |
| A | 0.6404 | 0.9804 |
| B | 0.6725 | — |
| D | 0.6307 | — |
| E | 0.5598 | — |
| F | 0.6917 | — |

**No arm meets the standard.** That is the honest headline and it belongs in the write-up.

But note what arm A's pair says: **0.98 specificity against a 0.95 floor, and 0.64
sensitivity against a 0.80 floor.** It has roughly three points of specificity in surplus
and sixteen points of sensitivity missing. The operating point is sitting far too
conservative, and surplus specificity is spendable — which is exactly what
`src/eval/thresholds.py` now measures, per arm, without retraining anything. How much of
the gap that closes is an empirical question that the tool answers and this decision does
not prejudge.

---

## DECISION-033 — Arms are compared under a matched decision rule, and the stage 1 ranking changes

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No. QWK remains the metric; what changes is that every arm
  is scored with the same number of free parameters.

### The asymmetry

The stage 1 table compared **arm E's QWK after fitting four cut points on validation**
against every other arm's QWK from a bare `argmax`. Those are not the same quantity: E
was scored with four fitted parameters and the softmax arms with none.

Giving every arm the same four degrees of freedom — cut points on the **expected grade**
`sum(p_i * i)` for a softmax head, which is the natural continuous analogue that `argmax`
discards — and measuring the optimism by fitting on half the validation set and scoring
the other half:

| arm | as run | fitted | held-out | optimism | gain | train−val gap |
|---|---:|---:|---:|---:|---:|---:|
| A | 0.6823 | 0.7315 | **0.7194** | 0.0121 | +0.037 | +0.092 |
| E | 0.7081 | 0.7263 | **0.7132** | 0.0131 | +0.005 | +0.073 |
| F | 0.6192 | 0.7091 | 0.7004 | 0.0087 | +0.081 | +0.301 |
| D | 0.5538 | 0.6541 | 0.6400 | 0.0140 | +0.086 | +0.300 |
| B | 0.5841 | 0.6474 | 0.6295 | 0.0180 | +0.045 | +0.290 |
| C | 0.4048 | 0.6078 | 0.5967 | 0.0111 | **+0.192** | −0.145 |

**Ranking on held-out fitted QWK: A > E > F > D > B > C.**
**As run it was: E > A > F > B > D > C.**

Two positions moved, and neither move is about imbalance handling — the decision rule
moved them. **Threshold-fitting optimism is 0.009–0.018 QWK**, so the fitted numbers are
usable; that is measured here rather than assumed, and it is re-measured whenever
`src/eval/compare_arms.py` is re-run.

### A and E are a tie, not a lead

Paired bootstrap on held-out fitted QWK, on the same validation images:

    QWK(A) - QWK(E) = +0.0069   95% CI [-0.0203, +0.0291]   A better in 74% of resamples

**Not separable.** E's apparent 0.04 QWK lead was substantially the fitting asymmetry.
At a fixed operating point the two were already tied (sens@spec 0.6618 vs 0.6589), and
they are tied on QWK too once the comparison is fair. **No arm is the presumptive winner
on this evidence.**

### What the arms are actually doing

The `train − val` QWK gap at the best epoch separates them far more cleanly than the
headline metric does:

- **A (+0.092) and E (+0.073)** — mild overfitting, and the two best arms. Neither
  rebalances anything.
- **B (+0.290), D (+0.300), F (+0.301)** — the three arms with the **weighted sampler**.
  They reach train QWK 0.87–0.92 and lose ~0.30 on validation. Sampling with replacement
  shows the same few hundred grade-3 and grade-4 images many times per epoch, and the
  model memorises them. Their epochs confirm it: B stopped at 16 (best 8), D at 14
  (best 6), against A and E at 28 (best 20).
- **C (−0.145)** — the only arm that *underfits*. Train QWK 0.26 against val 0.40, train
  loss 1.71 where every other arm is 0.13–0.71.

**The headline result of the ablation is therefore negative: neither rebalancing mechanism
beats doing nothing on this data.** That is a real finding, not a disappointment, and it
is the honest answer to the question the ablation was built to ask.

---

## DECISION-034 — Arm C's failure is a displaced decision boundary, not a broken model

- **Date:** 2026-08-22
- **Status:** Accepted
- **Deviates from proposal:** No

Arm C looks catastrophic as run — QWK 0.4048 against arm B's 0.5841 — and the obvious
write-up line, "the sampler beats class weights", would be **overstated**.

**Re-thresholding recovers most of it: +0.192 QWK, the largest gain of any arm, to
0.5967 against B's 0.6295.** At matched decision rules the gap is **0.03, not 0.18**, and
that is inside the range where these arms are not separable on one seed.

### The mechanism, for the viva

`class_weights_from` uses inverse frequency, normalised to mean 1. On the committed train
split that is:

    grade  0      1      2      3      4
    weight 0.061  0.637  0.299  1.812  2.191      ratio 4:0 = 36x

**A grade-0 mistake costs 1/36 of a grade-4 mistake**, so the model rationally gives grade
0 away. Its confusion matrix shows exactly that: **1,385 of 3,882 grade-0 images (35.7%)
predicted as grade 1**, and grade-0 recall collapsing to 0.493. It is the only arm where
**specificity** is the binding constraint on the operating point — every other arm is
limited by sensitivity. That is the signature of a decision boundary pushed too far
toward the rare classes, and moving the boundary back is exactly what re-thresholding does.

The residual damage, after the boundary is corrected, is **optimisation instability**.
Weighting does not change which images are in a batch: a batch of 64 still holds about
1.3 grade-4 images on average, and often none — but when one appears it arrives with 36×
the gradient of a grade-0. The expected gradient matches the sampler's; its **variance is
far higher**. That shows up as the highest train loss in the ablation (1.71), a train QWK
*below* its own validation QWK, and an early stop at epoch 9.

So the two mechanisms fail in opposite directions, and neither is subtle:

| | what it changes | how it fails here |
|---|---|---|
| **Sampler** (B, D, F) | which images are in the batch | rare images repeat within an epoch and get memorised — train QWK 0.87–0.92, gap ~0.30 |
| **Class weights** (C) | how much each image counts | boundary displaced 36:1, and high-variance gradients destabilise optimisation |

### The claim the thesis can actually make

Not "the sampler beats class weights". The defensible claims are:

1. **Inverse-frequency weighting displaces the decision boundary severely, and most of
   the apparent damage is recoverable by re-thresholding on validation.** The comparison
   is only fair after that correction.
2. **Neither mechanism beat the unbalanced baseline** on validation QWK at matched
   decision rules.
3. The result is specific to **inverse-frequency** weighting. `class_weights_from` also
   implements `effective_number` (Cui et al. 2019), which exists precisely because
   inverse frequency over-corrects, and **it has not been run**. Claiming "class weighting
   does not work" from arm C alone would overreach; claiming it about inverse-frequency
   weighting at a 36:1 ratio is supported.

---

## DECISION-035 — Every ranking claim uses a matched decision rule. Permanently.

- **Date:** 2026-08-22
- **Status:** Accepted — **standing rule, applies to every comparison in the thesis**
- **Deviates from proposal:** No. QWK is still the metric.

**This is the single easiest way for the write-up to mislead**, and it already did once:
the stage 1 table ranked arm E first on a QWK computed with four fitted cut points, above
arms scored with a bare `argmax` and no fitted parameters at all. Two positions in the
ranking moved when that was corrected, and the apparent winner became a statistical tie.

### The rule

**No ranking claim — in a table, a figure, a sentence, or the viva — may compare arms
scored with different numbers of free parameters.**

1. **Every arm gets the same degrees of freedom.** Four cut points, fitted on validation.
2. **Softmax heads are scored on the expected grade** `sum(p_i * i)`, not `argmax`. The
   expected grade is the continuous analogue of an ordinal output; `argmax` collapses
   "spread across 2 and 3" and "confident 2" into the same answer, and those are not the
   same evidence.
3. **Fitting optimism is measured and reported**, by fitting on half the validation set
   and scoring the other half. On this ablation it is 0.009–0.018 QWK. That number is a
   result, not an assumption, and it is re-measured on every run of
   `src/eval/compare_arms.py`.
4. **Differences are reported with a paired bootstrap interval**, paired on the same
   validation images. An interval spanning zero is a **tie** and is written up as one.
5. **The as-run column stays** — it is what the run actually produced and dropping it
   would hide the effect of the decision rule. It is **never** the basis of a ranking
   claim.

### Why the as-run column must stay but must not rank

The gap between the two columns is itself a finding. Arm C gains **+0.192 QWK** from
re-thresholding and arm E gains **+0.005**: that difference says something real about how
badly inverse-frequency weighting displaces the decision boundary (DECISION-034). Deleting
the as-run numbers would erase the evidence for that; ranking on them would attribute a
decision-rule artefact to the imbalance mechanism.

`src/eval/compare_arms.py` prints both columns side by side and, when the two rankings
disagree, says so explicitly:

    ranking on held-out fitted QWK: A > E > F > D > B > C
    as-run ranking was          : E > A > F > B > D > C
    ^ the decision rule, not the imbalance mechanism, moved these

### Where it applies

Every arm comparison, stage 2's seed repeats, stage 3's capacity test, the arm F pooled
question (which additionally uses EyePACS-only scores, DECISION-007), and the final
model-selection decision. The one number that is **not** subject to this is the test-set
result, which is produced once, at a single operating point fixed on validation
beforehand, and is not a ranking.

---

## DECISION-036 — The stage 3 prediction is half wrong, and it tested the wrong variable

- **Date:** 2026-08-24
- **Status:** Accepted
- **Deviates from proposal:** No.

The pre-registration in `docs/EXPERIMENTS.md` called stage 3 a **capacity** test. It was
not one. **EfficientNet-B0 has 4.01M parameters against ResNet18's 11.18M** — measured,
not looked up. The run swapped in a backbone that is 64% *smaller*, so whatever it
measured, it did not measure the effect of more capacity. That is a design error in the
pre-registration, recorded here rather than quietly re-labelled.

### What the prediction said and what happened

| claim | outcome |
|---|---|
| Arm B's train−val gap stays ≥ 0.25 | **held** — 0.290 → 0.329 |
| Arms A and E move < 0.03 QWK | **A held** (+0.015); **E broke it** (+0.053) |
| B0 will not close the 0.14 referable-sensitivity gap | **wrong** — E's sens@spec≥0.95 went 0.6589 → 0.7464, closing 62% of the distance to the 0.80 floor |

### What it actually tested, and the result

Backbone quality at matched compute (B0 is 1.08× ResNet18 per epoch). All three arms
improved. The informative part is that **the two softmax arms turned better features into
more overfitting and the ordinal arm did not**:

> **CORRECTED BY DECISION-042 (2026-08-25).** The B0 figures below are single seeds.
> Seed-resolved, arm E's B0 gap is **0.077** (mean of 0.034/0.098/0.097) and arm A's is
> **0.130** (0.157/0.137/0.096). **Arm E's gap did not narrow — it was flat (+0.004).**
> The "opposite response" claim is withdrawn. What survives: arm A's gap widened and arm
> E's did not, and arm E's gap is consistently about 60% of arm A's.

| arm | head | gap on R18 `[1 seed]` | gap on B0 `[1 seed, superseded]` | Δgap |
|---|---|---:|---:|---:|
| A | softmax | 0.092 | 0.157 | +0.065 |
| B | softmax | 0.290 | 0.329 | +0.039 |
| E | ordinal regression | 0.073 | ~~0.034~~ → 0.077 | ~~−0.039~~ → +0.004 |

The gap response still differs by head, but the difference is that arm A's gap widened
while arm E's held steady — not that they moved in opposite directions.

The mechanism: cross-entropy over five logits can always spend a better representation on
driving the correct logit higher on individual training images, and confidence does not
transfer. Smooth-L1 on a single scalar cannot — the output is already in grade units and
the loss stops rewarding a residual once it is small — so a better representation has
nowhere to go except better ordering. The corroborating evidence is in the cut points:
**arm E on B0 has a fitted first cut of exactly 0.500, the default**, and re-thresholding
buys it +0.002 QWK against +0.041 for A and +0.046 for B.

### Consequences

1. **Capacity remains untested.** No claim about it may be made in the write-up.
2. **Backbone quality is a demonstrated, cheap lever**: +0.0408 held-out QWK
   [+0.0181, +0.0654], separable, for 1.08× compute.
3. **"Regularise" now applies only to arms we are not going to use.** Arm E's gap is
   **0.077 across three seeds** (DECISION-042 corrects the 0.034 first written here),
   against arm A's 0.130 and arm B's 0.329. Arm E still overfits far less than the arms
   it is being carried forward over, so the conclusion holds — the number was wrong by
   2.2×, the prescription was not.
4. **384px moves down the queue but not off it.** Its argument — microaneurysms are a few
   pixels across at 224 — is physical and untouched by this result, but it costs ~2.9×
   compute plus a ~2.5 h cache rebuild, against ~1 h to test one more backbone.

### The new methodological risk this creates

Architecture is now being selected on the same 5,268 validation images as everything else.
DECISION-035's optimism measurement covers **cut points only**; it does not cover
architecture choice. The test set is still untouched, so the final reported number stays
honest — but the *validation* figure is now optimistic by an amount nobody has measured.
Every architecture decision made on validation is counted in `PROGRESS.md` and the count
is reported in the write-up.

---

## DECISION-037 — Arm C's failure is mostly, but not only, a displaced boundary

- **Date:** 2026-08-24
- **Status:** Accepted
- **Deviates from proposal:** No.

DECISION-034 proposed that inverse-frequency class weighting fails by displacing the
decision boundary rather than by learning a worse model. Arm C2 (effective-number
weighting, 17.1:1 against inverse frequency's 36:1) tests it. **The story holds, and the
decomposition is not 100/0.**

The displacement is monotone in how aggressive the weighting is:

| arm | weight ratio | mean expected grade on **true grade-0** images | fitted first cut | as-run grade-0 recall | re-thresholding gain |
|---|---:|---:|---:|---:|---:|
| A | 1.0 | 0.414 | 0.642 | 0.964 | +0.045 |
| C2 | 17.1 | 1.456 | 1.581 | 0.879 | +0.045 |
| C | 36.0 | **1.877** | **1.970** | **0.493** | **+0.200** |

Arm C's average output on an image that is genuinely healthy is **1.877** — nearly two
grades of severity — and recovering from that needs the first cut moved +1.47. Once the
weights are gentler, **C2's re-thresholding gain is identical to plain arm A's**, so the
pathology is a property of the weight ratio, not of class weighting as such.

**The decomposition.** C2 beats C by **+0.198 as-run**, but at matched decision rules by
only **+0.0436 [+0.0144, +0.0746]** (paired bootstrap, separable). So **about 78% of the
apparent advantage is decision-boundary displacement and about 22% is a genuinely better
learned ordering.** Aggressive weighting hurts twice: mostly by moving the operating
point, which thresholding recovers, and partly by degrading the ranking, which it does not.

**What survives for the write-up.** At matched rules C2 is 0.6483 and C is 0.6050, both
still well below arm A's 0.7270. The conclusion that **loss-level class weighting
underperforms leaving the distribution alone** is now robust to the weighting scheme and
to the decision rule, which is exactly what one run of one scheme could not establish.

---

## DECISION-038 — Stage 3.5: one backbone step, pre-registered, with a stopping rule

- **Date:** 2026-08-24
- **Status:** Accepted — **pre-registered before the run**
- **Deviates from proposal:** No. EfficientNet is the proposal's primary family.

DECISION-036 found backbone quality to be the only lever with separable evidence
(+0.0408 QWK [+0.0181, +0.0654] for 1.08x compute). This tests one more step and then
**closes the question**, so that a ladder does not turn into an unbudgeted search.

### The manipulated variable, in parameters and FLOPs

Measured locally with `timm` and `torch.utils.flop_counter`:

| backbone | params | GMAC @224 | native input |
|---|---:|---:|---:|
| resnet18 | 11.18M | 1.814 | 224 |
| efficientnet_b0 | 4.01M | 0.385 | 224 |
| **efficientnet_b2** | **7.70M** | **0.658** | **256** |

The step is **+3.69M parameters (+92%) and +0.273 GMAC (+71%)** over B0. **The entire
ladder sits below ResNet18 on both measures**, which is why no result anywhere on it may
be attributed to capacity. What varies is architecture family and pretrained-feature
quality.

### The confound, stated before the run

B2's native input is 256 and we run at 224 to hold resolution fixed against every other
run in the project. B0's native input **is** 224. B2 is therefore handicapped and B0 is
not, so **a null result does not show the backbone lever is exhausted** — only that this
step, at this resolution, did not pay. Only the second claim may be written up.

### The prediction

**B2 will not beat B0 by a separable margin: |dQWK| < 0.02, paired interval spanning
zero.** The ResNet18 -> B0 gain came from crossing architecture *families* — a different
inductive bias and a stronger ImageNet initialisation. B0 -> B2 is within-family compound
scaling at a below-native input size, the weakest form of the same lever.

### The stopping rule — every outcome stops

| paired held-out dQWK (B2 − B0) | decision |
|---|---|
| not separable | keep **B0** — smaller, cheaper, native at 224 |
| separable and positive | keep **B2**. Do not run B3. |
| separable and negative | keep **B0**, noting the off-native confound |
| any of the above, but B2 clears sens@spec>=0.95 of 0.80 | report as deployment-relevant, still do not run B3 |

Nothing escalates. Reopening the ladder requires a positive argument logged first
(DECISION-036), never a good result on its own. `notebooks/phase4_stage35.py` cell 3
applies this table rather than interpreting it.

### After this

Backbone fixed -> stage 2 seeds (arms E and A, 3 seeds, on the chosen backbone) -> the
384px decision on arm E alone.

---

## DECISION-039 — Stage 3.5 resolved: keep B0. The backbone question is closed.

- **Date:** 2026-08-25
- **Status:** Accepted — **the pre-registered prediction held**
- **Deviates from proposal:** No.

DECISION-038 predicted B2 would not beat B0 separably, |dQWK| < 0.02, interval spanning
zero. Measured, arm E, matched decision rule, paired on the same 5,268 validation images:

```
paired: QWK(E/b2) - QWK(E/b0) = +0.0052  95% CI [-0.0195, +0.0285]
  E/b2 better in 68% of resamples
  NOT SEPARABLE - the interval spans zero, so this pair is a tie
```

**AS PREDICTED.** Stopping rule row 1: **keep EfficientNet-B0** — smaller (4.01M vs
7.70M), cheaper (0.385 vs 0.658 GMAC) and native at 224 where B2 is not.

The screening operating point points the same way, which the QWK tie alone would not have
shown:

> **THE SUPPORTING ARGUMENTS BELOW ARE STRUCK BY DECISION-042 (2026-08-25).** Both
> compared single seeds. Seed-resolved at 224, B0's sens@spec≥0.95 ranges 0.7211–0.7464
> (mean 0.7360) and its gap averages 0.077 — so **B2's 0.7211 is exactly B0's worst seed,
> not 2.5 points behind it**, and B2's gap of 0.061 is **lower** than B0's mean, not
> double it. **The decision to keep B0 stands** on the two reasons that survive: the QWK
> difference is not separable, and B0 is smaller, cheaper and native at 224.

| run | held-out QWK | sens@spec>=0.95 | spec@sens>=0.80 | gen gap |
|---|---:|---:|---:|---:|
| **E/b0** | 0.7560 | 0.7464 `[1 seed; 3-seed mean 0.7360]` | 0.9030 `[1 seed]` | ~~0.034~~ → 0.077 |
| E/b2 | 0.7600 | 0.7211 `[1 seed]` | 0.8738 `[1 seed]` | 0.061 `[1 seed]` |

B2 is nominally ahead on QWK by an amount that is not separable. ~~and behind on the
metric that gates deployment, with nearly double the generalisation gap~~ — struck; both
differences are inside seed noise.

**Consequence.** The backbone is fixed at EfficientNet-B0. Selection-optimism count stays
at **3 of 4**: this step was pre-registered and resolved to "keep what we had", so it
spent a run, not a degree of freedom. Reopening the ladder still needs a positive
argument logged before a run (DECISION-036), and the off-native confound (DECISION-038)
means this result does **not** license the claim that backbone scaling is exhausted in
general — only that this step, at 224, did not pay.

---

## DECISION-040 — `compare_arms` was silently dropping runs; comparisons are keyed on a label

- **Date:** 2026-08-25
- **Status:** Accepted — bug fixed, regression tests added
- **Deviates from proposal:** No.

`src/eval/compare_arms.py` built its table as `runs[metrics["arm"]] = r`. That is correct
for exactly as long as one arm means one run, which is how it was written and how it was
true until arm E was trained on a second backbone.

**Found by the user, from the symptom: the E row read 0.7615, which is the B0 run, after
B2 had been fetched.** Three runs of arm E collapsed to one, last write won, and
`sorted()` put B0 last. **Four of eleven runs were being dropped**, and the ranking was
then computed over the seven survivors. Nothing warned, because nothing counted.

This is the DECISION-024 shape again — a branch that was never wrong until the data grew
a dimension it did not model — and it would have hit stage 2 immediately, where three
seeds of arm E would have reported as one seed and the seed-stability claim would have
been built on a single run.

**The fix.** `label_runs()` keys each run on the arm **plus whichever of arch and seed
actually varies in the matched set**, so a homogeneous set still reads `A`, `B`, `E`,
while a mixed one reads `E/r18`, `E/b0`, `E/b2` and a seed sweep reads `E/s1`, `E/s2`,
`E/s3`. A label collision that still gets through falls back to the run directory name
and then raises — it never overwrites. `main()` asserts `len(runs) == len(dirs)` and
prints the label-to-directory mapping above every table, so a dropped run is impossible
to have and impossible to miss.

`--compare` now resolves labels rather than uppercasing arm letters, and lists the
available labels when a token is ambiguous.

**Four regression tests** cover the three-backbone case, the three-seed case, the
homogeneous case (the label must not get noisier when there is nothing to disambiguate),
and the indistinguishable-runs case.

**Everything reported before this fix used single-backbone sets**, where the arm letter
was unique and the label is identical, so no committed number changes. Verified by
re-running the stage 1 comparison after the fix.

---

## DECISION-041 — Stage 2 is a stability measurement, not a tie-break, and cannot become one

- **Date:** 2026-08-25
- **Status:** Accepted — **stated before the run**
- **Deviates from proposal:** No.

Written down in advance because the tempting claim after three seeds is exactly the one
the design does not support.

### What stage 2 can settle

- The **seed variance of the headline number**, so arm E's QWK is reported as a mean over
  seeds with a spread rather than one draw presented as a fact.
- Whether the **operating point** is stable — `sens@spec>=0.95` gates deployment and is
  the number closest to a floor.
- Whether arm E's unusually small **generalisation gap (0.034)** is a property of the arm
  or of one seed.
- Whether the **sign** of the A-vs-E difference is consistent across seeds — a
  descriptive fact, never a significance claim.

### What it cannot settle, at three seeds or thirty

**The A-vs-E tie.** Every seed is scored on **the same 5,268 validation images**.
Averaging over seeds reduces the training-stochasticity component of the uncertainty and
does **nothing** to the validation-set sampling component, which is common to all seeds
and is a fixed floor. The measured effect on B0 is **+0.0224 QWK** and the paired
interval's half-width is **about 0.027** — the effect is smaller than a floor that
seed-averaging cannot lower.

Worse for the tempting claim: properly accounting for seed variance makes the honest
interval **wider** than the single-seed paired CI, which understates uncertainty by
ignoring training noise altogether. **Stage 2's effect on the tie, if any, is to make it
more of a tie.**

Three seeds give a **spread, not an interval**. Non-overlapping ranges are not a
significance test and must not be written up as one.

### The rule this creates

**The reported number is the mean across seeds. Never the best seed.** Best-of-three
would be a configuration choice made on validation, against the soft budget of four with
a positive-argument gate (DECISION-036). Stage 2 is a measurement and spends none of that
budget — but only because this is fixed in advance.

Arm E is carried forward on the secondary criteria stated **before** this run — a better
operating point, a smaller gap, and an output already calibrated in grade units — and not
because it won a comparison. A and E are reported as a tie (DECISION-035).

### Design

Seeds **42, 43, 44**, sequential and obviously arbitrary. Seed 42 already exists for both
arms from stage 3, so stage 2 is **four new runs, not six** (~2.4 h rather than ~3.5 h).

---

## DECISION-042 — Arm E's 0.034 gap was a seed artefact, and it was load-bearing

- **Date:** 2026-08-25
- **Status:** Accepted — **corrects DECISION-036 and DECISION-039**
- **Deviates from proposal:** No.

Stage 2 measured arm E's train−val gap on EfficientNet-B0 across three seeds:

| arm | s42 | s43 | s44 | **mean** | range |
|---|---:|---:|---:|---:|---:|
| E | **0.034** | 0.098 | 0.097 | **0.0765** | 0.064 |
| A | 0.157 | 0.137 | 0.096 | **0.1300** | 0.061 |

**The honest figure to quote for arm E is a mean of 0.077 over three seeds, range
0.034–0.098** — never 0.034, which is the most extreme of the three and was the only one
we had. The seed-to-seed range (0.064) is larger than most of the between-arm differences
this project has been reasoning about.

### What this invalidates

**1. DECISION-036's central mechanism claim does not survive.** It said the two softmax
arms turned better features into more overfitting while the ordinal arm's gap *narrowed*,
and called that "same backbone change, opposite gap response". Recomputed:

| arm | gap on R18 (s42) | gap on B0 | change |
|---|---:|---:|---:|
| A | 0.092 | 0.130 (3-seed mean) | **+0.038, widened** |
| E | 0.073 | 0.077 (3-seed mean) | **+0.004, unchanged** |

Arm E's gap did **not** halve. It was flat. The surviving claim is weaker and must be
stated as such: **arm A's gap widened on B0 and arm E's did not, and arm E's gap is
consistently about 60% of arm A's.** The "opposite response" framing goes.

**2. DECISION-039's two supporting arguments both dissolve.** It preferred B0 over B2
partly because B2 was "2.5 points of sensitivity behind" and had "nearly double the
generalisation gap". Against the seed-resolved 224 baseline:

- B2's sens@spec≥0.95 of 0.7211 is **exactly B0's worst seed**, inside a 224 range of
  0.7211–0.7464. Not behind — indistinguishable.
- B2's gap of 0.061 is **lower** than B0's 3-seed mean of 0.077, not double it.

Both were single-seed noise on both sides of the comparison. **The decision to keep B0
still stands**, on the two reasons that do survive: the QWK difference was not separable
(+0.0052 [−0.0195, +0.0285]), and B0 is smaller, cheaper and native at 224. The
supporting arguments are struck.

**3. "Arm E's gap is 0.034, there is nothing to regularise" becomes weaker but survives.**
At 0.077 arm E still overfits far less than A (0.130) and B (0.329), so regularisation
remains the wrong prescription for the arm we are carrying forward. The number was wrong
by 2.2×; the conclusion was not.

### The rule this creates

**Every single-seed generalisation gap in this project is provisional and must be labelled
so.** The stage 1 gaps for arms B (0.329), C, C2, D and F are all one seed each and none
of them has been seed-resolved. **No gap may carry an argument unless it has been measured
across seeds.** Where a single-seed gap appears in a table it is marked `[1 seed]`.

This is the second time a single-seed number has been used as evidence (DECISION-036 was
the first). The cost both times was a claim that had to be withdrawn rather than a wrong
decision — but only by luck.

---

## DECISION-043 — What arm E beating arm A on every seed does and does not license

- **Date:** 2026-08-25
- **Status:** Accepted
- **Deviates from proposal:** No.

Stage 2, three seeds each, EfficientNet-B0:

| | E (s42/s43/s44) | mean | sd | A (s42/s43/s44) | mean | sd |
|---|---|---:|---:|---|---:|---:|
| held-out QWK | 0.7578 / 0.7548 / 0.7564 | **0.7563** | 0.0012 | 0.7346 / 0.7370 / 0.7426 | 0.7381 | 0.0034 |
| sens@spec≥0.95 | 0.7464 / 0.7211 / 0.7405 | **0.7360** | 0.0108 | 0.6822 / 0.7085 / 0.7172 | 0.7026 | 0.0149 |

Arm E is ahead on **all three seeds on both metrics**, the ranges do not overlap
(QWK by 0.0122, sensitivity by 0.0039), and E's seed variance is roughly a third of A's on
QWK.

### What may be written

> Arm E outperformed arm A on every seed on both metrics, with lower seed-to-seed
> variability (held-out QWK range 0.003 against 0.008). Arm E was selected on that basis
> together with the pre-stated secondary criteria.

That is a factual description of six runs and a **selection rationale**. It is defensible.

### What may NOT be written

**Not** "arm E significantly outperforms arm A", or any phrasing implying the ordering is
established for the population.

The reason is specific and worth stating in the viva. Uncertainty here has two components:

1. **Training stochasticity** — which seed. Stage 2 measures this, and it is small.
2. **Validation-set sampling** — which patients happen to be in the validation split.
   **All six runs share the same 5,268 images**, so this component is *identical* across
   them and does not average away. The paired bootstrap puts it at ±0.027 on the
   difference, against a seed-mean difference of +0.018.

Consistency across seeds addresses (1) and is **completely silent** on (2). Six
measurements of the same object with the same mis-calibrated ruler agree beautifully;
agreement is not accuracy. Non-overlapping ranges over three points are a **spread, not an
interval**, and cannot be converted into one.

**The A-vs-E tie therefore stands** (DECISION-035). What stage 2 changes is the *confidence
of the selection*, not the *status of the comparison*. Arm E is what we carry forward; we
have not shown it is the better arm.

The only thing that could settle it is the held-out test set, and it will be opened once,
for the selected model only (R3). Running both arms on test would be selection on test.

---

## DECISION-044 — 384px goes ahead as ONE pre-registered ablation, not as a floor fix

- **Date:** 2026-08-25
- **Status:** Accepted — **pre-registered before the run**
- **Deviates from proposal:** No. §5 already scopes 384 as an optional ablation "if GPU
  quota survives Phase 4". It has.

### The framing that matters most

**A 384 result cannot become the headline number.** The proposal fixes **224 for all
headline results** (CLAUDE.md §5). So this run cannot "fix" the sensitivity floor for the
reported system — adopting 384 as the headline would be a separate deviation needing
supervisor approval. What it can do is answer a real thesis question: **was input
resolution the binding constraint?**

The thesis should state plainly that **the system does not meet the screening floor at
224** — best sens@spec≥0.95 is 0.7360 (3-seed mean) against 0.80 — and report this
ablation as evidence about *why*, rather than presenting it as a rescue. That is a
stronger and more honest chapter than a floor chased and missed.

### What it manipulates

**Input resolution only: 224 → 384.** Everything else is held — arm E, EfficientNet-B0,
30 epochs, seed 42, same splits, same patients, same preprocessing pipeline and
parameters. The pixel count rises **2.94×** ((384/224)²), which is also the training-cost
multiplier.

This is a **data** change, not a model change: it requires the cache to be rebuilt at 384,
so the model sees genuinely more detail rather than an upsampled 224 image.

### The prediction

**Sensitivity improves but does not reach 0.80**, landing in roughly **0.76–0.80**, and
**QWK improves by less than sensitivity does.**

Reasoning: microaneurysms are on the order of 50 µm and a fundus image is ~3000 px across,
so at 224 they are sub-pixel to one pixel. They are the defining lesion of grades 1–2 —
which is exactly the referable boundary that `sens@spec≥0.95` measures. Resolution should
therefore move the *operating point* more than it moves overall ordinal agreement, which
is already dominated by the easy grade-0 mass.

### The stopping rule — stated against the 224 seed RANGE, not a point estimate

This is DECISION-042's lesson made structural. The 224 baseline is **not** 0.7464; it is a
three-seed range of **0.7211–0.7464, mean 0.7360**. A single 384 seed must clear the top
of that range to mean anything at all.

| 384 sens@spec≥0.95 (seed 42) | reading | action |
|---|---|---|
| **≥ 0.78** | clearly above the 224 range | resolution is a real lever. **Take it to the supervisor** as a headline-resolution deviation. Only *after* approval, run 3 seeds at 384. |
| **0.7464 – 0.78** | one seed above a three-seed range | **suggestive, not established.** Report as the ablation. Do not escalate, do not change the headline. |
| **< 0.7464** | inside or below the 224 range | clean negative result. Report and stop. |

**In no case** does this lead to 512px, to 384 on other arms, or to a 384 headline without
supervisor approval.

### Cost, and a correction to the figure previously quoted

**The ~2.5 h cache rebuild written in the handoff was wrong.** That number was the compute
*lost* to the first failed Phase 2 attempt (DECISION-021), not the build time. **The 224
cache build actually took 8.1 hours** at `--workers 4` (DECISION-022).

Preprocessing cost is dominated by decoding ~3000 px source JPEGs and the Ben Graham blur
at source scale; the output size barely affects it. So:

| item | cost |
|---|---|
| Cache rebuild at 384 + verify + publish | **~8–9 h**, one full Kaggle session |
| Storage | ~2.4 GB (224 cache is 0.836 GB × 2.94) |
| Reconcile + leakage gate | ~15 min |
| Train arm E at 384, 30 epochs | 76 s/epoch × 2.94 ≈ 224 s/epoch → **~2 h** |
| **Single-seed total** | **~11 h across two sessions** |
| If it wins and 3 seeds are approved | +4 h |

### Against what remains

Quota is 30 h/week and **the remaining phases barely touch the GPU**:

| phase | GPU |
|---|---|
| 5 — Grad-CAM | inference + overlays, **minutes** |
| 6 — external validation on APTOS | inference only, **minutes** |
| 7 — FastAPI + Next.js | local CPU, **none** |
| 8 — write-up | **none** |

**GPU quota is not the binding constraint; calendar time and attention are.** 11 h is
roughly one week's quota for a result that is informative either way, and nothing
downstream is blocked waiting on it.

### The positive argument required by DECISION-036

Selection-optimism count would reach **4 of 4** only if a 384 result were allowed to change
the headline model. Under this decision it cannot without a separate supervisor approval,
so the count **stays at 3**. The positive argument, written before the run as required:

1. It is the **only remaining untested lever with a physical mechanism** — lesion size
   against pixel size — rather than an architectural guess.
2. It is **already scoped in the proposal**, so it is not an invention.
3. The floor is a **deployment gate**, and a thesis that never tests the most-cited fix
   for it is weaker for the omission.
4. **A negative result is a genuine finding**: it would say the limit is data scale and
   label noise, not resolution.

---

## DECISION-045 — Phases 5 and 6 run before the 384 ablation, and the test set waits for all three

- **Date:** 2026-08-25
- **Status:** Accepted
- **Deviates from proposal:** No — it is a reordering within the proposal's phases.

Order becomes: **Phase 5 (Grad-CAM) → Phase 6 (APTOS) → 384 ablation → Phase 7/8**, with
384 running while the web app is built.

### Nothing breaks, and one thing improves

Neither Phase 5 nor Phase 6 touches the **EyePACS test set**. Phase 5 is qualitative and
runs on validation images. Phase 6 evaluates on **APTOS**, which is a different dataset,
not the EyePACS test split — legitimate external validation for arms A–E (DECISION-007).

### The reordering is actively better, for a reason worth stating

**Phase 5's rim gate can invalidate the preprocessing the 384 cache would be built with.**
DECISION-016 chose 2–3% erosion over full 0.9r masking and pre-committed to revisiting it
"if the Phase 5 Grad-CAM sanity check shows the model keying on the rim, with evidence."
If that gate fails, the fix is a preprocessing change → cache rebuild → retrain. Building
the 384 cache first would mean building it **twice, at 8–9 hours each**.

So Phase 5 before 384 is not merely harmless — it removes a 9-hour downside risk.

Phase 6 before 384 costs little in the other direction: if 384 ever became the headline,
APTOS would need re-running on it, but that is inference-only and takes minutes.

### What this pins down: when the test set is opened

**The EyePACS test set is opened exactly once, on the single selected model, after the 384
decision is final** — including after any supervisor deviation is resolved either way.
Deferring it until after the last thing that could change the model is what makes "touched
once" achievable rather than aspirational.

**A contradiction in the governing documents, resolved here.** `BOOTSTRAP.md` R3 says
"Test metrics are computed at the end of each phase and recorded", which would be many
touches. `CLAUDE.md` R2/R3 says the test set is touched once. **CLAUDE.md wins** — it is
the operational distillation and the stricter reading, and the once-only rule is the
project's central methodological claim. BOOTSTRAP's phrasing is superseded and the
write-up describes the once-only protocol.

---

## DECISION-046 — Phase 5: the border-artefact check is a quantitative gate, pre-registered

- **Date:** 2026-08-25
- **Status:** Accepted — **pre-registered before any heatmap is generated**
- **Deviates from proposal:** No. Proposal §5.8 names Grad-CAM and Grad-CAM++.

Grad-CAM on **arm E, seed 42, EfficientNet-B0, 224**. The rim question was deferred to
here with evidence (DECISION-016), so the check is a **gate with a number and a threshold
fixed in advance**, not a figure someone eyeballs.

### Three implementation facts that make this non-obvious

**1. Arm E has ONE output, not five.** Standard Grad-CAM backpropagates from a class
logit. The ordinal head emits a single scalar, so the gradient is taken **from the scalar
itself** — the map answers "what raised the predicted severity". Any off-the-shelf snippet
assuming five logits will pick `argmax` of a length-1 vector and silently produce
something meaningless. A test asserts the target is the scalar.

**2. The CAM is 7×7 before upsampling.** EfficientNet-B0 at 224 ends at a 7×7 feature map,
so each CAM cell covers ~32×32 input pixels. **Grad-CAM at this resolution cannot localise
microaneurysms**, which are sub-pixel at 224. It can only show gross attention — disc,
macula, arcades, rim. The write-up must say this plainly rather than implying lesion-level
explanation. It is, however, exactly the right resolution for the rim question.

**3. The panel is pre-specified, not curated.** A fixed seed, a stratified random sample:
**200 validation images for the quantitative gate** (40 per grade), and a **20-image
qualitative panel** (correct and misclassified per grade) drawn by the same seed. Choosing
attractive heatmaps after the fact is the standard way an XAI section becomes decorative.

### The gate

Using `retina_mask` from the preprocessing pipeline, each image is divided into:

- **outside** — beyond the retinal disc entirely (black surround)
- **rim** — the outer 10% of the retinal radius
- **interior** — the rest

For each image, compute **mass ratio = (fraction of CAM mass in region) / (fraction of
image area in region)**. A model ignoring a region scores ≈ 1.0 there; one keying on it
scores well above 1.

| statistic | PASS | FAIL |
|---|---|---|
| median **rim** mass ratio over 200 images | **< 1.5** | ≥ 1.5 |
| median **outside** mass ratio | **< 1.0** | ≥ 1.0 |

> **AMENDED 2026-08-26 (DECISION-050).** This threshold was **0.5**, justified as
> "beyond the disc there is literally nothing to see, so mass there is unambiguous
> artefact". That justification was wrong — padded convolutions and a 7×7 upsample
> deposit mass at frame edges unavoidably, and an **untrained** network scores 0.615,
> failing the gate. Recalibrated to the fair-share expectation against measured nulls.
> **The Phase 5 measurement of 2.342 fails 0.5 and 1.0 alike, so the recalibration is
> not the reason that run failed and does not change its verdict.**

| rim ratio on grade 3–4 images specifically | **< 1.5** | ≥ 1.5 |

The `outside` threshold is strict on purpose: there is literally nothing to see beyond the
retinal disc, so meaningful mass there is unambiguous artefact rather than a judgement
call. The grade 3–4 row is separate because peripheral disease appears there and that is
precisely the region erosion was chosen to preserve — a model keying on the rim *only* for
severe grades is a different and worse failure than a uniform rim bias.

**On FAIL:** revisit masking with this evidence, per DECISION-016 — and, per
DECISION-045, **do so before building the 384 cache**, not after.

### A gate on the method, not just the model

Before any of the above is believed: **randomise the final block's weights and confirm the
CAM changes materially.** A saliency map that survives model randomisation is a property
of the image, not the model, and would invalidate the entire section. This is cheap and
it is the kind of thing that otherwise surfaces in a viva.

> The published sanity-check protocol for saliency maps (Adebayo et al., *Sanity Checks
> for Saliency Maps*, NeurIPS 2018) is **[CITATION UNVERIFIED]** and must not enter the
> write-up until checked, per the DECISION-032 rule. The check itself is run regardless —
> it stands on its own logic.

### Deliverables

1. `src/xai/gradcam.py` — Grad-CAM and Grad-CAM++, ordinal-head aware, testable on CPU.
2. `src/xai/border_check.py` — the three statistics above, `--gate` exits non-zero on FAIL.
3. `tests/test_gradcam.py` — scalar-target, shape, a synthetic image whose bright corner
   must produce high `outside` mass (so the statistic is proven to detect what it claims),
   and the randomisation check.
4. `notebooks/phase5_gradcam.py` — runs both on Kaggle, ~15 min.
5. The 20-image qualitative panel, drawn by the pre-registered seed.

---

## DECISION-047 — What happens if the Phase 5 gate fails, written before the numbers

- **Date:** 2026-08-25
- **Status:** Accepted — **pre-registered, same discipline as the stopping rules**
- **Deviates from proposal:** No.

A gate with no defined failure path is a gate that gets argued with after the fact. Each
of the three failure modes has a different cause and a different response, and conflating
them would produce either an unnecessary 12-hour rebuild or a quietly ignored artefact.

### If the RANDOMISATION gate fails — tooling, not model

A CAM that barely changes when the target layer is randomised is measuring the image.
**This invalidates every other number in the report**, so it is checked first and nothing
else is believed until it passes.

**Response:** fix `src/xai/gradcam.py`. **No cache rebuild, no retraining, and no heatmap
enters the write-up** until the gate passes. The model is not implicated.

### If the OUTSIDE gate fails — a segmentation bug, not a parameter

Meaningful CAM mass beyond the retinal disc usually means `retina_mask` is
**under-segmenting** — leaving black surround inside the "retina" — rather than that the
model has learned something exotic about darkness.

**Response:** inspect the masks on the offending images directly. If the mask is wrong
that is a **preprocessing bug**, fixed and rebuilt on its own merits, not an erosion
parameter question.

### If the RIM gate fails — a staged path, cheapest causal test first

**A high CAM ratio is not proof that the decision depends on the rim.** Grad-CAM is
correlational, and high-contrast boundaries attract activation for reasons unrelated to
the decision. So the path starts with a causal test, not with a rebuild.

**F1 — occlusion test. ~10 minutes, no retraining.** `border_check.occlusion_delta`
replaces the rim annulus with the **interior's mean colour** — not black, which is itself
out-of-distribution and would confound the measurement — and re-runs the model on the same
200 images. Measure the change in referable score and in `sens@spec>=0.95`.

| result | reading | action |
|---|---|---|
| `abs(Δsens) < 0.02` | the CAM shows a correlate; the decision does not depend on the rim | **Record as a documented limitation in the write-up. Do not rebuild.** The gate is downgraded to a stated caveat, and the reasoning is shown. |
| `abs(Δsens) >= 0.02` | real dependence | go to **F2** |

**F2 — choose the new erosion value with evidence. ~30 minutes, preprocessing only.**
DECISION-016 recorded the residual annulus ratio after 2.5% erosion. Re-measure that same
statistic at **5% and 10%** on a 2,000-image stratified subsample and take **the smallest
erosion that brings it into line** — a guessed value would be the same mistake this
project has already made with single-seed numbers. Log the measured values.

**F3 — rebuild and retrain. ~12 hours, and it is mandatory, not optional.**

| step | cost |
|---|---|
| Full 224 cache rebuild at the new erosion | ~9 h |
| Retrain arm E | ~40 min |
| **Re-run stage 2's three seeds** | ~2 h |

The seeds are not optional: both the headline number and its stability change, and
DECISION-042 is the standing reminder of what a single seed is worth. Everything
downstream — Phase 6 and the 384 cache — then uses the new cache, which is exactly why
DECISION-045 put Phase 5 first.

**Why mandatory.** Rim artefacts are camera- and site-specific. A model keying on them has
a generalisation hazard aimed directly at the external-validation claim and at any
deployment claim. That is not something the thesis can carry as a caveat; if F1 shows the
dependence is real, the 224 headline is compromised and must be rebuilt.

The old runs stay in `runs/` as the record and the write-up reports **both**, with the
reason for the change.

### Explicitly NOT the response: full 0.9r circular masking

DECISION-016 rejected it because it costs **19% of retinal area including the periphery
where proliferative disease appears**, and grade 4 is the thinnest class at 98 test
images. A rim-gate failure says *erode more*; it says nothing in favour of masking a fixed
geometric fraction, and that reasoning is unchanged by the gate's outcome.

---

## DECISION-048 — Tests must run in the context the artefact runs in; device parity is now tested

- **Date:** 2026-08-25
- **Status:** Accepted — bug fixed, device-parameterised tests added
- **Deviates from proposal:** No.

Phase 5 cell 2 died on the first real GPU run:

```
RuntimeError: Expected a 'cuda' device type for generator but found 'cpu'
  src/xai/gradcam.py, randomise_last_block
```

`torch.Generator` is **device-bound**. The seeded CPU generator could not seed
`normal_()` on a CUDA parameter, and `randomise_last_block` deep-copies a model that is
already on the GPU. **All 24 tests in `tests/test_gradcam.py` passed on CPU**, where the
model is on CPU and the mismatch cannot arise.

### The fix, and why not the obvious one

The noise is now **always generated on CPU and copied across**, even when the parameter
is already on CPU.

Seeding a CUDA generator instead would also have worked and would have been **wrong**:
CPU and CUDA generators produce **different streams for the same seed**, so the gate's
randomisation would not reproduce across machines. The seed is the only reason the gate
repeats at all, so the stream is pinned to CPU and the device transfer happens after the
numbers exist. `test_randomisation_stream_is_identical_on_every_device` pins three
reference values so a future switch to a CUDA generator fails **on the GPU**, which is
where the reproducibility would actually be lost.

A second latent bug was fixed alongside it: `normal_` has no CPU kernel for float16, so
the noise is generated in float32 and cast, and a half-precision checkpoint no longer
fails here for an unrelated reason.

### The pattern — this is the fourth time

DECISION-022 (a command line never parsed), -024 (a config branch never exercised),
-025 (a value never serialised), -040 (a dict key that was unique until it was not), and
now this. **Every one has been a context the fixture did not reproduce**, and every one
surfaced in the expensive run rather than the cheap one.

**The countermeasure is not a cleverer local test.** A device-mismatch bug is *unreachable*
on a CPU-only machine — no fixture can manufacture it. The countermeasure is to run the
tests **in the context the artefact runs in**:

1. `tests/test_gradcam.py` is now **device-parameterised** — `DEVICES = ["cpu"] + (["cuda"]
   if available)`. Locally the cuda cases skip; on Kaggle they execute.
2. **Cell 1 of `notebooks/phase5_gradcam.py` runs those tests on the GPU**, verbosely and
   by name, *before* cell 2 spends ten minutes. That is what makes (1) worth anything.

This generalises: **any notebook whose code path has a device, a driver, or a filesystem
the dev box does not have must run its unit tests inside that environment as a pre-flight
step**, not merely rely on them having passed locally. `smoke --arch` (DECISION-038) was
the same idea for backbones; this is it for devices.

Tests added: device parity for `randomise_last_block`, the pinned stream, an assertion
that noise is generated on CPU whatever device the model is on, an end-to-end CAM per
device, the full randomisation-gate path per device, a 0-dim parameter case, and the
float16 case. **31 tests, up from 24.**

---

## DECISION-049 — One checkpoint convention, one definition, tested against a real checkpoint

- **Date:** 2026-08-25
- **Status:** Accepted — bug fixed, shared loader added, structural guard in tests
- **Deviates from proposal:** No.

`notebooks/phase5_gradcam.py` cell 1 loaded weights with:

```python
model.load_state_dict(state["model"] if "model" in state else state)
```

**`"model"` is a key that has never existed in this project.** `src/train/loop.py` has
always written `{"epoch", "val_qwk", "state_dict"}`. The fallback then handed
`load_state_dict` the whole outer dict, which fails with a `RuntimeError` about unexpected
keys — a message that reads like an architecture mismatch rather than like a wrong key,
which is why it cost a second Kaggle session after the CUDA-generator fix.

### Why every test passed

Three call sites each hardcoded the key independently. Two were right
(`src/eval/predict.py`, `src/train/loop.py`) and the third was invented. **No test loaded a
checkpoint that the real training loop had written** — `tests/test_train.py` checked the
*save* side, the eval loaders happened to be correct, and the notebook was never executed
locally. A hand-built dict in a test would only have re-asserted whatever convention the
test author had in mind, which is the same coin flip that produced the bug.

### The fix

`src/models/factory.load_checkpoint()` now owns the convention, and **all three call sites
go through it**. It raises naming the keys it actually found:

```
KeyError: .../best.pth has no 'state_dict' key; found ['epoch', 'model'].
Checkpoints in this project are written by src/train/loop.py as
{'epoch', 'val_qwk', 'state_dict'}.
```

### The structural guard

`tests/test_checkpoint.py::test_nothing_loads_a_checkpoint_except_through_the_shared_loader`
scans `src/` and `notebooks/` and fails on any `load_state_dict` outside `factory.py`.
Three sites were three independent coin flips; a fourth would have been a fourth. Now
there is one definition and adding a site that bypasses it is a test failure.

### The tests

`tests/test_checkpoint.py` builds a **real `best.pth` through `src/train/smoke.py`**, which
runs the real `train.main()` end to end on a synthetic fixture, then: asserts the
documented keys are present, asserts `"model"` is *not* (so a future divergence is
deliberate rather than silent), restores it into a model rebuilt from the run's own
`config.yaml` exactly as the notebook does, and **runs a forward pass** — because loading
without erroring is not the same as loading correctly.

### Relation to DECISION-048

Same root cause one layer up. -048 was a context the fixture did not have (a GPU); this
was an artefact the fixture did not produce (a real checkpoint). The rule generalises:
**a test that constructs its own version of an artefact tests the constructor, not the
artefact.** Where a real one can be produced cheaply — `smoke.py` does it in ~12 seconds —
the test uses the real one.

---

## DECISION-050 — The `outside` failure is real, but the `outside` THRESHOLD was mis-specified

- **Date:** 2026-08-26
- **Status:** Accepted. **Threshold change APPROVED and APPLIED 2026-08-26**; DECISION-046 amended in place.
- **Deviates from proposal:** No.

Phase 5 result: rim 1.217 PASS, **outside 2.342 FAIL**, rim on grades 3–4 1.087 PASS,
randomisation 0.410 PASS, interior 0.447.

Before diagnosing the mask, the prior question was whether the statistic itself is sound:
the CAM is 7×7 upsampled to 224, so one cell spans ~32 px and mass **must** bleed across
any mask boundary. Measured on the 20 real cached images held locally.

### Is it upsampling bleed? No.

| construction (through the exact CAM pipeline) | outside | interior |
|---|---:|---:|
| 7×7 cell value = fraction of that cell inside the retina (**the ideal null**) | **0.359** | 1.420 |
| 7×7 interior only, edge cells zero | 0.125 | 1.440 |
| 7×7 centre cell only | 0.112 | 1.419 |
| **untrained EfficientNet-B0, real cached images** | **0.615** | 1.182 |
| **the trained model (Phase 5)** | **2.342** | **0.447** |

A model attending in exact proportion to how much retina each cell contains scores
**0.359**. Bleed pushes a ratio *towards* 1.0; it cannot manufacture 2.342. **The
measurement is real** — the trained model puts 3.8× the mass outside that an untrained one
does, and less than half the fair share inside.

### Is it the mask? No — and DECISION-047's presumption was wrong

DECISION-047 said an `outside` failure means `retina_mask` is under-segmenting. Measured
on cached images, it is not:

- mean mask coverage **70.7%** (a circle inscribed in a square is 78.5%)
- **the mask is LARGER than the non-black region in every image** (e.g. 70.1% vs 66.0%),
  agreement 94–96%

So it is slightly *generous*, not under-segmenting. That branch of the failure path is
struck; the presumption was written without measuring.

### What WAS wrong: the threshold

`OUTSIDE_MAX = 0.5` was justified as "beyond the disc there is literally nothing to see,
so mass there is unambiguous artefact". **That reasoning was wrong.** Zero-padded
convolutions plus a 7×7 upsample put unavoidable mass at frame edges: an **untrained**
network scores 0.615 and already fails the gate. A threshold an untrained model cannot
pass is not measuring what it claimed to measure.

**Proposed:** `OUTSIDE_MAX = 1.0` — the fair-share expectation — with the nulls above
recorded as the calibration. **Not applied unilaterally.** Moving a gate threshold after
seeing a failing result is exactly what this project's pre-registration discipline exists
to prevent, so it needs explicit sign-off. What makes it defensible to propose at all:
**2.342 fails 0.5 and 1.0 alike, so the recalibration does not change this run's verdict**
— it only stops future runs failing for an artefact.

`tests/test_gradcam.py` now pins the nulls so the calibration is reproducible rather than
a paragraph.

### Does it implicate the cached images?

**No, not through this analysis.** `retina_mask` is used in two unrelated places: on
**raw** images during cache building (circle crop), and on **cached** images here. This
result concerns the second and says nothing about the first — and the cache reconciles
clean against its provenance.

**But there is a live hypothesis that does implicate the results**, and it is not a masking
question: **the model may be reading the black surround.** Its extent encodes the camera's
field of view, which is site-specific, which can correlate with disease prevalence. That is
a textbook shortcut and external validation (Phase 6) is precisely what punishes it.

`occlusion_delta(..., region="outside")` now exists and cell 3B runs it for whichever gate
failed. **Until that number exists, the cause is undetermined** and no rebuild is
triggered — the same discipline the rim path already has.

### What is settled

The **rim** result stands and is a genuine finding: 1.217 overall, **1.087 on grades 3–4**
— lower where peripheral disease lives. DECISION-016's erosion choice is supported by
evidence, which is what it was deferred to Phase 5 for. No rebuild is triggered by that
path.

---

## DECISION-051 — How the outside-occlusion number will be read, written before it exists

- **Date:** 2026-08-26
- **Status:** Accepted — **pre-registered**
- **Deviates from proposal:** No.

### First, a correction to the test itself

The occlusion test as written ran on the **200-image gate sample** (40 per grade). That is
wrong for `sens@spec>=0.95`: the operating point needs the **natural distribution**, and a
stratified 200 gives it roughly 80 non-referable images to estimate a 0.95 specificity
threshold from. The number would have been noise dressed as a measurement.

**The occlusion test runs on the FULL validation split (5,268 images).** It is
forward-only, so it costs seconds of GPU plus about a minute of mask computation, and it
makes the result directly comparable to the 0.7360 baseline. **The operating point is
fixed on the unoccluded data and reused** — re-optimising the threshold after occluding
would absorb the very effect being measured.

### O1 — the fill test, and why its threshold is 0.03 rather than 0.02

Replacing the surround with the interior's mean colour is a **much larger perturbation
than the rim equivalent**: the surround is black, so the fill is a black→grey change
across ~25% of the frame. A large response is therefore confounded with the fill simply
being out of distribution. The bar is set conservatively to account for that:

| `abs(Δsens)` on the full validation set | reading | action |
|---|---|---|
| **< 0.01** | correlate | documented limitation, no remedy |
| **0.01 – 0.03** | equivocal — the fill's OOD-ness could explain it | **decided by O2** |
| **>= 0.03** | real dependence | remedy, below |

0.03 also sits above the 0.025 seed range of this metric, so it clears the noise scale the
project already treats as meaningful — even though this particular comparison is paired
within one model and so is not itself seed-noisy.

### O2 — the actual test of the hypothesis

The hypothesis is not "the model reacts to a weird fill". It is **"the model reads how much
surround there is"**, because surround extent encodes field of view, which is site-specific,
which can correlate with prevalence. So the targeted perturbation **varies the amount of
surround** using the pipeline's own erosion operation, keeping every pixel in
distribution: `shrink_field_of_view` at **+0%, +3%, +6%, +9%** extra erosion (measured:
retina coverage 69.4% → 67.5% → 64.5% → 61.9%).

| result | reading |
|---|---|
| **monotone** trend in mean predicted grade with total `abs(Δ) >= 0.10` grade units | **field-of-view shortcut CONFIRMED** |
| non-monotone, or total `abs(Δ) < 0.10` | not a FOV shortcut; O1's effect was the fill being OOD |

Monotonicity matters more than magnitude: a shortcut on extent predicts a *trend*, whereas
a generic sensitivity to perturbation predicts noise.

### If it is real — the remedy, and why the obvious one is rejected

**Rejected: constant-fill the surround at preprocess time.** As anticipated, it does not
remove the information — a constant fill still marks exactly where the boundary is, so
field-of-view extent remains perfectly readable. It costs a ~12 h rebuild to move the
shortcut rather than remove it.

**Preferred: randomise the surround as a train-only augmentation.** Fill the masked-out
region with a per-image random constant (or noise) during training only. This breaks the
*correlation* between surround appearance and label without discarding any retina.

**It needs no cache rebuild** — augmentation is applied in `DRDataset` at load time. Cost
is a retrain (~40 min) plus **re-running stage 2's three seeds** (~2 h) because the model
changes: **~2.7 h, not 12 h.** Success is re-measured by re-running the gate and O2.

**Fallback if that fails: crop to the largest square inscribed in the eroded disc**, so
there is no surround to read at all. Rejected as first choice because an inscribed square
keeps only ~64% of the disc area and discards the periphery — colliding directly with
DECISION-016's reasoning about proliferative disease, and with grade 4 being the thinnest
class. It needs supervisor sign-off, not just a rebuild.

**In all cases** the EyePACS validation figures would be inflated by an amount not
estimable from EyePACS alone, and the write-up must say so.

### Phase 6 becomes a test of the hypothesis — and here is what would confirm it

Yes. But **a drop on APTOS confirms nothing on its own**, because domain shift predicts a
drop anyway (DECISION-031 already found pooling to be a null on the target domain). Two
things are diagnostic, and both are pre-registered here:

1. **Within-grade correlation between prediction and field of view, on APTOS.** For each
   true grade, correlate the predicted score against the image's retina-coverage
   fraction. **Confirmation: `abs(r) >= 0.2` within grades, and larger on APTOS than on
   EyePACS validation.** A model reading anatomy has no reason to show this; a model
   reading field of view does. This is inference-only and costs minutes.
2. **The paired comparison, if the augmentation remedy is applied.** Train
   surround-randomised arm E and compare the *APTOS drop* of the two models.
   **Confirmation: the randomised model loses less on APTOS**, even if it is equal or
   slightly worse on EyePACS validation. That trade — worse in-domain, better
   out-of-domain — is the signature of removing a shortcut, and is a thesis result in its
   own right.

Recording this now so that whichever way the APTOS number lands, it is read against a
prediction rather than explained after the fact.

---

## DECISION-052 — No-retina images are excluded from border statistics, counted, and reported

- **Date:** 2026-08-26
- **Status:** Accepted — **the user's proposed policy, adopted**
- **Deviates from proposal:** No.

Cell 3B died on the full validation split:

```
ValueError: retina mask is empty; the image is black or the mask is broken
  src/xai/border_check.py, region_masks, from occlusion_delta
```

`1986_left` is one of the four `ok:no-retina` images of DECISION-018, and it is in the
validation split. Cell 2's stratified 200 never drew it; cell 3B's 5,268 did.

### The policy

**Excluded from border statistics, counted, and reported.** Agreed, and for a reason
stronger than "the measurement is undefined": those four images took the preprocessing
fallback and were resized **without the square crop, without Ben Graham, and without the
surround mask** (DECISION-018). Including them would not merely add noise — it would
average a **different image domain** into a statistic about surround behaviour.

**They keep their place in every PERFORMANCE metric.** QWK, accuracy, sensitivity,
specificity and the reported operating point all still include them, because the model
does produce a prediction for them and dropping a row from those would be the silent
rebalancing DECISION-018 exists to prevent. It is *only* the border statistics that do not
exist for them.

### Two refinements the policy needs to be correct

**1. NaN, not skip.** The obvious implementation — `continue` past the image — leaves it
unoccluded, so `after - before` is exactly **0.0**. That is indistinguishable from
"occluding this image changed nothing", which is precisely the finding under test. A
skipped image would have quietly biased `dsens` toward the "it's only a correlate"
conclusion. `occlusion_delta` returns **NaN**, which cannot be mistaken for evidence and
cannot be silently averaged.

**2. The exclusion applies to BOTH ARMS.** A baseline over 5,268 images compared against
an occluded arm over 5,267 is not a paired comparison, and the difference would fold the
exclusion into the effect. Cell 3B now recomputes the baseline on the same subset and
prints both, so the reader can see the subsetting cost nothing. The same applies to O2:
the field-of-view sweep uses **the same images at every rung**, because a sweep whose
membership changes between rungs shows a "trend" that is really a change of denominator.

### Where it applies

`partition_borders()` is the one place the policy lives, so it cannot be implemented three
different ways in three notebooks. Applied at every site that runs over a full split:

| site | handling |
|---|---|
| cell 2, the gate ratios | caught, counted, passed to the gate CLI as `--n-border-undefined` |
| cell 3B O1, occlusion | NaN, excluded from **both** arms, count printed |
| cell 3B O2, FOV sweep | excluded identically at every rung, count printed |
| `shrink_field_of_view` | raises rather than returning an all-black frame |

`format_report` prints `EXCLUDED, no retina: N` whenever N > 0, so **the count is in the
gate's own output**, not only in a notebook log.

### The typed exception

`NoRetinaError(ValueError)` rather than a bare `ValueError`, so a full-split loop can
exclude these images **without also swallowing a broken mask, a corrupt decode, or a shape
mismatch**. Catching `ValueError` around 5,268 images would hide real bugs at exactly the
scale where they are hardest to notice.

### The pattern, again

This is the same shape as DECISION-048 and -049: **a case the small fixture never
contained.** A 200-image stratified sample drew none of the four; the full split has one.
Six tests now cover it, including the one that matters — that a no-retina image yields NaN
rather than 0.0.

---

## DECISION-053 — Phase 5 complete. The field-of-view shortcut is NOT supported, and O1 alone would have said otherwise

- **Date:** 2026-08-26
- **Status:** Accepted — **Phase 5 closed, no rebuild triggered**
- **Deviates from proposal:** No.

### The numbers

| gate (DECISION-046) | value | threshold | verdict |
|---|---:|---:|---|
| median rim mass ratio | 1.217 | < 1.5 | **PASS** |
| median outside mass ratio | 2.342 | < 1.0 | **FAIL** |
| median rim ratio, grades 3–4 | 1.087 | < 1.5 | **PASS** |
| median \|corr\| vs randomised | 0.410 | < 0.5 | **PASS** |
| interior (context, no gate) | 0.447 | — | — |

Follow-up on the `outside` failure, both arms on the same 5,267 images with one
`ok:no-retina` image excluded and counted (DECISION-052):

| test | result | pre-registered bar | reading |
|---|---|---|---|
| **O1** fill the surround with the interior mean | sens 0.7464 → 0.6929, **Δ −0.0534** | ≥ 0.03 = real dependence | crosses the bar |
| **O2** vary how *much* surround there is (+0/3/6/9% erosion) | 0.6209 / 0.6200 / 0.6194 / 0.6134, **total −0.0075**, monotone | monotone **and** ≥ 0.10 | **far under — not confirmed** |

### O1 and O2 disagree, and O2 settles it

**The field-of-view shortcut hypothesis is NOT supported.** O1's −0.0534 is the grey fill
being out of distribution: replacing a black surround with mid-grey across ~25% of the
frame is a large domain change, and the model's sensitivity to it says nothing about
whether it reads surround *extent*.

O2 varies exactly the quantity the hypothesis is about, using the pipeline's own erosion
so every pixel stays in distribution. A 12-percentage-point change in retina coverage
(69.4% → 61.9%) moves the mean predicted grade by **0.0075 grade units** — detectable,
monotone, and negligible. A model reading field of view would not behave like that.

**O1 alone would have produced the wrong conclusion.** −0.0534 against the 0.03 bar reads
as "real dependence", and the pre-registered remedy path would have been entered:
surround-randomising augmentation, a retrain, and re-running stage 2's three seeds —
roughly 2.7 hours spent on a premise that is false. The 0.03 bar and O2 existed precisely
to separate "reacts to a weird fill" from "reads the surround", and they did. This is the
clearest case so far for pre-registering the interpretation rather than reasoning about a
number after seeing it.

**Corollary for the write-up:** the `outside` gate as specified does not measure what it
was meant to. It flags any concentration of CAM mass beyond the disc, and 7×7 CAM cells
that straddle a high-contrast boundary produce that without any dependence. The gate is
retained as a **screen**, with O2 as the test that decides. Recorded so the failing number
is not quoted alone.

### What Phase 5 concluded

**No rebuild. No preprocessing change. No remedy.** DECISION-047's F2/F3 path and
DECISION-051's augmentation remedy are both **not entered.**

---

## The Phase 5 conclusion, as it goes into the thesis

> **Explainability and border-artefact analysis.**
>
> Grad-CAM and Grad-CAM++ were computed for the selected model (arm E, ordinal-regression
> head, EfficientNet-B0, 224 px, seed 42) over a seed-fixed stratified sample of 200
> validation images, 40 per grade. Because the head emits a single scalar rather than five
> class logits, gradients were taken with respect to that scalar, so each map answers what
> raised the predicted severity.
>
> **Resolution limit.** EfficientNet-B0 at 224 px produces a 7×7 final feature map, so one
> CAM cell corresponds to approximately 32×32 input pixels. **These maps therefore cannot
> localise individual lesions.** Microaneurysms, the defining lesion of grades 1–2, are
> sub-pixel at 224 px. The analysis resolves gross spatial attention only — optic disc,
> macula, vascular arcades, and the peripheral rim — and no lesion-level explanatory claim
> is made from it.
>
> **Method validity.** Before interpreting any map, the target layer's weights were
> randomised and the maps recomputed. Median absolute correlation between the two was
> **0.410**, below the pre-registered 0.5 threshold, confirming the maps are a property of
> the trained model rather than of image structure alone.
>
> **Border artefacts.** Attention was quantified as a mass ratio: the share of CAM mass in
> a region divided by that region's share of image area, so an indifferent model scores
> 1.0. Thresholds were fixed before any map was generated. Median rim mass ratio was
> **1.217** (threshold 1.5), and **1.087 on grades 3–4** — lower where peripheral disease
> appears. The 2.5% mask erosion adopted during preprocessing is therefore supported by
> evidence: the model is not keying on the vignetted boundary, including in the severity
> grades where the periphery matters most.
>
> Mass beyond the retinal disc measured **2.342**, exceeding its threshold. Two follow-up
> experiments were run on the full validation split. Replacing the surround with the
> retinal interior's mean colour reduced sensitivity at 95% specificity from 0.7464 to
> 0.6929 (Δ = −0.053). However, varying the *amount* of surround — re-eroding the retinal
> mask by a further 3%, 6% and 9%, which changes retinal coverage from 69.4% to 61.9%
> while leaving every pixel in distribution — changed the mean predicted grade by only
> **0.0075 grade units**. The first result therefore reflects the out-of-distribution
> nature of the substituted fill rather than a dependence on field of view, and **the
> hypothesis that the model exploits surround extent as a shortcut is not supported on
> this dataset.** One image with no detectable retina was excluded from all border
> statistics, counted, and reported; it remains in every performance metric.
>
> This conclusion is specific to EyePACS framing. External validation on APTOS
> (Section 6) retains a coverage-correlation diagnostic to test the same hypothesis under
> genuinely different acquisition.

---

## DECISION-054 — Phase 6 design, pre-registered: APTOS external validation

- **Date:** 2026-08-26
- **Status:** Accepted — **pre-registered before any APTOS inference**
- **Deviates from proposal:** No. §5 scopes APTOS as external validation for arms A–E.

Inference only, **~15 minutes**, no training. The EyePACS test set is **not** opened.

### What runs

**Arm E on EfficientNet-B0, all three seeds (42/43/44)**, over **all 3,662 APTOS images**
pooled (DECISION-004: `aptos_train` + `aptos_val` + `aptos_test` are one external set here;
the author-provided split is ignored). Three seeds because it is inference and costs
minutes, and because DECISION-042 is the standing reminder that a single seed is a draw —
the domain-shift drop is reported as a **range**, never a point.

**Arm F is excluded.** APTOS is its training data and cannot also be its external
validation set (DECISION-007).

### The rule that makes this external validation rather than a second fit

**The cut points and the operating-point threshold are carried over from EyePACS
validation, unchanged.** Re-fitting either on APTOS would be fitting on the external set,
which destroys the claim the phase exists to make. This is the single easiest way to
inflate the number, so it is fixed here in advance.

A **secondary** figure — APTOS QWK with cut points re-fitted on APTOS — is reported
alongside and clearly labelled, because the gap between the two separates **calibration**
shift from **discrimination** shift. That decomposition is genuinely useful and it is
never the headline.

### What is expected

**A drop is expected and is itself the finding.** No "acceptable" threshold is set,
because there is nothing here to accept or reject. The expectation is recorded only so it
is on the record: **QWK drops 0.05–0.15**, driven more by calibration than by
discrimination, so the re-fitted secondary figure should recover part of the gap.

APTOS is imbalanced in the same direction as EyePACS but less extremely — **49.3% grade 0
against 73.5%** — so "worse everywhere" is the wrong naive expectation: **balanced accuracy
may well rise while QWK falls.** Recorded so that outcome is not mistaken for a bug.

### The shortcut diagnostic — retained, and precisely why

DECISION-053 found no field-of-view shortcut, but **O2 varied surround extent on EyePACS
images only**. APTOS has genuinely different acquisition and framing, so the hypothesis is
**unsupported in-domain, not dead**. The diagnostic is inference-only and costs nothing.

For each true grade, correlate the predicted score against the image's retina-coverage
fraction:

| result | reading |
|---|---|
| |r| < 0.2 within grades, on both datasets | consistent with DECISION-053; the shortcut hypothesis is closed |
| **|r| >= 0.2 within grades AND larger on APTOS than on EyePACS validation** | the shortcut is real but invisible within one dataset's framing — reopen DECISION-051's remedy |
| |r| >= 0.2 on both, similar magnitude | coverage correlates with grade for a reason that is not a shortcut (e.g. acquisition quality tracks severity); report as a confound, not a defect |

The third row is why the test is a **comparison between datasets** rather than an absolute
threshold on APTOS alone.

### Deliverables

1. `src/eval/external.py` — carried-over-threshold evaluation plus the coverage
   diagnostic, with DECISION-052's no-retina policy applied.
2. `notebooks/phase6_aptos.py` — three cells, ~15 min.
3. Per-seed and pooled results in `runs/phase6_aptos_*/metrics.json`.
4. A limitations paragraph: APTOS `id_code` values carry no patient linkage, so each image
   is its own patient (DECISION-004). That is an APTOS-internal caveat, **not** a leakage
   risk for this evaluation, since no APTOS image was trained on under arm E.

---

## DECISION-055 — Analysis artefacts live in `analysis/`, fetched by a parallel path; panel.png is tracked

- **Date:** 2026-08-27
- **Status:** Accepted
- **Deviates from proposal:** No.

### Where they belong: `analysis/<name>/`, not `runs/`

Phase 5 produced JSON and a figure with **no `config.yaml`, `metrics.json` or
`train_log.csv`** — nothing was trained. Putting that in `runs/` would mean two
structurally different kinds of thing in one directory distinguished by nothing, and every
consumer that globs `runs/` would have to learn the difference. `runs/` means *a training
run*; `analysis/` means *analysis over one*. The Phase 5 set lands at
`analysis/phase5_gradcam_arm_e_efficientnet_b0/`, named for the run it analyses.

### Why `fetch_run` rejected them, and why that check was right

`find_run_dir` and `verify` hard-require `metrics.json`. That is not an oversight: those
checks are what make a committed run the record of a real execution (R4/R6). **Loosening
them to admit analysis output would weaken the guarantee for the artefacts that actually
need it.**

So `--artefacts NAME` is a second, parallel path that **reuses the download and auth
machinery** — the part that has actually cost sessions (kaggle 2.2.4, the shadowed
`~/.kaggle/kaggle.json`) — and applies verification appropriate to what an analysis set
is:

| | training run (`--run-id`) | artefact set (`--artefacts`) |
|---|---|---|
| located by | a dir named `<id>` containing `metrics.json` | a dir named `<name>` containing at least one `.json` |
| verified by | config/metrics/train_log present, metrics parse, `run_id` matches, R4/R6 checks | every JSON parses; **sha256 per file against `MANIFEST.json`** when present |
| installed to | `runs/<id>/` | `analysis/<name>/` |
| copies | a fixed `WANTED` list | **everything** except checkpoints |

Copying everything rather than an allowlist is deliberate: an allowlist would silently drop
a new artefact the day it is added, and an analysis set is by nature whatever the analysis
produced.

**Requiring at least one `.json`** is what stops an empty or half-written output directory
being installed and committed as though it were a result.

`write_manifest()` is called at the end of an analysis notebook so future fetches verify
**bytes**, not just parseability. The Phase 5 set predates it; that is reported explicitly
(`no MANIFEST.json in this set — JSON was parsed but bytes were not verified`) rather than
passing silently.

### `panel.png` is TRACKED, at full quality

The deciding question is not size, it is **reproducibility from the repo**. It is not
reproducible: regenerating it needs `best.pth` (gitignored, Kaggle-only), the 0.8 GB
preprocessed cache, and a GPU session. **A file that cannot be regenerated from the repo
is a record, not a derivative**, and the project's rule is that records are committed.

3.84 MB, once. Recompression was measured — optimised PNG 3.77 MB, RGB at maximum
compression 3.29 MB — a 14% saving not worth losing "these are the exact bytes the run
produced". It is committed **once per phase**; if Phase 5 is ever re-run, the replacement
is deliberate and the old figure is superseded, not accumulated.

The JSON beside it is what makes it evidence rather than decoration: `ratios.json` carries
all 200 per-image measurements, so any claim made from the figure can be checked against
numbers.

---

## DECISION-056 — The panel is the pre-registered draw. Verified, not asserted.

- **Date:** 2026-08-27
- **Status:** Accepted — **verified by reproduction**
- **Deviates from proposal:** No.

The panel is 20 images and the eye cannot tell a pre-registered sample from a curated one.
So it was checked rather than claimed: the draw was **reproduced locally** from the
committed `data/splits/val.csv` and the pre-registered seed `20260825`, and compared
against what the run actually used.

**`ratios.json`'s 200 rows are identical, in order, to the reproduced sample.** That is
proof the run used the pre-registered draw — the order is a property of the seeded
`rng.choice` and would not survive any reselection. The 20 panel images are a subset of
those 200, drawn by the next call on the same generator.

`analysis/.../panel_provenance.json` now records the seed, the parameters, all 200 sample
paths and the 20 panel paths with labels, so the check does not have to be re-derived.

**A gap this exposed:** `panel.png` was not self-describing. The figure did not record
which images it showed, so its provenance was only reconstructible because the draw is
deterministic. Analysis notebooks now write the image list beside the figure.

**One honest caveat for the write-up.** The panel is drawn **uniformly from the balanced
200**, so its own grade distribution is uneven — 6/1/3/6/4 across grades 0–4, with only
**one grade-1 image**. It is an unbiased sample of the analysis set, not a per-grade
exhibit, and a caption implying even coverage would be wrong.

---

## DECISION-057 — What would make the model NOT deployable outside its training population

- **Date:** 2026-08-27
- **Status:** Accepted — **pre-registered before Phase 6 runs**
- **Deviates from proposal:** No.

Written before the APTOS number exists, because "degraded but usable" is exactly the
judgement that drifts when you are looking at your own result.

### First, the framing the question needs

**"Deployable" is not a claim this thesis can make either way.** The model already fails
the screening floor **in-domain**: sens@spec>=0.95 is **0.7360** over three seeds against
the 0.80 required (DECISION-032, itself provisional). No external result can make a system
deployable when it is below the floor on its own training distribution.

So the question Phase 6 actually answers is narrower and answerable: **does this model
generalise beyond its training population, or does it work only there?** The wording below
is fixed accordingly, and the thesis must not slide from "generalises" to "deployable".

### The instrument: carried-over vs re-fitted

**Calibration shift is fixable; discrimination collapse is not.** Local threshold fitting
on site data is a normal, documented deployment step. Losing the ability to *rank* severity
is not recoverable by any thresholding.

DECISION-054 already reports both. **The generalisation line is therefore drawn on the
RE-FITTED number**, because that is the one that isolates discrimination. The carried-over
number stays the headline for the domain-shift finding.

### DOES NOT GENERALISE — any ONE of these

| # | criterion | why this line |
|---|---|---|
| G1 | **re-fitted APTOS QWK < 0.60** | the Phase 3 baseline — an 8-epoch ResNet18 — scored **0.6138** on EyePACS validation. Falling below that externally means the entire ablation buys nothing outside the training population. |
| G2 | **re-fitted sens@spec>=0.95 < 0.60** | in-domain is 0.7360 against a 0.80 floor. 0.60 means missing 40% of referable disease at the specificity one would deploy at — below any plausible screening utility. |
| G3 | **grade 3–4 recall < 0.30 while grade 0 recall > 0.90** | a specific dangerous *shape*, not uniform degradation: the model is most reliable exactly where it matters least. This is caught separately because G1 and G2 can both pass while it is true. |
| G4 | **coverage-correlation confirms the shortcut** (|r| >= 0.2 within grades AND larger on APTOS than EyePACS) | the model would be working for a reason that does not transfer. This invalidates the deployment claim **regardless of the headline number**, which is why it is a criterion and not a footnote. |

Any one of these and the thesis states plainly: **this model does not generalise beyond
its training population, and the in-domain results should be read as an upper bound.**

### DEGRADED BUT USABLE — requires ALL of these

- re-fitted QWK **>= 0.65**, and
- re-fitting recovers **>= half** the carried-over drop (i.e. the loss is mostly
  calibration), and
- none of G1–G4.

Then the finding is: **the model generalises, with a domain-shift penalty that is
predominantly calibration.** The write-up must state the condition attached —
**deployment in a new population would require local recalibration on site data; the
EyePACS thresholds are not transferable** — rather than reporting the re-fitted number as
if it were free.

### The middle band, named so it cannot be rounded up

Re-fitted QWK **0.60–0.65**, or re-fitting recovering less than half the drop:
**"generalises weakly; not usable without further work."** This band exists specifically
because it is the one a motivated reader rounds towards the better neighbour. It is
neither of the other two verdicts and must be reported in these words.

### Fixed regardless of outcome

1. The **carried-over** figure is the headline. The re-fitted figure is secondary and
   always labelled.
2. The APTOS result is reported as a **three-seed range**, never a point (DECISION-042).
3. A drop is expected and is a finding, not a failure.
4. **Balanced accuracy may rise while QWK falls** — APTOS is 49.3% grade 0 against 73.5% —
   and that is not evidence of generalisation.

---

## DECISION-058 — A NaN passed a verdict criterion; G4 was reported as passing when it was undecided

- **Date:** 2026-08-28
- **Status:** Accepted — bugs fixed, criterion ambiguity resolved
- **Deviates from proposal:** No.

### The NaN

`verdict()` printed `fraction of the drop recovered: nan` and then reported a clean
verdict. Diagnosis:

```
drop      = eyepacs_qwk - carried_qwk = 0.7563 - 0.7902 = -0.0339      # NEGATIVE
recovered = (refit - carried)/drop if drop > 0 else nan                 # -> nan
usable    = refit >= 0.65 and (not isfinite(recovered) or recovered >= 0.5)
                                    ^^^^^^^^^^^^^^^^^^^^^^^^ passed THROUGH the NaN
```

**APTOS QWK came in ABOVE EyePACS**, so the drop was negative and `recovered` was NaN —
and the usable branch treated "could not compute this" as "criterion satisfied".

**Did it change the determination? No — and that is not a defence.** There genuinely was
no drop, so there was nothing to recover and the verdict stands on its merits. But it was
*reached* through a branch that would equally have passed a genuinely unknown value. The
same code with a missing field would have produced the same clean verdict.

**The fix distinguishes three states, not two:**

| state | meaning | criterion |
|---|---|---|
| `measured` | drop > 0, recovery is a real fraction | must be >= 0.5 |
| `not applicable — QWK did not drop` | drop <= 0, nothing to recover | **vacuously satisfied, and says so** |
| genuinely unknown | a value is missing | **fails** — never satisfies |

The printed line now reads `not applicable — QWK did not drop` instead of `nan`.

### G4 was reported as `ok` when it had not been computed

`verdict()` took `shortcut_eyepacs=None` and evaluated G4 to `False`, which printed as
`ok  G4_shortcut_confirmed` — indistinguishable from a criterion that had been checked and
passed. **The same class of error as the NaN hatch**: an uncomputed check presented as a
passing one.

G4 now has an explicit `undecided` state, and the verdict carries
`[PROVISIONAL: G4 is UNDECIDED …]` until both sides exist.

### max vs median — an ambiguity in DECISION-054, resolved

DECISION-054 wrote only "|r| >= 0.2 within grades", which does not say whether the
statistic is the maximum or the median across the five grades. The code used **max**. That
ambiguity was mine and it is resolved here rather than silently settled now that the
numbers exist.

**Resolved to max**, on two grounds:

1. **Max is the conservative choice for a safety check** — it flags more readily, which is
   the right bias for "is the model taking a shortcut".
2. The obvious objection — *the maximum of five noisy correlations exceeds 0.2 by chance* —
   is answered by the criterion already being a **between-dataset comparison on the same
   statistic**, so a selection effect present on both sides cancels. `G4_MIN_N = 100` is
   added so a small grade cannot trigger it alone.

**And on this data the objection does not apply anyway.** The maximum is on **grade 0 in
all three seeds** — n = 1,805, the largest grade — with a consistent negative sign:

| seed | g0 | g1 | g2 | g3 | g4 | max | median |
|---|---:|---:|---:|---:|---:|---:|---:|
| 42 | **−0.3285** | −0.2032 | −0.0713 | −0.0876 | −0.0858 | 0.3285 | 0.0876 |
| 43 | **−0.1345** | −0.1275 | +0.0025 | −0.0603 | +0.0096 | 0.1345 | 0.0603 |
| 44 | **−0.2451** | −0.1530 | −0.0374 | −0.0741 | −0.1169 | 0.2451 | 0.1169 |

That is not the max-of-five artefact. It is a consistent effect on the largest grade,
which is precisely why the EyePACS comparison decides it rather than the APTOS number
alone. The direction — more retinal coverage, *lower* predicted grade — has an innocent
reading (on normal eyes, better framing means a clearer "definitely normal") that would
show on **both** datasets.

### The gap this exposed in the tooling

`notebook_check` validated every command line and **passed a cell containing a
SyntaxError**, because the damaged line was not a subprocess invocation and nothing else
ever parsed the cell. Phase 6 cell 4 shipped broken. `cell_syntax_problems()` now
`ast.parse`s every cell and `main()` refuses before checking invocations, with two tests —
one that every real cell parses, one that the checker actually detects a broken cell.

---

## The Phase 6 conclusion, as it goes into the thesis

> **External validation on APTOS.**
>
> The selected model (arm E, ordinal-regression head, EfficientNet-B0, 224 px) was
> evaluated on all 3,662 APTOS images across three training seeds. No APTOS image was seen
> during training. **The cut points and the referral threshold were carried over from
> EyePACS validation unchanged**; re-fitting them on APTOS would constitute fitting on the
> external set and is reported separately and explicitly below.
>
> **Headline, carried-over decision rules.** Quadratic weighted kappa was **0.7902**
> (seeds: 0.7810 / 0.7920 / 0.7976) against **0.7563** on held-out EyePACS validation.
> Referable sensitivity was **0.990** (0.9926 / 0.9892 / 0.9886) at specificity **0.83**,
> and overall accuracy **0.58**.
>
> **These figures require careful reading, and two of them are not what they appear.**
>
> *First, the apparently improved kappa is not evidence that the model performs better
> externally.* Quadratic weighted kappa is chance-corrected against the marginal label
> distribution, and the two datasets differ substantially in that distribution — 49.3% of
> APTOS images are grade 0 against 73.7% of the EyePACS validation split. A more even
> distribution admits a higher kappa for the same underlying discriminative ability.
> **Kappa is therefore not directly comparable across the two datasets**, and no claim of
> improvement is made from it.
>
> *Second, the referable sensitivity of 0.990 is over-referral, not superior detection.*
> The referral threshold was fixed on EyePACS to achieve 95% specificity. Under domain
> shift the score distribution moves, so on APTOS that same threshold sits far lower
> within the distribution and the model refers almost every image. Sensitivity rises to
> 0.99 precisely because specificity falls to 0.83 and accuracy falls to 0.58 — barely
> above the 49.3% majority-class rate. **This is a mis-set operating point, and it is the
> clearest single measurement of the calibration shift.**
>
> **Secondary, with cut points re-fitted on APTOS.** Kappa **0.8802** and sensitivity at
> 95% specificity **0.7707**. The gap between the carried-over and re-fitted figures
> isolates the nature of the domain shift: **discrimination transfers, calibration does
> not.** The model's ability to rank severity is preserved on unseen data from a different
> acquisition setting, while the decision thresholds derived on EyePACS are not
> transferable to it.
>
> **Verdict against pre-registered criteria.** Four criteria for failure of
> generalisation were fixed before the evaluation was run (re-fitted kappa below 0.60;
> re-fitted sensitivity below 0.60; collapse of grades 3–4 while grade 0 remained intact;
> and confirmation of a field-of-view shortcut). None was met. The model **generalises,
> with a domain-shift penalty that is predominantly calibration** — subject to the stated
> condition that **deployment in a new population would require local recalibration on
> site data, as the EyePACS thresholds are demonstrably not transferable.**
>
> **This is a generalisation result, not a deployment claim.** The system does not meet
> the 80% sensitivity at 95% specificity screening reference in-domain (0.7360 across
> three seeds), and external validation does not alter that.

---

## DECISION-059 — G4's seed-aggregation rule was NOT pre-registered. Said plainly.

- **Date:** 2026-08-28
- **Status:** Accepted — with the weakness stated rather than smoothed
- **Deviates from proposal:** No.

### What was actually applied, and it is not 2-of-3

`notebooks/phase6_aptos.py` cell 4 computes the **seed means** and passes those to
`verdict()`:

```
mean EyePACS 0.1367   mean APTOS 0.2360   ->  0.2360 >= 0.2 and 0.2360 > 0.1367  -> FIRES
```

So the criterion fired on **the mean across seeds**, not on a 2-of-3 vote. The per-seed
"APTOS larger?" column printed beside it is informational and does not enter the decision.

### Was it pre-registered? No.

DECISION-054 wrote the criterion as "|r| >= 0.2 within grades AND larger on APTOS than
on EyePACS validation". DECISION-058 resolved the ambiguity **across grades** (max, not
median). **Neither said how to aggregate across seeds.** That rule is being settled now,
after seeing the numbers, and this decision exists so that is on the record rather than
absorbed silently.

**What limits the damage, and it is not nothing:** DECISION-042 is a standing project rule
— *report the mean across seeds, never the best seed* — and it points at the mean. So the
aggregation used is the one existing policy already implied, not one selected because it
gave a result. But it was not fixed **for G4** in advance, and that is a real gap in a
project whose whole method is pre-registration.

### Robustness — the conclusion under every plausible rule

| aggregation | EyePACS | APTOS | fires? |
|---|---:|---:|---|
| **mean** (applied) | 0.1367 | 0.2360 | **yes** |
| median | 0.1418 | 0.2451 | yes |
| majority of seeds | — | 2 of 3 | yes |
| **unanimity** | — | 2 of 3 | **no** |

Three of four fire. Only unanimity does not. The verdict does not hinge on the
undocumented choice — but it does hinge on not requiring unanimity, which is itself an
aggregation choice nobody wrote down.

### The honest strength of the claim

| seed | EyePACS | APTOS | difference | clears 0.2? | r² |
|---|---:|---:|---:|---|---:|
| 42 | 0.1418 | 0.3285 | +0.1867 | yes | 0.108 |
| 43 | 0.1265 | 0.1345 | **+0.0080** | **no** | 0.018 |
| 44 | 0.1419 | 0.2451 | +0.1032 | yes | 0.060 |

**The claim that survives scrutiny is narrower than "the model uses a shortcut":**

> Shortcut-like dependence on retinal framing is present in **two of three training runs**
> and effectively absent in the third. Averaged over seeds it exceeds the pre-registered
> threshold. Where present it is **modest**, explaining **6–11%** of within-grade-0 score
> variance; in the third run it explains 1.8% and sits below the threshold, with an
> APTOS-over-EyePACS margin of **+0.008**, which is nothing.

The direction is consistent — APTOS exceeds EyePACS in all three seeds — but seed 43's
margin is small enough that "3 of 3 on direction" would be a misleading way to put it, and
it is not put that way anywhere in the write-up.

**The most defensible framing, and the more interesting one:** because the effect varies
this much by seed, it is a property of the **training procedure** — which sometimes
produces a framing-dependent model — rather than a fixed property of the architecture or
the data. That is a stronger claim about method than about this particular checkpoint.

### For the thesis, not only for this log

The methods chapter states this in its own words rather than leaving it here:

> The rule for aggregating the field-of-view diagnostic across training seeds was **not
> fixed in advance**. The criterion (DECISION-054) and its resolution across grades
> (DECISION-058) were pre-registered; the seed rule was settled after the numbers were
> seen. The rule applied is the **mean across seeds**, which is the project's standing
> reporting rule (DECISION-042) and therefore the one existing policy already implied.
> The criterion fires under three of the four plausible rules — mean, median and
> majority — and not under unanimity. The finding does not depend on the undocumented
> choice, but it does depend on not requiring unanimity, which is itself a choice that
> was never written down.

An examiner who finds this unaided reads it as a result selected to fire. Stated plainly
it is a limitation with its robustness already measured, which is what it actually is.

### R4 note

At the time of writing, `analysis/phase6_aptos/coverage_correlation_eyepacs.json` is
**not in the repository** and `verdict.json` still holds the pre-cell-4 state. The numbers
above are as reported from the console. **They must be fetched and committed before any of
this enters the thesis** (R4: every number traces to a committed artefact).

---

## DECISION-060 — The Phase 6 conclusion, and what the shortcut finding does to Phases 7 and 8

- **Date:** 2026-08-28
- **Status:** Accepted
- **Deviates from proposal:** No.

### The project's headline conclusion changes

It was: *a validated, imbalance-aware, explainable DR grading system, below the screening
sensitivity floor.* It is now that **plus a demonstrated generalisation defect**.

**State the verdict precisely, because the wording invites a wrong reading.** "Does not
generalise" here does **not** mean performance collapsed externally — it did not. G1, G2
and G3 all passed comfortably. It fired on **G4 alone**: the model shows a dependence on
retinal framing that is stronger out-of-domain than in-domain, and DECISION-057 fixed in
advance that this invalidates the generalisation claim *regardless of the headline
numbers*, because a model working partly for a reason that does not transfer cannot be
said to generalise on the strength of numbers that reason inflates.

---

## The Phase 6 conclusion, as it goes into the thesis

> **External validation on APTOS.**
>
> The selected model (arm E, ordinal-regression head, EfficientNet-B0, 224 px) was
> evaluated on all 3,662 APTOS images across three training seeds, with **cut points and
> the referral threshold carried over unchanged from EyePACS validation**. No APTOS image
> was seen during training.
>
> **Headline.** Quadratic weighted kappa **0.7902** (0.7810 / 0.7920 / 0.7976) against
> 0.7563 on held-out EyePACS validation; referable sensitivity **0.990** at specificity
> **0.83**; accuracy **0.58**.
>
> **Two of those figures are not what they appear.** Kappa is chance-corrected against the
> marginal label distribution, and the datasets differ substantially — 49.3% of APTOS
> images are grade 0 against 73.7% of EyePACS validation — so **kappa is not directly
> comparable across them** and the apparent improvement is not evidence of better external
> performance. The sensitivity of 0.990 is **over-referral, not superior detection**: the
> threshold was fixed on EyePACS for 95% specificity, and under domain shift it sits far
> lower in the APTOS score distribution, so the model refers almost every image.
> Sensitivity rises precisely because specificity falls to 0.83 and accuracy to 0.58,
> barely above the 49.3% majority rate. That is the clearest single measurement of the
> calibration shift.
>
> **With cut points re-fitted on APTOS** (secondary, never the headline): kappa **0.8802**,
> sensitivity at 95% specificity **0.7707**. The gap between carried-over and re-fitted
> isolates the shift: **discrimination transfers; calibration does not.** The ability to
> rank severity survives the change of acquisition setting; the decision thresholds derived
> on EyePACS do not.
>
> **The field-of-view diagnostic, and the methodological finding.** Within each true grade,
> the predicted score was correlated against the fraction of the frame occupied by retina.
> On APTOS the maximum within-grade correlation was 0.3285 / 0.1345 / 0.2451 across seeds
> (mean 0.2360); on EyePACS validation, 0.1418 / 0.1265 / 0.1419 (mean 0.1367). The
> dependence is therefore **stronger on the external dataset than on the training
> distribution**, which was the pre-registered criterion for a framing shortcut.
>
> The effect is **modest and seed-dependent**: it clears the threshold in two of three
> training runs and explains 6–11% of within-grade score variance where present, against
> 1.8% in the third run. It is best characterised as a property of the **training
> procedure**, which sometimes produces a framing-dependent model, rather than as a fixed
> property of the architecture.
>
> **This is the methodological point of the chapter.** The same hypothesis was tested
> in-domain during Phase 5 and found *unsupported*: varying how much surround an EyePACS
> image contained, by re-eroding the retinal mask by up to 9%, moved the mean predicted
> grade by 0.0075 grade units — an order of magnitude below the threshold for a real
> dependence. **The shortcut was invisible within the training distribution and became
> visible only under the between-dataset comparison.** An in-domain perturbation test can
> only vary framing across the range that dataset happens to contain; a second dataset
> with genuinely different acquisition supplies variation the first cannot. Single-dataset
> shortcut analysis is therefore not conservative — it is systematically blind to precisely
> the dependencies that matter for deployment, because those are the ones that only differ
> across populations.
>
> **Verdict.** Of four pre-registered criteria for failure of generalisation, three passed:
> discrimination did not collapse, sensitivity did not collapse, and the severe grades did
> not degrade while the normal grade held. The fourth — confirmation of a framing shortcut
> — was met. Under the rule fixed before the evaluation, **the model does not generalise
> beyond its training population, and the in-domain results should be read as an upper
> bound.** This reflects a demonstrated dependence that does not transfer, not a collapse
> in measured performance.

---

### What it does to Phase 7 — the web application

The app now deploys a model with a **measured** defect, and the interface must reflect
that rather than presenting a grade with unqualified confidence.

**The disclaimer must state, specifically and not in general terms:**

1. Research prototype. **Not a medical device**; not for clinical use.
2. **Below the screening reference in-domain**: referable sensitivity 0.7360 at 95%
   specificity, against a 0.80 reference that is itself provisional (DECISION-032).
3. **Demonstrated dependence on image framing**, stronger on external data than on the
   training distribution (DECISION-059), present in two of three training runs.
4. **Thresholds are not transferable.** Any use on a new population requires local
   recalibration; the shipped thresholds were fitted on EyePACS.

**Beyond a disclaimer — a guard, which is the better engineering answer.** The failure
mode is now *known and measurable*, so the app should not merely warn in the abstract: on
upload it computes the retina-coverage fraction and **flags an image whose framing falls
outside the range the model was trained on**. That converts a finding into a control, and
it is a stronger Phase 7 contribution than a paragraph of text. The same
`region_masks`/coverage code from Phases 5 and 6 is reused, so it costs little.

### What it does to Phase 8 — the write-up

- The limitations section gains a **measured, quantified** entry in place of the usual
  boilerplate about generalisation.
- The Phase 5 → Phase 6 sequence becomes a **methodological contribution in its own
  right**, not a footnote: an in-domain perturbation test cleared the model, and only the
  between-dataset comparison exposed the dependence.
- The honest overall claim: **a rigorously validated system that does not meet the
  screening reference and shows a demonstrated generalisation defect** — which is a
  stronger thesis than an unexamined system reporting a better number, and should be
  presented as such rather than apologised for.

---

## DECISION-061 — The remedy is triggered, and it should DISPLACE the 384 ablation

- **Date:** 2026-08-28
- **Status:** **Proposed — needs your decision.** The trigger is automatic; the
  re-prioritisation is not.
- **Deviates from proposal:** No. 384 was always optional (DECISION-005/044).

### Is it triggered? Yes, formally

DECISION-051 fixed the remedy in advance: **randomise the surround as a train-only
augmentation**, which breaks the correlation between surround appearance and label without
discarding retina, and needs **no cache rebuild** because augmentation is applied at load
time.

| step | cost |
|---|---|
| Implement + smoke the augmentation | ~30 min local |
| Retrain arm E, 3 seeds | ~2.0 h |
| Re-run Phase 6 to test whether it worked | ~18 min |
| **Total** | **~3 h** |

### The recommendation: it displaces 384, not adds to it

| | cost | what it buys now |
|---|---:|---|
| **Remedy** | ~3 h | tests whether the demonstrated defect is fixable; converts a correlational finding into a causal one **either way** |
| **384 ablation** | ~11 h | in-domain sensitivity, on a headline that the proposal fixes at 224 so it **cannot become the headline** without a supervisor deviation |

The priorities inverted the moment G4 fired. Before it, the open problem was the
sensitivity floor and 384 was the last untested lever. Now there is a **demonstrated
generalisation defect**, and spending 11 hours squeezing in-domain sensitivity while
leaving it untested would be optimising the number that Phase 6 just showed is an upper
bound. **Net effect of the swap: 8 hours saved and a better thesis.**

### Pre-registering the remedy's outcome, before it runs

The effect being remedied is **modest and seed-dependent** (DECISION-059: two of three
seeds, r² 6–11% where present). A three-seed test of a three-seed effect is **underpowered
by construction**, and that is stated now rather than discovered afterwards.

| outcome | reading |
|---|---|
| APTOS max \|r\| drops below EyePACS **and** below 0.2, in ≥ 2 of 3 seeds | **remedy works.** The causal story is confirmed: the model was reading the surround. |
| \|r\| unchanged within seed noise | **remedy fails, and the shortcut interpretation weakens** — the correlation may be a confound the augmentation cannot touch. Report both. |
| \|r\| drops but external QWK/sensitivity drops with it | the framing signal carried real information; report the trade-off honestly rather than as a fix |

**Every outcome is publishable**, which is what makes the 3 hours worth spending: a failed
remedy falsifies the shortcut interpretation, which is itself a result and one this project
would otherwise have no way to obtain.

### Stronger demonstrated-and-remedied, or demonstrated-and-reported?

**Remedied, if the remedy is pre-registered as above** — because an intervention that
changes the measured dependence is the only evidence available that the correlation is
causal rather than coincidental. Reported-only leaves the thesis's central negative finding
resting on a correlation in two of three runs.

But this holds **only** with the outcomes fixed in advance. Running it, getting an
ambiguous result, and then deciding what counts as success would be worse than not running
it — it would convert a clean finding into a muddy one.

### If time is short

**Report-only is a complete and defensible thesis.** The finding stands on its own, the
methodological point (Phase 5 in-domain vs Phase 6 between-dataset) is intact, and the
limitations section is concrete. The remedy strengthens it; it is not load-bearing.

---

## DECISION-062 — The 384 ablation is deliberately NOT run

- **Date:** 2026-08-29
- **Status:** Accepted — the swap is approved; 384 is dropped, the remedy takes its slot
- **Deviates from proposal:** No. 384 was always optional (DECISION-005/044).

### Not run, and this is the reason

| | cost | what it would buy |
|---|---:|---|
| 384 ablation | **~11 h** | in-domain sensitivity on a headline fixed at 224 |
| surround remedy | **~3 h** | a causal test of the one demonstrated defect |

**It optimises a number Phase 6 has already shown is an upper bound.** G4 fired: the
in-domain figures are inflated by a dependence that does not transfer (DECISION-060).
Spending eleven hours raising in-domain sensitivity, while leaving untested the finding
that in-domain sensitivity overstates the model, is work aimed at the wrong quantity.

**And it could not have become the headline anyway.** The proposal fixes 224 for all
headline results. A 384 win would have needed supervisor sign-off as a deviation before
it could be reported as the main result; without that it is an appendix table.

**This is not a null result and must not be written up as one.** 384 was never run, so
nothing is known about it. The write-up says it was **not run, and why** — a resolution
ablation that is skipped and reported as skipped is honest; one that is skipped and
quietly implied to have been a tie is not.

**Cost of being wrong:** if 384 would have cleared the 0.80 screening floor, that is
missed. Judged unlikely — stage 3.5 moved B0→B2 (a capacity increase of the same kind)
without clearing it — but it is a real risk and it is recorded here rather than
discovered later.

**Net:** 8 hours returned to the project, and the remaining GPU budget spent on the open
problem rather than on the closed one.

---

## DECISION-063 — The remedy runbook, pre-registered before it runs

- **Date:** 2026-08-29
- **Status:** Accepted — **pre-registered**. Written before a single remedy epoch.
- **Deviates from proposal:** No.
- **Implements:** DECISION-051's remedy, DECISION-061's approved swap.

### What is manipulated — exactly one thing

`configs/remedy_surround.yaml`, an overlay on arm E:

```
augment:
  surround_randomisation: 0.75
```

On 75% of **training** draws, the masked-out surround is replaced by a per-image random
constant colour, sampled per channel from U(0,1). Head, loss, schedule, epochs, seeds,
splits and cache are untouched. Cell 1 **asserts** that exactly one config key differs
between the baseline and remedy merges, rather than trusting it.

**0.75 and not 1.0.** Validation and test are never augmented, so their surround is
always black. A model that never saw a black surround in training would be evaluated
slightly out of distribution, and an in-domain drop caused by *that* would be
indistinguishable from an in-domain drop caused by removing the shortcut. A quarter of
draws stay black to keep the evaluation condition inside the training distribution.

**No cache rebuild; negligible cost.** Applied at load time. The extra mask costs a
measured **1.19 ms/image** — about 29 s per epoch on one worker against a ~76 s epoch,
fully hidden by two workers.

### Two measurements made before choosing the factor, and one correction

DECISION-051 pre-registered *appearance* randomisation. Before implementing it, both
candidate manipulations were measured locally on a synthetic disc:

| candidate | measured | verdict |
|---|---|---|
| **extent** — how much surround | the existing affine already moves coverage over **0.611–0.864, sd 0.075** — a *wider* range than the entire Phase 5 erosion sweep (0.694 → 0.619) | **rejected as primary.** Already present; a null from it would mean nothing |
| **appearance** — what it looks like | the surround stays essentially black in **96%** of draws (mean surround value 0.011 after jitter) | **chosen.** Genuinely absent from training |

**A correction on the record.** The first appearance probe indexed the surround with the
**unrotated** disc mask, so retina rotated into that region counted as "lifted" surround
and the probe reported the surround was already randomised in 89% of draws. That was
wrong, and it pointed at the opposite conclusion. The corrected probe warps an indicator
channel through the same geometry — which is also how the augmentation itself is
implemented, for the same reason.

**A side finding worth keeping.** Because the existing augmentation already jitters
coverage substantially, a coverage→label association cannot be *eliminated* by that
jitter, only **attenuated** — per-image baseline coverage differences survive random
scaling in expectation. That is consistent with the effect actually observed being
modest and seed-dependent rather than strong.

### What the remedy does NOT do

It does not remove the boundary. A random constant still marks exactly where the retina
ends — DECISION-051 says so outright. Measured on the fixture at 0.7× scale, near-black
falls from 0.688 of the frame to 0.016, and the residue is **entirely the bilinear
interpolation rim**: 708 px inside the warped mask, 70 px within 2 px of it, **0 px
beyond**. What is removed is the surround's appearance as a stable, noise-free cue —
"fraction of the frame that is black" is a feature a global pool computes for free, and
after this it is not.

### The prediction, fixed in advance

**Primary endpoint:** G4 recomputed on the remedied model — the seed **mean** of the max
within-grade |r|, on APTOS and on EyePACS validation. **The aggregation rule is fixed HERE, in
advance, this time** (DECISION-042); all four rules are printed alongside.

| outcome | criterion | reading |
|---|---|---|
| **WORKS** | APTOS mean < 0.20 **and** ≤ EyePACS mean **and** direction ≤ 1/3 | the shortcut reading is supported **causally**, not only correlationally |
| **FAILS** | APTOS mean ≥ 0.20 **and** > EyePACS mean | **the shortcut reading weakens.** Most likely a confound — coverage tracking acquisition quality, which tracks severity. Phase 6's generalisation finding stands; the word "shortcut" comes out of the write-up |
| **TRADE-OFF** | |r| falls **and** external QWK or sensitivity falls with it | the framing signal carried real information. Report both, claim neither |
| **AMBIGUOUS** | anything else | three seeds were not enough. Reported as ambiguous |

**Secondary** (DECISION-051's own paired test): the remedied model should **lose less on
APTOS** than the baseline, even if equal or slightly worse on EyePACS. Worse in-domain,
better out-of-domain is the signature of removing a shortcut.

**In-domain cost, against a measured noise scale:** baseline arm E validation QWK is
0.7615 / 0.7534 / 0.7560 — mean **0.7570**, range **0.0081**. Inside ±0.0081 is not a
detectable cost. Below **0.7489** it is a real one, and it is the pre-registered *price*
of the remedy, not a failure of it: the endpoint is external.

### Power — the part that is not reassuring

The baseline APTOS |r| ranged **0.194 across seeds** (0.3285 / 0.1345 / 0.2451). A three-seed
test of an effect with that seed range **cannot** separate "the remedy removed a modest
dependence" from "the seeds landed differently".

> A drop from 0.2360 to 0.15 is **inside the baseline's own seed range** and proves
> nothing on its own.

So the decisive readings are the ones that do not rest on magnitude: the **direction
count** (3/3 baseline → at most 1/3) and **agreement across all four aggregation rules**.
Both are reported. An ambiguous landing is **reported as ambiguous** — no re-analysis
until something crosses a line.

**Every outcome is reported**, whichever way it goes. That was the condition for running
it at all, and a failed remedy is the more interesting result: it falsifies the shortcut
interpretation, which nothing else in this project can do.

### How to run it

`notebooks/phase6_remedy.py`, four cells, ~2.5 h. Cell 1 refuses to start unless the
Phase 6 artefacts are attached, so the baseline it compares against is read from
committed files rather than retyped from a console log (R4).

---

## DECISION-064 — The splits vanish mid-run. Recorded as unexplained, and survived.

- **Date:** 2026-08-29
- **Status:** Accepted — a workaround with the cause **not** established
- **Deviates from proposal:** No.

### The observation, and a correction to my own first diagnosis

Phase 6 Version #2 failed in cell 4: `data/splits/val.csv does not exist`. Cells 1–3 had
run and written their artefacts.

**My first reading of this was wrong and is corrected here.** I claimed the leakage gate
had "passed while checking nothing" — that the split CSVs were absent at cell 1 and the
gate had skipped every test needing them. That is not what happened.

| | Kaggle | local, splits intact, `trainLabels.csv` hidden |
|---|---|---|
| result | `36 passed, 5 skipped` | **`36 passed, 5 skipped`** |

Reproduced exactly. All five skips are the gitignored `data/raw/eyepacs/trainLabels.csv`
(four parametrised cases plus one), which is correctly absent from the Kaggle bundle.
**Every split test ran and passed.** `data/splits` was complete at cell 1, and `val.csv`
was gone by cell 4, with nothing in between that writes to that directory.

The earlier count of `33 passed, 5 skipped` was the *previous* code version; the
difference of three is exactly the three tests added in `c876706`.

### What is NOT established

**Why the file disappears.** The dataset listing shows all six CSVs at the right sizes;
they survive the copy; the gate reads them. Nothing in cells 2–3 touches
`REPO/data/splits`. I could not determine the cause from the logs and am not going to
invent one — a plausible-sounding guess in this log would be worse than the gap.

### What was done instead

Cell 1 now **snapshots** the six CSVs to `WORK/splits_backup` with SHA-256 prefixes
recorded, and cell 4 re-checks. If a file has vanished it is **restored from the snapshot
and its hash verified against the cell-1 value**, so a restored file is provably the same
bytes the leakage gate checked; a mismatch aborts. Every step prints, including a line
saying the restore is a workaround and must be reported.

This is deliberately not silent. A run should not lose two hours to an unexplained
disappearance, but a self-healing step that hid the anomaly would be worse than the
anomaly.

### Version #3 (2026-09-03): it happened again, and the workaround held

The run completed. The restore fired between cell 3 and cell 4:

```
[splits @ cell 4] !! 6 split CSV(s) VANISHED since cell 1: [train, val, test, aptos_*]
    still present: []
    restored train.csv  sha 7f42cf0ba8e8cf9c  (matches cell 1)   ... all six matched
```

**All six, not one.** The whole directory emptied — Version #2's `val.csv` error was
simply the first file cell 4 happened to ask for. Every restored file's hash matched its
cell-1 value, so the partition cell 4 used is provably the one the leakage gate checked.

Independently verified: the six CSVs are **byte-identical across local repo, bundle, and
Kaggle** (sha-256 and size), so nothing is being corrupted in transit — they exist, then
they are gone.

**Still not explained.** Nothing in `src/` deletes anything (`write_manifest` only writes
into the artefact dir; the only `rmtree` is `smoke.py` on its own workdir), so it is
Kaggle-side. The next run carries a **repo-integrity probe** that prints whether `src/`,
`configs/` and `notebooks/` also vanished. That distinguishes "the whole copied tree is
being pruned" — plausible, since already-imported modules keep working from memory, which
would explain how cell 4 ran at all — from "something specific to `data/splits`". One
print settles it; the cause is not guessed at in the meantime.

**Hardening for the remedy:** cell 2 of `phase6_remedy` now checks and restores before
**every seed**, not once. That cell is ~2.1 h across three subprocesses and each re-reads
the splits at startup; a disappearance between seed 42 and seed 43 would otherwise kill
the remaining seeds two hours in.

### The gate fix of `c876706` stands anyway

`_missing_split_is_fatal` was written for a cause that turned out not to be the one here.
It stays: a gate that skips its subject and reports success is a real hazard, it is the
same shape as DECISION-058's NaN, and it costs nothing. Its commit message overstates
what happened, and this decision is the correction of record.

---

## DECISION-065 — Phase 6 is complete. Every G4 number now traces to a committed artefact.

- **Date:** 2026-09-03
- **Status:** Accepted — R4 satisfied
- **Deviates from proposal:** No.

### The R4 hole is closed

`analysis/phase6_aptos/` now holds **eight** files including
`coverage_correlation_eyepacs.json`, and `verdict.json` has been replaced with the
G4-complete version. The artefact previously in the repo said **GENERALISES** with
`G4_shortcut_confirmed: false`; it now reads:

```
verdict              : DOES NOT GENERALISE beyond its training population;
                       the in-domain results should be read as an upper bound
G4_shortcut_confirmed: true
G4_undecided         : false
```

The contradiction between the repo's own artefact and DECISION-060 is gone.

### Every number in DECISION-059/060 is confirmed, to four decimals

| seed | EyePACS | APTOS | APTOS larger? |
|---|---:|---:|---|
| 42 | 0.1418 | 0.3285 | yes |
| 43 | 0.1265 | 0.1345 | yes (by +0.008) |
| 44 | 0.1419 | 0.2451 | yes |
| **mean** | **0.1367** | **0.2360** | **fires** |

Claimed from the console in DECISION-059: EyePACS 0.1367, APTOS 0.2360. From the
committed artefact: **identical**. Nothing written into the decisions from console output
has had to be corrected.

This also confirms the per-seed reading that keeps the claim narrow: seed 43 clears the
threshold by **+0.008**, which is nothing, and the "2 of 3 seeds" framing of DECISION-059
stands exactly as written.

### The run was only completed by a workaround, and that is on the record

Cell 4 ran **only because the restore of DECISION-064 fired** — all six split CSVs had
vanished between cells. The numbers are sound (hashes verified against the cell-1
snapshot, which is byte-identical to the committed files), but the run is not
reproducible on a clean Kaggle session without that workaround, and the cause is still
open. Anyone re-running Phase 6 must expect the restore to fire.

### Phase 6 is now closed

The remedy (DECISION-063) is the next and last piece of Phase 4/6 work.

---

## DECISION-066 — The remedy run is INCOMPLETE. No outcome is claimed.

- **Date:** 2026-09-03
- **Status:** Accepted — the run is void as a test of DECISION-063; re-run pending
- **Deviates from proposal:** No.

### What happened

Seeds 42 and 43 trained to completion. **Seed 44 hit the notebook's 60-minute per-run
timeout** at epoch 23 of 30 (exit 124), with its best checkpoint at epoch 19 and val QWK
0.7603 still improving. Two of three seeds.

### The pre-registered rule was NOT met, and cell 4 applied it anyway — that was a bug

Cell 2 prints, correctly, that a partial result "is reported as partial and the
pre-registered rule is **NOT** applied to it". Cell 4 then applied it to two seeds and
printed `OUTCOME: AMBIGUOUS`. **That label is void** and is retracted here:

- a **two-seed** comparison against a **three-seed** baseline is not the registered test;
- the "majority" rule is **undefined on an even number of seeds** — and it duly
  disagreed with every other rule (majority `True`, mean/median/unanimity `False`),
  which is an artefact of the tie, not a finding;
- "median" on two seeds is just the mean, so the four-rule agreement check collapses to
  two independent rules.

The notebook now **refuses** to evaluate WORKS/FAILS/AMBIGUOUS unless all three seeds
completed, and writes `"complete": false` into the verdict. The refusal is enforced in
code rather than left to whoever reads the output.

### Why it timed out: my runtime estimate was wrong by ~2x

| | s/epoch | vs baseline |
|---|---:|---|
| baseline arm E | 76 | — |
| remedy, seed 42 | 148.3 | 1.95x |
| remedy, seed 43 | 147.8 | 1.94x |
| remedy, seed 44 | 150.0 | 1.97x |

DECISION-063 budgeted "~29 s/epoch, fully hidden by two workers", from a measurement of
`retina_mask` alone. That measurement was correct and the **estimate built on it was
not**: it ignored that the affine now warps **four channels instead of three**, and that
the fill costs a full-frame `torch.where`, all per-sample on the CPU. The true overhead is
~74 s/epoch. Consistent to within 1.5% across three independent runs, so it is the
augmentation, not a noisy machine.

**Fixed:** timeout raised to 95 min, and the docstring now carries the measured 148
s/epoch instead of the estimate. Budget ~50 min per seed, ~2.6 h for three.

### Descriptive numbers only — NOT a result

From `analysis/phase6_remedy/` (committed, 2 seeds):

| | APTOS | EyePACS | direction |
|---|---:|---:|---|
| baseline (3 seeds) | 0.2360 | 0.1367 | 3/3 |
| remedied (**2 seeds**) | 0.1796 | 0.1411 | 1/2 |

**In-domain cost: none detectable.** Remedied mean val QWK **0.7551** against baseline
**0.7570**, a delta of **-0.0019**, well inside the baseline's own 0.0081 seed range. That
much is a real reading and does not depend on the third seed, because it is a
seed-by-seed comparison rather than an aggregate against a threshold.

**Everything else waits.** DECISION-063's power section already said a drop to ~0.15 sits
inside the baseline's 0.194 seed range and proves nothing; reading a two-seed 0.1796 as
progress would be exactly the error that section was written to prevent.

### Cost control for the re-run

Re-running all three seeds to recover one costs ~1.7 h of quota for nothing. Cell 2 now
**reuses a completed run** found in an attached input, but only if that run's own
`config.yaml` proves it is this experiment: matching run id, matching backbone, and
`surround_randomisation` actually 0.75. A checkpoint that cannot prove it is ignored
rather than trusted. So the re-run trains **seed 44 only**, ~50 min.

---

## DECISION-067 — The remedy ran to completion. Outcome: AMBIGUOUS, and it stays AMBIGUOUS.

- **Date:** 2026-09-09
- **Status:** Accepted — the pre-registered outcome, reported as pre-registered
- **Deviates from proposal:** No.
- **Artefact:** `analysis/phase6_remedy/` — `complete: true`, seeds [42, 43, 44]

### The result

| | APTOS | EyePACS | direction | G4 fires |
|---|---:|---:|---|---|
| baseline | 0.2360 | 0.1367 | 3/3 | 3 of 4 rules |
| **remedied** | **0.1853** | **0.1598** | **1/3** | **0 of 4 rules** |
| change | **−0.0507** | **+0.0230** | | |

**In-domain cost: none.** Remedied mean validation QWK **0.7570** against baseline
**0.7570** — a delta of −0.0000. Per seed: 0.7554 / 0.7547 / 0.7608 against 0.7615 /
0.7534 / 0.7560. Seed 44 improved, seed 42 declined, and the mean is unchanged to four
decimals.

### Applying the pre-registered rule, clause by clause

| WORKS clause | value | met? |
|---|---|---|
| APTOS mean < 0.20 | 0.1853 | **yes** |
| APTOS mean ≤ EyePACS mean | 0.1853 vs 0.1598 | **NO** |
| direction ≤ 1/3 | 1/3 | **yes** |

Two of three. FAILS requires APTOS ≥ 0.20 **and** > EyePACS; 0.1853 < 0.20, so that is not
met either. **The rule returns AMBIGUOUS**, and that is the outcome of record.

### A defect in my own pre-registration, and how it is resolved

DECISION-063's notebook docstring glossed the first two clauses as "**(i.e. G4 no longer
fires)**". **That gloss is wrong.** `src/eval/external.py:207` defines
`g4 = (a >= 0.2 and a > e)` — G4 fires only if **both** hold, so it stops firing when
**either** fails. The WORKS criterion demanded **both** fail, which is strictly stronger
than G4 itself.

So the same pre-registration supports two readings:

- **rule as written and as coded** → AMBIGUOUS;
- **its own parenthetical gloss**, and the literal G4 definition → the criterion does not
  fire, which reads as WORKS.

**Resolved as AMBIGUOUS**, the stricter reading. When a pre-registration turns out to be
internally ambiguous, the reading that does **not** favour the hypothesis is the one that
gets used — otherwise the ambiguity is worth exactly as much as no pre-registration at
all. Recorded here so an examiner who spots the gloss sees that the discrepancy was found
and resolved against interest, rather than not noticed.

### What actually moved, stated without spin

**Every reading that does not depend on magnitude moved as "works" predicts.**
DECISION-063 named two such readings in advance, because the effect is too small for
magnitude to carry a conclusion. Both moved: direction **3/3 → 1/3**, and the criterion
fires under **0 of 4** aggregation rules against 3 of 4 for the baseline.

**But the gap narrowed partly from the wrong end.** APTOS fell 0.0507 and EyePACS **rose
0.0230** — roughly a third of the narrowing comes from the *in-domain* dependence getting
**stronger**, not the external one getting weaker. A remedy that worked cleanly would not
do that, and it is the single most important qualifier on this result.

**And the magnitude proves nothing on its own,** exactly as pre-registered: the 0.0507
drop sits well inside the baseline's own **0.194** across-seed range.

### The secondary endpoint was NOT tested

DECISION-051's secondary was "the remedied model **loses less on APTOS**". What cell 4
prints is **mean predicted score** (baseline 1.7372/1.6173/1.5729 → remedied
1.5168/1.5084/1.4140), which is a proxy and does not answer it. A lower mean score against
*carried-over* thresholds means **fewer referrals**, and the baseline's APTOS sensitivity
of 0.990 was already over-referral — so this could be better calibration or worse
sensitivity, and the printed numbers cannot distinguish them.

**Optional, ~18 min:** re-run Phase 6's carried-over evaluation with the remedied
checkpoints. That completes the pre-registered plan rather than extending it. **It cannot
change the primary outcome** — using an external metric to break an ambiguous primary
after seeing it would be precisely the post-hoc move this project has avoided throughout.

### For the thesis

> **The remedy.** Arm E was retrained with one factor changed: on 75% of training draws
> the masked-out surround was replaced by a per-image random constant colour, removing the
> surround's appearance as a stable cue. Three seeds; everything else identical.
>
> Every marker of the dependence that does not rest on magnitude moved in the predicted
> direction. The per-seed direction count fell from **3 of 3 to 1 of 3**, and the shortcut
> criterion ceased to fire under **all four** aggregation rules against three of four for
> the baseline. The mean within-grade correlation on APTOS fell from 0.2360 to 0.1853.
> There was **no measurable in-domain cost**: mean validation QWK 0.7570 for both.
>
> Two things stop this being reported as a successful remedy. The pre-registered criterion
> required the external correlation to fall to at or below the in-domain one, and it did
> not (0.1853 against 0.1598). More informatively, the gap narrowed partly from the wrong
> end: APTOS fell by 0.051 while **EyePACS rose by 0.023**, so about a third of the
> narrowing came from the in-domain dependence increasing rather than the external one
> decreasing. The APTOS drop also sits inside the baseline's own 0.194 across-seed range.
>
> The pre-registered outcome is therefore **ambiguous**, and is reported as such: three
> seeds were not enough to settle an effect of this size, which was written down before
> the run rather than concluded after it. The narrower claim that survives is still worth
> making — an intervention aimed specifically at the surround's appearance moved every
> non-magnitude marker of the dependence in the predicted direction at no cost to
> in-domain performance, which is **weak causal support** for the shortcut reading rather
> than none.

### What this does NOT change

The Phase 6 verdict stands unaltered. The model evaluated in Phase 6 — and the one the
thesis reports — is the **baseline**, for which G4 fired and DECISION-060's conclusion
holds. The remedy is a follow-up experiment about *why*, not a replacement headline. The
deployed checkpoint does not change.

---

## DECISION-068 — Phase 7 starts with the coverage guard, and its bounds are measured

- **Date:** 2026-09-09
- **Status:** Accepted — code and tests landed; **the calibration artefact does not exist yet**
- **Deviates from proposal:** No. The proposal requires a web interface; this is an input
  check inside it.

### Why this is the first thing built

DECISION-060 approved a guard over a disclaimer paragraph, on the grounds that a
**measured** failure mode should be **controlled** rather than described. Phase 6 showed
the model's score depends partly on retina coverage, and that the dependence is stronger
out-of-domain. So the app measures coverage on the actual upload and says whether *this*
image sits inside the framing the model was trained on.

It is deliberately narrow. It is not a quality score, not a diagnosis, and not a claim
that an in-range image is safe. It answers one question: is this framing inside the range
the training images occupied?

### The bounds are measured, and the guard refuses to run without them

`src/inference/coverage_guard.py` has **no default range and no fallback**. Without
`analysis/coverage_guard/calibration.json` it raises. A guard with invented bounds is
worse than no guard, because it presents as evidence (R4).

`python -m src.inference.calibrate_coverage --cache-root <cache> --split train` produces
the artefact. ~30 s for 24,586 images at the measured 1.19 ms/image, so it is a small
addition to any future Kaggle session rather than a session of its own.

**p1/p99, not min/max.** The question is whether the training set contained images framed
like this one; a single freak image would stretch a min/max range far enough to wave
everything through. Both percentile choices are recorded in the artefact so a reader can
see which rule produced the bounds.

**The TRAINING split, not validation.** The reference is what the model was fitted on.
Using validation would also quietly involve an evaluation split in a deployment decision.

### It is conservative, and that is stated

Training augmentation moves coverage over roughly 0.81x–1.15x of an image's own value
(measured on a synthetic disc, DECISION-063), so the model tolerates somewhat more than
the raw cache range. The guard flags against the **raw** training distribution and
therefore flags slightly sooner than strictly necessary — the right direction to be wrong
in for a screening prototype, and recorded rather than left implicit.

### The second job it does for free

`region_masks` raises `NoRetinaError` when no illuminated disc is found. In Phases 5 and 6
that meant "exclude from a statistic". On an upload path it means **"this is probably not
a fundus photograph"**, and the guard returns `no_retina_detected` with no grade. Somebody
will upload a selfie; the app should decline rather than grade it.

### Tested for the ways it could stop guarding

16 tests, and they are aimed at silent failure rather than at coverage: that a missing or
malformed calibration **raises** instead of defaulting; that the guard measures the
**same quantity** Phase 6 correlated, asserted against `region_masks` directly, so the two
cannot drift apart; that a non-fundus image is refused; that every verdict carries the
bounds it was judged against, since a flag with no stated threshold is unauditable.

The calibration CLI is exercised **end to end through the real `main()`** against a
synthetic cache. It runs on Kaggle where the cache lives, so a mistake in it would
otherwise surface only after a session had been spent — which is exactly what happened
twice in Phase 6 (DECISION-064/066).

### Still to do in Phase 7

1. **Run the calibration on Kaggle** and commit `calibration.json`.
2. `src/inference/predictor.py` — grade + Grad-CAM, framework-agnostic and testable
   without HTTP.
3. FastAPI backend, Next.js frontend.
4. The **four-point disclaimer** of DECISION-060, in the interface rather than the README.

---

## DECISION-069 — Seed 42 ships, and the cherry-pick risk is handled structurally

- **Date:** 2026-09-09
- **Status:** Accepted — **user decision**, offered with the trade-off stated
- **Deviates from proposal:** No.

### The choice

The app deploys **`phase4_stage3_arm_e_efficientnet_b0`, seed 42**.

| seed | val QWK | distance from 3-seed mean | Phase 5 analysis |
|---|---:|---:|---|
| **42** | **0.7615** | 0.0045 | **yes — Grad-CAM, border gate, panel figure** |
| 43 | 0.7534 | 0.0036 | no |
| 44 | 0.7560 | **0.0010** | no |

**Why not seed 44, which is the most representative draw.** The entire explainability
chapter is seed 42: `notebooks/phase5_gradcam.py` names it "the selected model", and its
Grad-CAM is what passed the border-check gate and produced the qualitative panel.
Deploying seed 44 would put heatmaps in front of users that **no chapter has examined**.
An interface whose explanations were never validated is a worse failure than a shipped
model that is 0.0045 above the mean.

**The cost, stated:** seed 42 is also the **highest-scoring** of the three, so "you
shipped your best run" is a fair question to expect.

### Why that criticism does not land, and it is not a matter of trust

DECISION-042 — *report the mean across seeds, never the best seed* — governs **what is
claimed**, not which file is loaded. So the interface reports the **3-seed mean**
regardless of which checkpoint runs:

```
reported_val_qwk              0.7569    <- quoted
reported_val_sens_at_spec95   0.7360    <- quoted
seed_val_qwk                  0.7615    <- recorded, not quoted
seed_val_sens_at_spec95       0.7464    <- recorded, not quoted
```

Both pairs live in `analysis/deployment/deployment.json`, side by side, and
`Deployment.provenance()` prints them together. **Two tests enforce it**: the disclaimer
must contain `0.7360` and must **not** contain `0.7464`. The shipped seed being the best
one is exactly why that is a test rather than an intention.

### Every number traces to the committed run

`cuts`, `referral_threshold` and `seed_val_sens_at_spec95` were **reproduced** from
`runs/phase4_stage3_arm_e_efficientnet_b0/val_outputs.npz` via `optimise_qwk_cuts` and
`choose_operating_point`, and the cuts and threshold match
`analysis/phase6_aptos/carried_over_rules.json` exactly. Nothing in the manifest was
typed from memory.

### A correction: the 3-seed mean QWK is 0.7569, not 0.7570

The true mean is **0.75694**. The 0.7570 used in DECISION-063 and in the remedy notebook
came from averaging the per-seed values **already rounded to 4 dp**
((0.7615+0.7534+0.7560)/3 = 0.75697).

**Nothing concludes differently.** The remedy's in-domain delta becomes **+0.0001**
instead of −0.0000, against a seed range of 0.0081 — "no detectable in-domain cost"
stands, and the sign at that scale is noise.

**Root cause removed rather than the instance patched:** `phase6_remedy` now carries the
per-seed QWK at full precision and **computes** the mean and range instead of hardcoding
them, so the same class of error cannot recur in that notebook.

---

## DECISION-070 — The coverage guard is calibrated and live. It is also narrower than it looks.

- **Date:** 2026-09-09
- **Status:** Accepted — measured, committed, and its limit quantified
- **Deviates from proposal:** No.
- **Artefact:** `analysis/coverage_guard/calibration.json`, from
  `rah098/fyp-dr-phase7-calibrate` (378 s, CPU only)

### The measurement

| | |
|---|---|
| images | **24,586** (the training split) |
| no retina | **3** — counted, excluded from percentiles (DECISION-052) |
| median coverage | **0.7829** |
| **p1 / p99 — the enforced bounds** | **0.6138 / 0.8172** |
| min / max | 0.1655 / 0.8755 |

The self-check passed at **47 of 50** training images inside their own bounds. The bounds
exclude 2% of the training distribution by construction, so a small number of failures is
the design working, not a fault.

**Cross-check against Phase 6:** training median 0.7829 against the EyePACS *validation*
median of 0.7822 measured independently in `phase6_aptos` cell 4. Two different splits,
two different code paths, agreeing to 0.0007.

### p1/p99 over min/max was the right call, and the data says so loudly

DECISION-068 chose percentiles on principle — before seeing any numbers — because one
freak image would stretch a min/max range far enough to wave everything through. The
measurement is a stronger vindication than expected:

> The training minimum is **0.1655**. The 1st percentile is **0.6138**. A gap of **0.448**,
> more than twice the entire width of the enforced band.

At least one training image has a retina filling a sixth of the frame. Under min/max
bounds the low side of the guard would essentially never have fired.

### What it does on external data — and the limit that comes with it

Run against the 3,662 committed APTOS coverage values:

| | flagged | rate |
|---|---:|---|
| training split (by construction) | — | 2.0% |
| **APTOS** | **174** | **4.8%** |

**2.4x the in-domain rate, and every flag on the tight-crop side** (0 low, 174 high).
So the guard is sensitive in the right direction on the dataset where G4 fired.

**But 95.2% of APTOS passes.** That number matters more than the 4.8%, and the write-up
leads with it:

> APTOS's median coverage is **0.7319** against the training median of **0.7829** — a
> shift of **0.051, a quarter of the enforced band's width** — and yet almost the whole
> distribution sits inside the bounds. **A per-image check cannot see a shift in the
> median.** The guard catches an individual badly framed upload; it does not and cannot
> detect that a whole population is framed differently, which is the condition Phase 6
> actually found.

That is a real limitation of the control, stated at the point it was measured rather than
discovered by a reader. Detecting the population case needs the *distribution of uploads*
monitored over time, which is out of scope here and belongs in future work.

### Status

The guard is live: `Calibration.load()` succeeds and the app's startup now blocks only on
`FYP_CHECKPOINT`, which is gitignored by design.

---

## DECISION-071 — Frontend handoff: what was decided so the next session inherits it

- **Date:** 2026-09-09
- **Status:** Accepted
- **Deviates from proposal:** No.

### The disclaimer appears in full on BOTH screens

The frontend brief required the four-point disclaimer on the Result view and separately
mentioned the Upload view, without saying whether Upload gets the full set or a summary.
**Decided: all four strings on both.**

Upload is where someone decides whether to use the thing at all, and shortening the
caveats at exactly that moment is the "make it look better" pressure this project exists
to resist. Four short strings is not a usability burden for an audience of a thesis panel
and clinicians. *Considered and rejected:* a one-line summary on Upload with the full set
on Result — which is what a frontend tool would pick by default, which is why it is
settled here rather than left to be inherited.

### Fixtures are verified against the real pipeline, never merely named

`fixtures/build_fixtures.py` pushes every image through the real `preprocess_image` and
the real coverage guard and **asserts** the measured status before writing the file. A
fixture called `framing_too_tight` that does not actually trigger that status would have
the frontend built against a state that never fires.

**A measurement that corrected an assumption:** padding an image does **not** lower
coverage. `preprocess_image` square-crops to the retina bounding box, so padding is
cropped straight back off. Coverage is the *filled fraction of that bounding square* —
about 0.785 for a full disc, higher when the retina is truncated top and bottom, lower
when part of it is out of frame. The transforms that move it are a partially out-of-frame
retina (down: 0.3667) and a centre crop inside the disc (up: 1.0000).

### The two score-selected fixtures were NOT built, and a synthetic stub is used instead

A clean grade 0 and the grade/referral disagreement case both need `best.pth` (gitignored)
and validation images (not on this machine — CLAUDE.md §3). The builder produces them
automatically once `FYP_CHECKPOINT` is set.

For the **disagreement** case, hunting for an image whose score lands inside the 0.673-wide
band between the referral threshold (0.9488) and the grade-1→2 cut point (1.6216) is the
wrong tool: **the frontend needs to render that state, not discover it.**
`fixtures/expected/predict_disagreement_SYNTHETIC.json` carries it, marked synthetic in
the filename and in a `_note` field. Every recorded `predict_*.json` was produced with an
**untrained** checkpoint — key sets and types exact, scores and grades meaningless — and
each says so in `_note`.

### Fixture images are gitignored; the contract is committed

The images are generated, derive from the already-ignored `data/raw/`, and one is a
deliberate 26 MB file for the 413 path. The script, README, `fixtures.json` and
`expected/*.json` **are** committed, so the frontend can be built with no images present.

### Two stale things in this repo, found and fixed

1. **`CLAUDE.md` §9** still described Phase 4 as in progress and quoted seed 42's own
   **0.7464** — five phases stale, and 0.7464 is precisely the figure the interface is
   forbidden to display. Rewritten to Phase 7 with the 3-seed means.
2. **`tests/test_predictor.py`** carried `reported_val_qwk=0.7570` in its `DEPLOY` fixture
   and asserted `"0.7570"` in the provenance line — the superseded rounded-average value
   (DECISION-069). Corrected to `0.7569412` / `"0.7569"`.

### What `docs/api-contract.md` documents that the brief did not

Read off the source and confirmed by calling both routes: `/meta` does **not** carry
`num_outputs`, `cuts` or `referral_threshold` (the last two come back per prediction);
`guard.coverage` is `null` exactly when `status == "no_retina_detected"`; a declined
upload is **HTTP 200** with `graded: false` and no `grade` key, making the response a
discriminated union; and the 413 message quotes the exact byte limit.

---

## DECISION-072 — The frontend is built; one rule conflict resolved; the design choices recorded

- **Date:** 2026-09-13
- **Status:** Accepted — built, typechecked, linted, production-built, and verified in a browser
- **Deviates from proposal:** No. Next.js + TypeScript + Tailwind, per DECISION-001.

### A conflict inside the frontend rules, resolved toward the stricter one

Frontend rule 7 says the provenance line appears on the page. `/meta.provenance` — by
DECISION-069's design — ends with **"This seed's own validation QWK is 0.7615."** Frontend
rule 2 forbids 0.7615 in the interface. Rendering the string verbatim satisfies rule 7 and
breaks rule 2.

**Resolved:** the footer is composed from `/meta` *fields* (`run_id`, `arch`, `head`,
`seed`, `reported_val_qwk`, `reported_val_sens_at_spec95`) and never renders
`meta.provenance`. The side-by-side record of both figures still exists where DECISION-069
put it for auditability — `analysis/deployment/deployment.json` — and the interface quotes
only the 3-seed means. Verified: `0.7615` and `0.7464` appear nowhere in the source or the
production build output, nor in the served HTML.

*Considered and rejected:* changing the backend string. It is the audit line DECISION-069
deliberately designed, and the backend tests pin it.

### The design direction, and why it came from the subject

- **A neutral grey surround for the image.** Medical image review uses a neutral surround
  so the frame does not bias how the picture is read. The page is cool neutral paper; the
  fundus sits in a mid-grey viewer.
- **One indigo hue stepped in lightness for severity.** No red, amber or green anywhere.
  Checked with a greyscale screenshot: the scale still reads as ordered, and every grade is
  also named in words.
- **Atkinson Hyperlegible Next**, one family — designed by the Braille Institute for
  low-vision readers, the population diabetic retinopathy produces.
- **Grade 0 gets identical treatment to every other grade.** No tick, no green, no
  reassuring copy; "Not flagged" rather than "Do not refer".

### The one bold element: the decision ruler

The hardest UX problem in the brief was making "Mild, refer" read as two correct answers
rather than a contradiction. It is solved in the layout: **one axis, drawn to scale**, with
the four cut points dividing it into grade segments and the referral threshold as a separate
dashed line. The grade is which segment the score lands in; the referral is which side of
the line. For the disagreement case the reader sees the threshold sitting inside the Mild
segment and the score just past it — the explanation is the geometry.

It is deliberately not a gauge: no fill, no sense of progress toward certainty, and segment
widths are **proportional** to the real cut points. *Considered and rejected:* equal-width
segments, which look tidier and put the threshold in the wrong place.

The one motion on the page is the score marker travelling to its position when a result
arrives — the thing that changed. `prefers-reduced-motion` removes it.

**A layout defect caught by screenshot and fixed:** the first version drew both vertical
lines straight through the segment labels inside the bar. The bar now carries no text;
labels sit on their own rows above and below.

### Verified in a real browser, against the real backend

Run with an **untrained** checkpoint — every UI state is real, every grade and heatmap is
meaningless — using the committed fixtures:

| state | how | result |
|---|---|---|
| upload | direct | full four-string disclaimer in flow; provenance from fields |
| `no_retina_detected` | `not_a_fundus.png` | no grade; `guard.message` verbatim |
| `framing_below_training_range` | `framing_too_wide.jpeg` | warning above the readout, grade still shown |
| `framing_above_training_range` | `framing_too_tight.jpeg` | same |
| `ok` | `in_range_fundus.jpeg` | framing check shown quietly after the limits |
| grade/referral disagreement | real response, four fields overridden in-browser | Mild + Refer at equal weight, ruler explains it |
| 400 | `not_an_image.jpg` | service detail shown verbatim |
| 413 | `oversized_over_20mb.png` | service detail shown verbatim |
| 400 "empty upload" | accidental, see below | rendered correctly |

On every graded result the disclaimer heading is inside the first viewport at 1360×900.
Keyboard: skip link → nav → "Choose a photograph", and Enter opens the file chooser. Mobile
at 390 px: no horizontal overflow; readout stacks above the image; a colour key replaces the
in-bar labels because the Moderate segment is too narrow to label.

The disagreement state was produced by capturing a real `/predict` response and overriding
`score`, `grade`, `grade_name` and `referable` in the browser. A first attempt used
Playwright's `route.fetch()`, which does not re-send a multipart body; the backend therefore
answered "empty upload" and the page rendered that 400 path correctly — a harness artefact,
not an app bug.

### Guarantees that are enforced rather than intended

- **`/predict` is a discriminated union on `graded`.** A probe file reading `r.grade`
  without narrowing fails `tsc` with *"Property 'grade' does not exist on type
  'PredictDeclined'"*; the narrowed read compiles.
- **Runtime validation of every response** in `lib/api.ts`: a graded response carrying
  `no_retina_detected`, a declined response carrying a grade or a coverage value, or a
  disclaimer that is not exactly four strings is treated as malformed and shown as an
  error — never partially rendered.
- The word "detected" appears only as the API's enum key; the single place a user sees it is
  inside `guard.message`, which frontend rule 5 requires verbatim.

### Not done

- The heatmap screenshots from this session come from an **untrained** model and must not be
  used in the thesis. Real ones need seed 42's `best.pth`.
- No automated frontend test suite; verification this session was a scripted browser pass.
- No Docker Compose yet.

---

## DECISION-073 — The app has been run end to end on the real seed 42 checkpoint

- **Date:** 2026-09-13
- **Status:** Accepted — observed, not measured
- **Deviates from proposal:** No.

### The checkpoint, and proof it is the right one

`best.pth` was pulled from the `rah098/fyp-dr-phase4-stage3` kernel output with
`kaggle kernels output --file-pattern` and placed at
`runs/phase4_stage3_arm_e_efficientnet_b0/best.pth`, which `.gitignore` excludes
(`runs/**/*.pth`). Before use it was checked against the committed run:

| | checkpoint | `metrics.json` |
|---|---|---|
| epoch | 12 | `best_epoch` 12 |
| val QWK | 0.7619686857570801 | `best_val_qwk_during_training` 0.7619686857570801 |

Identical to 16 decimal places, and the state dict loads into the arm-E EfficientNet-B0
architecture the deployment manifest names. SHA-256 prefix `e0e1eb4e73d2897d`.

### What the real model produced, through the whole stack

Uploaded through the frontend, graded by the backend, on the committed fixtures:

| fixture | source · train label | real result |
|---|---|---|
| `disagreement_mild_but_refer.jpeg` | `3895_left` · 2 | **Mild + Refer**, score 1.2306, framing ok |
| `clean_grade0.jpeg` | `13613_left` · 0 | No DR, not flagged, score 0.1845 |
| `in_range_fundus.jpeg` | `13345_right` · 1 | Moderate + Refer, score 1.7597 |
| `framing_too_wide.jpeg` | top half of `13345_right` | Moderate + Refer, score 1.8712, **framing warning** |

The scores reached the browser identical to the ones the fixture builder computed
directly, so nothing in the HTTP or frontend layers alters them. The disagreement state —
the hardest UX problem in the brief — renders as designed on a **real** result, not only on
the synthetic stub.

### A fixture that would have been misleading, and why the builder changed

The first real scoring run chose `3829_left` for the disagreement case: a 400×315, almost
black, underexposed photograph whose preprocessing salvaged only a crescent artefact
(coverage 0.2529). Its score fell in the band, but it was the model grading a broken
image — and **the framing guard correctly flagged it**. The builder now accepts only
candidates that pass the guard; `3895_left`, a normal full-resolution photograph, replaced
it.

### Two observations, recorded as observations

Neither is evidence. Both come from single **training** images.

1. **The real Grad-CAM for `3895_left` concentrates at the bottom-right edge of the frame**,
   not over the optic disc, the macula or the vessels. That is the pattern Phase 5's failed
   outside-border gate measured in aggregate and the kind of framing dependence Phase 6
   found (DECISION-053/060). It is worth a sentence in the Grad-CAM chapter as an
   illustration, and must not be presented as more than one image.
2. **Cropping `13345_right` to its top half moved its score from 1.7597 to 1.8712.** One
   image, one perturbation, and a label of 1 for both — so it is consistent with a framing
   dependence and demonstrates nothing on its own.

### Status

Phase 7's application is complete and has been seen working with the model that ships.
Screenshots from the **untrained** runs of DECISION-072 are superseded; real-model
screenshots can now be taken for the write-up, labelled as training images.

---

## DECISION-074 — Published as a private GitHub repo, with the deployed checkpoint committed

- **Date:** 2026-09-13
- **Status:** Accepted — **user decision** on both points, offered with the trade-offs
- **Deviates from:** the project convention that `*.pth` is never committed (CLAUDE.md §7).
  Not from the proposal.

### Private

The repo is shared by link with people the user invites. **Public was declined**, and should
stay declined unless two things are dealt with first: the repo already tracks two images
made from EyePACS photographs (`docs/phase2_contact_sheet.png` and
`analysis/phase5_gradcam_arm_e_efficientnet_b0/panel.png`), and the split CSVs carry
EyePACS labels. Republishing those publicly is not permitted by the dataset's terms, and
removing the images would mean rewriting history, not just deleting the files.

### The checkpoint is committed

`runs/phase4_stage3_arm_e_efficientnet_b0/best.pth` (15.6 MB, SHA-256 prefix
`e0e1eb4e73d2897d`, verified against the committed run in DECISION-073) is tracked so that a
cloned repo runs the app with no further download. The alternative offered, a GitHub
Release asset, would have kept the binary out of history; the user chose simplicity for
recipients.

Scoped to exactly that file: a `.gitignore` negation re-includes it, and a probe `.pth`
elsewhere under `runs/` was confirmed still ignored. CLAUDE.md §7 records the exception.

### Checked before the first push

Pushing publishes every past commit, not only the latest, so the whole history was scanned:
no `kaggle.json`, `.env`, key or credential file has ever been committed, and no
token-shaped string (GitHub, Kaggle, AWS or OpenAI formats) appears in any diff.

A root `README.md` was added for recipients: what the project is and is not, the headline
figures (3-seed means, below the screening reference, does not generalise), and setup for
Windows and macOS/Linux.


## DECISION-075 — Frontend redesigned around the patient journey; browser-only records

**Date:** 2026-10-16. **Requested by the user**, who supplied the target flow.

The frontend is rebuilt (dark theme) around this journey: upload a retinal image → automated
screening (grade 0–4 + Grad-CAM + framing check) → screening report (save, download PDF) and
referral guidance → find an eye specialist and request an appointment → track appointments
and previous screenings. The flow's sign-in step is **deliberately omitted**, at the user's
request.

**This amends frontend rule 8** ("no storage … nothing persists"). Records persist, but:

* only in the browser's IndexedDB — no server store, no account, nothing on the backend
  changed;
* only on an explicit "Save result" — nothing is stored automatically;
* the user's original upload is never stored; only the 224 × 224 crop, the Grad-CAM overlay,
  and the result fields.

What did **not** change: rules 1–7. All four disclaimer strings still render verbatim on the
Upload and Result views and in the PDF; `guard.message` is verbatim everywhere including the
PDF; the PDF's provenance line is built from `/meta` fields, never `meta.provenance` (which
carries seed 42's own QWK); grade and referral stay two answers of equal weight.

**Referral guidance** is read off `referable` and `guard` only — never off `grade` — so it
cannot reconcile the grade/referral disagreement. Its "not flagged" branch states the
missed-referral share computed from `/meta` (1 − reported_val_sens_at_spec95) rather than
reassuring.

**Specialist directory is demo data.** Ten invented clinics, no phone numbers, every card
labelled "Demo". Appointment requests are not sent anywhere; the page says so, and the user
updates the status (Requested → Booked → Attended / Cancelled) by hand.

Dependencies added: `lucide-react` (icons), `jspdf` (client-side PDF).


## DECISION-076 — Non-fundus uploads are declined; capture quality is reported

**Date:** 2026-10-19. **Raised by the user**, who uploaded a photograph of dice and got a grade.

### The defect

`retina_mask` — the only "is this a retina" test in the upload path — is a brightness
threshold (gray > 10 after blurring). A photo of dice on a table is bright edge to edge, so
it becomes one large "retina"; the coverage guard reports ~100% coverage, raises a framing
warning, and the model **grades it**. `no_retina_detected` only fires for an almost entirely
black frame. A grade for a non-retinal image is worse than no grade: it looks like evidence.

### The fix: `src/inference/fundus_check.py`, before preprocessing

Five rules on the RAW upload, each the physical signature of a fundus camera: warm retinal
colour (>= 0.60 of coloured pixels red/orange/yellow), a dark border (illuminated area
<= 0.95 of the frame), low edge contact (<= 0.70), a convex region (solidity >= 0.95), and a
round region (fills >= 0.70 of its enclosing circle). Failing any one returns
`graded: false` with the new guard status `not_a_fundus_photograph` and a message naming
the failed rules. An image with no illuminated region still takes the existing
`no_retina_detected` path, so existing behaviour and tests are unchanged.

**How the thresholds were set.** As with `QualityStats.flags` (Phase 2): fixed absolute
constants placed in the gap between measured groups, never dataset percentiles. Measured on
the 20 EyePACS originals of the Phase 2 QA sample (train split, from the contact sheet), a
public test fundus image, crop variants of these, and 17 non-fundus images (scikit-image
sample photographs; synthetic dice including red dice on true black). Result: every usable
fundus accepted; every non-fundus image declined.

**Declined by design, and said so in the message ("not a usable fundus photograph"):** a
near-black capture, a severely washed-out capture, a crop with no dark border left, and a
half-disc crop. The fixture `framing_too_wide.jpeg` (top half of a fundus) and
`framing_too_tight.jpeg` (centre crop) will now be declined rather than graded with a
framing warning; their recorded payloads in `fixtures/expected/` predate this decision.

**Known limitation, stated rather than hidden.** Hand-written rules cannot catch everything:
a plain orange disc on a black background passes all five. A learned fundus/non-fundus
classifier (or a feature-space out-of-distribution score) is the stated next step.
**Open measurement:** the false-decline rate on real fundus images has been measured only on
the sample above. `python -m src.inference.check_fundus_rate <folder>` measures it over a
full split (EyePACS train on Kaggle, or APTOS); thresholds change only by a new entry here.

### Capture quality: `src/inference/quality_check.py`

The coverage guard checks framing only; blurred, dark or over-exposed captures were graded
silently. Graded responses now carry `quality`, produced by the Phase 2 `scan_quality`
instrument **unchanged** (same function, same thresholds), restricted to capture flags
(blurred, dark, mostly-black, over-exposed, washed-out, low-contrast, bright-artefact). A
poor capture is a prominent warning on the result page, a note in the referral guidance
("retake the photograph"), and a line in the PDF. **It warns and never declines**: training
data was not filtered by these flags, so the model has seen such captures, and refusing them
would be stricter than the evidence supports.

**No training data is removed or changed by either check.** Both run only on uploads.

### Not addressed here, and why

- **Mild recall (13.4% on validation)** needs retraining (higher resolution, more Mild-aware
  loss or sampling) on Kaggle. Post-hoc moving of the Mild cut point is possible but trades
  directly against No-DR specificity and QWK, and Mild is non-referable, so the referral
  decision is unaffected by Mild/No-DR confusion.
- **Both eyes per patient** is out of scope: the deployed model grades one image; a
  patient-level rule (refer if either eye refers) is future work.

---

## DECISION-078 — Accounts and roles, specialist review, the grounded assistant, history and Urdu

**Date:** 2026-10-26. **Requested by the supervisor**, who judged the application's scope too
small for a final-year project (the model work was not in question). The team chose the
additions below; the grading model, its thresholds and every validation number are
**unchanged**.

### What changed

1. **Accounts and three roles** (amends DECISION-075's "no accounts, no server storage").
   Patients register themselves; specialist and admin accounts are created by an admin or
   the demo seed. SQLite through the standard library (`backend/db.py`), PBKDF2 password
   hashes, random session tokens stored only as SHA-256 (`backend/security.py`). Every route
   checks the role on the server; hiding a button is never the protection.
2. **Server-side records.** Saved screenings and appointment requests move from browser
   IndexedDB to the database. **The original upload is still never stored**: a saved record
   keeps the model's result, the 224 x 224 crop and the Grad-CAM overlay, as before. A
   graded result is held server-side under a `result_id` and saved from there, so a saved
   record is exactly what the model returned; unsaved results are deleted after 24 h.
   `/predict` still works without signing in and then stores nothing.
3. **Specialist review (human in the loop).** A patient can send a saved result for
   review. A specialist agrees, or records a different grade and referral decision with a
   note. **The review is stored beside the model's answer and never replaces it**, so the
   model-vs-specialist comparison stays possible and the "grade and referral are separate"
   rule is untouched.
4. **Appointments go to a clinic.** The demo directory moves to the database; each clinic
   is linked to a specialist account that confirms or declines requests with a note.
5. **History by eye.** Each eye's score across saved screenings on the result-page scale
   (single-hue grade bands, referral threshold). "Worsened" is stated only when the score
   rose **and** the reading moved to a higher grade or to Refer; movement within a grade
   is not reported, because the model is not precise enough for it to mean anything. A
   re-screening date one year after the latest screening, unless the latest was referred.
6. **Monitoring dashboard** (admin). Upload outcomes (declined, framing warning, poor
   quality), grade mix, referral rate, specialist agreement and a model-vs-specialist
   table, appointment and assistant outcome counts. It is the in-use view of DECISION-060:
   a rising framing-warning share is how a deployment would notice the generalisation
   problem. Specialist agreement is labelled **not a validation result** — it is measured
   on cases patients chose to send, which skew toward flagged and warned images.
7. **The assistant** (`backend/assistant/`). Retrieval-augmented and result-aware:
   - knowledge base of ~40 passages written in our own words from NHS pages, a Community
     Eye Health article, the international severity scale paper, and this app's own
     documentation, each passage carrying its source and link;
   - BM25 retrieval (explainable, no model download); nothing relevant -> "not in my
     sources" instead of an answer from the model's memory;
   - rule layer BEFORE any model: urgent symptoms -> fixed "care today" reply; medicine and
     dose questions -> fixed refusal; "do I have it / am I fine / is it 100%" -> fixed reply
     built from the result that states what was estimated and why it is not a diagnosis;
   - the language model (Gemini, Groq or Ollama; free tiers, swappable by one setting)
     only words an answer from the retrieved passages and the result [R];
   - output check AFTER the model: a draft that diagnoses, reassures, gives a confidence
     figure or names a dose is withheld;
   - offline mode with no model at all: the passages are quoted and cited.
   No message text is stored; only outcome counts.
8. **English / Urdu** interface with right-to-left layout. Text from the grading service
   (`disclaimer[]`, `guard.message`, `quality.message`) stays verbatim English, as required.

### Evaluation of the assistant

`backend/assistant/eval_questions.json` holds 38 questions across result explanation,
general information, urgent symptoms, medicine, diagnosis-seeking, off-topic, actions and
Urdu. `tools/eval_assistant.py` checks automatically: expected outcome, output safety,
citation, result facts repeated exactly, offered action, and reply language.

**Measured (offline mode, rules + retrieval, no language model), 2026-10-26:** 37/37
applicable questions passed every check; 5/5 urgent questions caught (1 Urdu question
needs a model and was skipped). **Not yet measured:** the same set with a language model
connected. Run `python tools/eval_assistant.py` with a key in `.env` and record the result
here before quoting any assistant figure in the write-up. The automatic checks measure the
rules, not the quality of the wording — read the replies in `runs/assistant_eval/`.

### Limits, stated

- The knowledge base is the project team's summary; a clinician should check it against
  its sources before any use outside the project.
- The regular-expression safety rules are deliberately broad but cannot catch everything;
  they are a second line behind the prompt, not a guarantee.
- The Urdu was written by the team and has not been checked by an independent native
  reader.
- Demo accounts have public passwords and the CORS policy is open: a local demonstration,
  not a deployment.

---

## DECISION-079 — Interface redesign: light clinical theme with a sidebar

**Date:** 2026-10-26. **Requested by the team**, who found the dark black-and-white interface
too plain for the final presentation and supplied two hospital-dashboard references.

- Light theme: white cards on a soft grey page, purple brand colour for navigation and
  actions; signed-in users get a sidebar menu with icons and a top bar with the user;
  visitors get a landing page. The "Prototype" tag next to the name is removed from the
  header. **The four disclaimer strings still render verbatim on Upload and Result**, and
  the About page and footer still state that this is not a medical device.
- Coloured tiles and icon circles identify WHICH feature or metric something is. They
  never encode a result: the grade scale stays one indigo hue stepped in lightness, grade 0
  gets no green or success state, amber is used only for warnings (framing, image quality,
  worsening) and rose only for urgent symptoms and errors, always with words.
- Figures on the landing page (QWK, referable sensitivity, missed share) come from
  `GET /meta`, not from the page source.

---

## DECISION-080 — Assistant search: alternative phrasings and model rephrasing

**Date:** 2026-10-26. The word-matching search (BM25) missed questions worded differently
from the sources, which then got "not in my sources" even when the answer was there.

**Measured before the change (offline, 22 paraphrased questions in
`eval_questions.json` → `retrieval`): 11/22** had an expected passage among the four found.

Two additions, neither of which lets the assistant answer from outside its sources:

1. **"Also asked:" lines in `kb/`** — other ways patients phrase each passage's question.
   Searched, never shown and never sent to the model as source text. **Offline after:
   18/22.** Caveat, stated: these lines were written by the team *after* seeing the test
   questions, so the offline gain is optimistic.
2. **Model rephrasing (online only).** When the search finds nothing or only a weak match
   (best score < 4.0), the language model rewrites the question as 4–12 search words — or
   `NONE` if it is unrelated to eyes, diabetes or the app — and the search runs again under
   the same match rules. The words are shown under the reply's sources ("Searched as");
   they are never an answer. `NONE` or a second empty search still gives "not in my
   sources". **Not yet measured with a model** — run `python tools/eval_assistant.py`
   with a key and record the `paraphrased_found` figure here.

Also fixed while measuring: "can I skip my eye exam?" was refused as a medicine question;
the medicine rule now needs a medicine word, and common medicine names were added.

---

## Excluded data rows

**None.** Four images finished preprocessing as `ok:no-retina` (DECISION-018) and
**remain in their splits** — that is a processing note, not an exclusion. They are
excluded from the Phase 5 **border statistics only**, where the measurement is undefined,
and that exclusion is counted and reported in the gate's own output (DECISION-052). They
remain in every performance metric.

The Phase 1 reconciliation found the EyePACS dataset completely clean: 35,126 CSV
rows, 35,126 image files, zero mismatches in either direction, zero duplicates, zero
unparseable filenames, zero zero-byte files. APTOS likewise: 3,662 rows across the three
author CSVs, 3,662 image stems on disk, zero duplicate `id_code`.

No row has been dropped from any manifest. If that ever changes, the excluded rows are
listed here with identifiers and reasons.

# Session handoff

Last updated 2026-09-13. Overwritten each session — this is the state of play, not a log.

---

## FIRST ACTION NEXT SESSION

**Decide the remaining Phase 7 scope with the user, then start Phase 8.** The application is
complete and has been run end to end on the real model (DECISION-073). Open questions below.

The real checkpoint is already on this machine, gitignored:

    set FYP_CHECKPOINT=runs\phase4_stage3_arm_e_efficientnet_b0\best.pth
    .venv\Scripts\python -m uvicorn backend.app:app --port 8000
    cd frontend && npm run dev        # http://localhost:3000

## THE APP HAS RUN ON THE REAL MODEL (DECISION-073)

Checkpoint verified against the committed run: epoch 12, val QWK 0.7619686857570801 in both.
A real **Mild + Refer** result (`3895_left`, score 1.2306) renders as designed.

**Real Grad-CAM on that image sits at the bottom-right EDGE of the frame.** Consistent with
the Phase 5 border finding and the Phase 6 framing dependence — but ONE training image. An
illustration, never evidence.

**Fixtures are still TRAINING images.** Real-model screenshots are usable in the write-up
only if labelled as such.

## THE FRONTEND IS BUILT (DECISION-072)

`frontend/` — Next.js 16, TypeScript, Tailwind v4. Upload, grading, declined, both framing
warnings, graded, 400/413/network/malformed, About. Typechecked, linted, production-built, and
verified in a real browser against the real backend.

**Screenshots from DECISION-072 came from an UNTRAINED checkpoint** and are superseded by
the real-model run of DECISION-073. Do not use the untrained ones.

**The footer does NOT render `meta.provenance`.** That string ends with seed 42's own 0.7615
(DECISION-069's audit line), which frontend rule 2 forbids. The footer is built from `/meta`
fields instead. Do not "simplify" it back to the string — the build is currently verified
free of 0.7615 and 0.7464.

**The decision ruler is proportional to the real cut points on purpose.** Equal-width segments
would look tidier and put the referral threshold in the wrong place.

## What happened this session

1. **Phase 6 closed.** The remedy ran to completion on all three seeds. Outcome
   **AMBIGUOUS** (DECISION-067) — see below, it is the thing most likely to be
   misreported.
2. **Phase 7 built:** coverage guard (calibrated on Kaggle, DECISION-068/070),
   `src/inference/predictor.py` (21 tests), FastAPI backend (12 tests).
3. **Frontend handoff pack** (DECISION-071): `CLAUDE.md` frontend section,
   `docs/api-contract.md`, 6 verified fixtures, recorded responses for every state.

**702 passed, 2 skipped.** Working tree clean.

---

## Things that are easy to get wrong

### The remedy outcome is AMBIGUOUS and stays that way (DECISION-067)

|  | APTOS | EyePACS | direction | G4 fires |
|---|---|---|---|---|
| baseline | 0.2360 | 0.1367 | 3/3 | 3 of 4 rules |
| remedied | 0.1853 | 0.1598 | 1/3 | 0 of 4 rules |

**Do not upgrade this to "the remedy worked."** Three pre-registered reasons: the WORKS
clause required APTOS ≤ EyePACS and it is 0.1853 vs 0.1598; **the gap narrowed partly from
the wrong end** — APTOS fell 0.0507 but EyePACS *rose* 0.0230, so about a third of the
narrowing is the in-domain dependence getting stronger; and the drop sits inside the
baseline's own 0.194 seed range.

What is true: every marker that does not rest on magnitude moved as predicted, at **no
in-domain cost** (QWK 0.7569 either way). That is weak causal support, not proof.

### The interface must never show 0.7615 or 0.7464

Seed 42 ships and it is the **best-scoring** of the three seeds (DECISION-069). The
interface reports the 3-seed means — **0.7569** and **0.7360** — only. Two tests enforce
it (`test_api.py::test_meta_reports_the_three_seed_mean_and_not_the_shipped_seed`,
`test_predictor.py::test_the_interface_quotes_the_three_seed_mean_not_the_shipped_seed_s_own_score`).
Both assert `"0.7360" in text and "0.7464" not in text`. Do not "simplify" the manifest by
deleting one of the two pairs — having them side by side is what makes the choice
auditable.

### grade and referable disagree by design

`referral_threshold` 0.9488 sits **below** the grade-1→2 cut point 1.6216, so any score in
that band is `grade: 1` "Mild" **and** `referable: true`. Correct behaviour. Do not
reconcile them.

### The coverage guard is narrower than it looks (DECISION-070)

It flags 4.8% of APTOS against 2% in-domain — right direction — but **95.2% of APTOS
passes**, even though APTOS is where G4 fired. A per-image check cannot see a shift in the
median. Lead with that limitation; it is future work, not a fix.

### Fixtures are TRAINING images

The only real fundus photographs on this machine are the 20 QA images, all from the
**train** split. Fine for exercising UI states, which is all they are for. **Never
screenshot one as a demo of performance** — that would be reporting a training-set result.

### The splits still vanish mid-run on Kaggle (DECISION-064)

Cause unknown. Cell 1 of the Phase 6/7 notebooks snapshots them with hashes and restores
if they disappear. It did not fire in the last two runs. If it fires, report it.

---

## Open questions for the user

1. **Docker Compose** is still on the Phase 7 checklist. Worth it for the viva demo, or is
   the two-terminal path enough? It was not attempted this session.
2. **The CPU inference benchmark** on a 16 GB target is unstarted. Needed for the
   write-up, or drop it?
3. **The optional ~18 min Phase 6 re-run** with the remedied checkpoints would complete
   DECISION-051's secondary endpoint ("loses less on APTOS"). It **cannot** change the
   ambiguous primary. Worth the quota or not?

## Known broken / incomplete

- **Two fixtures cannot be built here** — a clean grade 0 and the real disagreement case
  need `best.pth` plus validation images. `build_fixtures.py` makes them once
  `FYP_CHECKPOINT` is set. A synthetic stub covers the disagreement state meanwhile.
- **No automated frontend tests.** Verification was a scripted browser pass against the
  real backend with an untrained checkpoint (DECISION-072).
- **No Docker.** Nothing containerised yet.
- `context7` MCP server failed to connect this session (timeout) — unrelated to the repo.

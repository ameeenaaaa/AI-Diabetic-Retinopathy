"""Is this upload a usable fundus photograph at all? (DECISION-076)

The coverage guard asks one narrow question — is the framing inside the training range?
It assumes the upload IS a fundus photograph. Its retina detector is a brightness
threshold (`retina_mask`: anything brighter than 10/255), so a photo of dice on a table
becomes one large "retina", gets a framing warning, and is then GRADED. A grade for a
non-retinal image is worse than no grade: it looks like evidence.

This module runs BEFORE preprocessing, on the raw upload, and declines anything that does
not have the physical signature every fundus camera produces:

  1. warm colour     — the illuminated retina is red/orange/yellow. Grey, white, blue and
                       green images are not fundus photographs.
  2. dark border     — fundus cameras image a round field of view; the frame outside it
                       is dark. A photo that is bright edge to edge has no field of view.
  3. low edge contact — the illuminated region may be cut by the sensor top and bottom,
                       but it does not run along most of the frame's edge.
  4. convex region   — the field of view is one solid convex disc, not an irregular blob.
  5. round region    — that disc fills most of its enclosing circle (a square does not).

WHAT THIS IS NOT. It is not a learned classifier and it cannot catch everything: a plain
orange disc on a black background passes all five checks. It catches the common case —
an everyday photograph uploaded by mistake — and it says so in the message rather than
claiming certainty. A learned fundus/non-fundus classifier is the stated next step.

THE THRESHOLDS. Like `QualityStats.flags` in src/data/preprocess.py, these are FIXED
ABSOLUTE CONSTANTS set to separate measured groups, never percentiles of a dataset split.
They were measured on (a) the 20 EyePACS originals of the Phase 2 QA sample (train split
only, as rendered in docs/phase2_contact_sheet.png) plus a public test fundus image, and
(b) 17 non-fundus images (scikit-image sample photographs and synthetic dice, including
red dice on a true-black background). Worst real-fundus value vs best non-fundus value:

    rule                 threshold   fundus worst   non-fundus best   rejected by it
    warm_fraction        >= 0.60     0.86           0.38              grey/white/blue images
    coverage             <= 0.95     0.90           0.97              full-frame photos, dice on a table
    edge_contact         <= 0.70     0.63           0.83              astronaut, coffee
    solidity             >= 0.95     0.99           0.88              irregular bright regions
    circle_fill          >= 0.70     0.78           0.64              square objects on black

Real fundus images this ALSO declines, by design: an almost entirely black capture, a
severely washed-out capture, an image cropped so tightly that no dark border remains, and
an image cut to half a disc. None is a usable standard fundus photograph, and the message
says "not a usable fundus photograph" rather than "not an eye".

`python -m src.inference.check_fundus_rate` measures the decline rate over any manifest
(e.g. the training split on Kaggle). Thresholds are revised only through a DECISIONS.md
entry, never silently.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

import cv2
import numpy as np

from src.data.preprocess import retina_mask

# Rule thresholds — see the module docstring for where each number comes from.
MIN_WARM_FRACTION = 0.60
MAX_COVERAGE = 0.95
MAX_EDGE_CONTACT = 0.70
MIN_SOLIDITY = 0.95
MIN_CIRCLE_FILL = 0.70

# HSV (OpenCV hue 0-180) band counted as retinal colour: red through orange to yellow.
_WARM_HUE_LOW = 30      # 0..30  = red/orange/yellow
_WARM_HUE_HIGH = 165    # 165..180 = red wrapping round
_MIN_SAT = 40           # ignore near-grey pixels when judging hue
_MIN_VAL = 40           # ignore near-black pixels when judging hue

NOT_FUNDUS = "not_a_fundus_photograph"

_RULE_TEXT = {
    "warm_fraction": "the image is not the red-orange colour of a retina",
    "coverage": "there is no dark border around the retina, which every fundus camera produces",
    "edge_contact": "the bright region runs along most of the image edge",
    "solidity": "the bright region is irregular rather than one solid disc",
    "circle_fill": "the bright region is not round",
}


@dataclass(frozen=True)
class FundusFeatures:
    warm_fraction: float   # share of coloured retina pixels in the red-orange-yellow band
    coverage: float        # illuminated area / frame
    edge_contact: float    # share of the frame's border pixels that are illuminated
    solidity: float        # region area / convex hull area
    circle_fill: float     # region area / area of its minimum enclosing circle


def measure(bgr: np.ndarray) -> FundusFeatures | None:
    """Features of one RAW upload, or None when no illuminated region exists at all.

    None is deliberately not a verdict: an all-black frame is handled by the coverage
    guard's existing `no_retina_detected` path, which the API contract already defines.
    """
    if bgr.ndim == 2:
        bgr = cv2.cvtColor(bgr, cv2.COLOR_GRAY2BGR)
    mask = retina_mask(bgr) > 0          # the SAME detector the pipeline uses
    if not mask.any():
        return None

    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[:, :, 0][mask], hsv[:, :, 1][mask], hsv[:, :, 2][mask]
    coloured = (s > _MIN_SAT) & (v > _MIN_VAL)
    if coloured.any():
        hue = h[coloured]
        warm = float(((hue <= _WARM_HUE_LOW) | (hue >= _WARM_HUE_HIGH)).mean())
    else:
        warm = 0.0                        # an entirely grey image has no retinal colour

    border = np.concatenate([mask[0], mask[-1], mask[:, 0], mask[:, -1]])

    m8 = mask.astype(np.uint8)
    contours, _ = cv2.findContours(m8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(contours, key=cv2.contourArea)
    area = float(cv2.contourArea(c))
    hull_area = float(cv2.contourArea(cv2.convexHull(c)))
    (_, _), radius = cv2.minEnclosingCircle(c)

    return FundusFeatures(
        warm_fraction=warm,
        coverage=float(mask.mean()),
        edge_contact=float(border.mean()),
        solidity=area / hull_area if hull_area > 0 else 0.0,
        circle_fill=area / (np.pi * radius * radius) if radius > 0 else 0.0,
    )


def failed_rules(f: FundusFeatures) -> list[str]:
    out = []
    if f.warm_fraction < MIN_WARM_FRACTION:
        out.append("warm_fraction")
    if f.coverage > MAX_COVERAGE:
        out.append("coverage")
    if f.edge_contact > MAX_EDGE_CONTACT:
        out.append("edge_contact")
    if f.solidity < MIN_SOLIDITY:
        out.append("solidity")
    if f.circle_fill < MIN_CIRCLE_FILL:
        out.append("circle_fill")
    return out


def check(bgr: np.ndarray) -> dict:
    """Verdict for one raw upload.

    Returns {"is_fundus": bool | None, "failed": [...], "features": {...} | None,
    "message": str | None}. `is_fundus` is None when there is no illuminated region at
    all — the caller passes that case on to the coverage guard unchanged.
    """
    f = measure(bgr)
    if f is None:
        return {"is_fundus": None, "failed": [], "features": None, "message": None}
    failed = failed_rules(f)
    if not failed:
        return {"is_fundus": True, "failed": [], "features": asdict(f), "message": None}
    reasons = "; ".join(_RULE_TEXT[r] for r in failed)
    return {
        "is_fundus": False,
        "failed": failed,
        "features": asdict(f),
        "message": (
            "This does not look like a usable fundus (retinal) photograph, so no grade "
            f"is produced. Reason: {reasons}. Upload a colour photograph of the back of "
            "the eye taken with a retinal camera, with the round retinal image and its "
            "dark border fully in view."
        ),
    }

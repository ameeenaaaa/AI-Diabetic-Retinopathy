"""Measure how often the fundus check (DECISION-076) declines real fundus images.

The thresholds in src/inference/fundus_check.py were set on a small sample. Run this over
a larger set of REAL fundus photographs — the training split on Kaggle, or APTOS — to
measure the false-decline rate before relying on them. Revise a threshold only through a
docs/DECISIONS.md entry.

    python -m src.inference.check_fundus_rate <folder-of-images> [--limit 2000]
"""

from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path

import cv2
import numpy as np

from src.inference.fundus_check import check

EXTS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", type=Path)
    ap.add_argument("--limit", type=int, default=0, help="stop after N images (0 = all)")
    args = ap.parse_args()

    files = sorted(p for p in args.folder.rglob("*") if p.suffix.lower() in EXTS)
    if args.limit:
        files = files[: args.limit]
    verdicts, rules, feats = Counter(), Counter(), {}
    for p in files:
        bgr = cv2.imread(str(p), cv2.IMREAD_COLOR)
        if bgr is None:
            verdicts["unreadable"] += 1
            continue
        r = check(bgr)
        verdicts[{True: "accepted", False: "declined", None: "no_retina"}[r["is_fundus"]]] += 1
        rules.update(r["failed"])
        for k, v in (r["features"] or {}).items():
            feats.setdefault(k, []).append(v)

    n = sum(verdicts.values())
    print(f"{n} images from {args.folder}")
    for k in ("accepted", "declined", "no_retina", "unreadable"):
        print(f"  {k:10s} {verdicts[k]:6d}  ({verdicts[k] / max(n, 1):.1%})")
    print("rules that fired (an image can fail several):")
    for k, v in rules.most_common():
        print(f"  {k:14s} {v}")
    print("feature percentiles (p1 / p5 / p50 / p95 / p99):")
    for k, vs in feats.items():
        q = np.percentile(vs, [1, 5, 50, 95, 99])
        print(f"  {k:14s} " + " / ".join(f"{x:.3f}" for x in q))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Capture quality of an upload, reported alongside the grade (DECISION-076).

The coverage guard checks framing only. A blurred, dark or over-exposed photograph is
otherwise graded with no comment, although the Phase 2 QA sample showed such captures
exist in EyePACS and the model has no way to say it cannot see.

This reuses the Phase 2 instrument unchanged — `scan_quality` and its fixed thresholds in
src/data/preprocess.py — so an upload is judged by exactly the rules the training images
were inspected with. Nothing is recomputed and no new threshold is introduced.

IT WARNS; IT DOES NOT DECLINE. Training data is not filtered by these flags (Phase 2 kept
every flagged image in its split), so the model has seen captures like these. Refusing
them at upload would be stricter than the evidence supports; saying plainly that the
capture is poor and the reading less dependable is what the evidence supports. Only the
capture-quality flags are used here. Framing-type flags (tiny retina, off-centre) are the
coverage guard's job and the fundus check's job, and are not repeated.
"""

from __future__ import annotations

import numpy as np

from src.data.preprocess import scan_quality

# The capture-quality subset of QualityStats.flags(), with words for a person.
_QUALITY_FLAGS = {
    "blurred": "blurred, out of focus, or too low in resolution",
    "dark": "too dark",
    "mostly-black": "mostly black",
    "over-exposed": "over-exposed (washed out by glare)",
    "washed-out": "washed out (little colour)",
    "low-contrast": "low in contrast",
    "bright-artefact": "affected by flare or a bright artefact",
}

OK = "ok"
POOR = "poor_capture_quality"


def assess_quality(bgr: np.ndarray) -> dict:
    """{"status": "ok" | "poor_capture_quality", "flags": [...], "message": str}."""
    flags = [f for f in scan_quality(bgr).flags() if f in _QUALITY_FLAGS]
    if not flags:
        return {"status": OK, "flags": [], "message": "No capture-quality problem was found."}
    words = ", ".join(_QUALITY_FLAGS[f] for f in flags)
    return {
        "status": POOR,
        "flags": flags,
        "message": (
            f"This photograph appears {words}. The model was not designed to say when it "
            "cannot see the retina properly, so this reading is less dependable than "
            "usual. If possible, retake the photograph and upload it again."
        ),
    }

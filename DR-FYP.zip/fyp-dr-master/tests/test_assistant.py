"""The assistant engine, its guard rules and its provider connectors (DECISION-078).

No network: the language model is either absent (offline), a fake that returns a chosen
draft, or a local HTTP server that answers in Gemini's / OpenAI's JSON shape so the
request we send and the reply we parse are both checked.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from backend.assistant import guard
from backend.assistant.engine import Assistant, result_summary
from backend.assistant.providers import Gemini, OpenAICompatible, Provider, ProviderError
from backend.assistant.retrieval import Retriever

MILD_REFER = {"graded": True, "grade": 1, "grade_name": "Mild", "score": 1.21,
              "referable": True, "referral_threshold": 0.9488,
              "cuts": [0.5, 1.62164, 2.17199, 3.272691],
              "guard": {"status": "ok", "message": "Framing is within range."},
              "quality": {"status": "ok", "flags": [], "message": "Quality ok."}}


class FakeLLM(Provider):
    name, label = "fake", "Fake model"

    def __init__(self, draft: str) -> None:
        self.draft, self.calls = draft, []

    def available(self) -> bool:
        return True

    def generate(self, system, turns, user) -> str:
        self.calls.append((system, turns, user))
        return self.draft


# ------------------------------------------------------------------ retrieval
def test_every_knowledge_file_has_a_source_and_url():
    r = Retriever()
    assert len(r.passages) >= 30
    for p in r.passages:
        assert p.source and p.url and p.kind in ("health", "app")


@pytest.mark.parametrize("q, expected", [
    ("Can I drive after the eye drops?", "screening#2"),
    ("What does the heatmap show?", "app_gradcam#"),
    ("Why does it say Mild but Refer?", "app_how_it_works#3"),
    ("What is macular oedema?", "dmo#1"),
])
def test_retrieval_finds_the_right_passage(q, expected):
    top = Retriever().search(q, k=2)
    assert any(p.id.startswith(expected) for _, p in top)


def test_off_topic_questions_retrieve_nothing():
    assert Retriever().search("What is the capital of France?") == []
    assert Retriever().search("What's the best phone to buy?") == []


# ------------------------------------------------------------------ guard
@pytest.mark.parametrize("q", ["I suddenly can't see", "a curtain across my vision",
                               "flashes of light", "my sight went dark overnight",
                               "اچانک نظر دھندلی ہو گئی"])
def test_urgent(q):
    assert guard.classify(q) == "urgent"


@pytest.mark.parametrize("q, kind", [("How much insulin should I take?", "medication"),
                                     ("Do I have diabetic retinopathy?", "diagnosis"),
                                     ("So I don't have retinopathy, right?", "diagnosis"),
                                     ("What is HbA1c?", None)])
def test_classify(q, kind):
    assert guard.classify(q) == kind


def test_the_fixed_replies_pass_the_output_check():
    for lang in ("en", "ur"):
        for reply in (guard.URGENT_REPLY, guard.MEDICATION_REPLY, guard.OUT_OF_SCOPE_REPLY,
                      guard.BLOCKED_REPLY):
            assert guard.unsafe_reason(reply[lang]) is None
        for r in (None, MILD_REFER, MILD_REFER | {"referable": False}):
            assert guard.unsafe_reason(guard.diagnosis_reply(r, 26, lang)) is None


# ------------------------------------------------------------------ engine
def test_the_result_goes_to_the_model_verbatim():
    llm = FakeLLM("Your grade is Mild and the referral answer is Refer [R].")
    r = Assistant(llm).answer("Why Mild and Refer?", result=MILD_REFER)
    assert r.outcome == "answered" and r.cited == ["R"]
    _, _, user = llm.calls[-1]                   # the last call writes the answer
    assert result_summary(MILD_REFER) in user
    assert "[R]" in user


def test_an_unsafe_draft_is_withheld():
    llm = FakeLLM("Good news: your eyes are healthy and there is no need to see a doctor [S1].")
    r = Assistant(llm).answer("What does my result mean?", result=MILD_REFER)
    assert r.outcome == "blocked" and "eyes are healthy" not in r.answer


def test_urgent_never_calls_the_model():
    llm = FakeLLM("anything")
    r = Assistant(llm).answer("I suddenly lost my vision", result=MILD_REFER)
    assert r.outcome == "urgent" and llm.calls == []


def test_a_failing_model_falls_back_to_the_sources():
    class Broken(FakeLLM):
        def generate(self, *a):
            raise ProviderError("down")
    r = Assistant(Broken("")).answer("What happens at a screening appointment?")
    assert r.outcome == "error" and r.mode == "offline" and r.cited


def test_specialist_action_carries_the_city():
    r = Assistant(Provider()).answer("Find me an eye specialist in Lahore",
                                     cities=["Lahore", "Karachi"])
    assert {"type": "find_specialist", "city": "Lahore"} in r.actions


# ------------------------------------------------------------------ connectors
class _Server:
    """A local HTTP server answering like the real APIs, recording the last request."""

    def __init__(self, reply: dict):
        outer = self
        self.last = None

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers["Content-Length"])
                outer.last = {"path": self.path,
                              "headers": {k.lower(): v for k, v in self.headers.items()},
                              "body": json.loads(self.rfile.read(n))}
                b = json.dumps(reply).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b)

            def log_message(self, *a):
                pass

        self.httpd = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.httpd.server_port}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()


def test_gemini_request_and_reply_shape(monkeypatch):
    srv = _Server({"candidates": [{"content": {"parts": [
        {"text": "thinking...", "thought": True}, {"text": "Answer [S1]."}]}}]})
    try:
        monkeypatch.setattr(Gemini, "BASE", srv.url)
        out = Gemini("KEY", "gemini-flash-latest").generate("SYS", [("user", "hi"),
                                                                    ("assistant", "hello")], "Q")
        assert out == "Answer [S1]."
        assert srv.last["path"] == "/models/gemini-flash-latest:generateContent"
        assert srv.last["headers"]["x-goog-api-key"] == "KEY"
        body = srv.last["body"]
        assert body["systemInstruction"]["parts"][0]["text"] == "SYS"
        assert [c["role"] for c in body["contents"]] == ["user", "model", "user"]
    finally:
        srv.close()


def test_groq_request_and_reply_shape():
    srv = _Server({"choices": [{"message": {"content": "Answer [S2]."}}]})
    try:
        p = OpenAICompatible("groq", srv.url, "KEY", "some-model")
        assert p.generate("SYS", [], "Q") == "Answer [S2]."
        assert srv.last["path"] == "/chat/completions"
        assert srv.last["headers"]["authorization"] == "Bearer KEY"
        assert srv.last["body"]["messages"][0] == {"role": "system", "content": "SYS"}
    finally:
        srv.close()


def test_gemini_falls_back_to_the_next_model_when_one_is_busy(monkeypatch):
    calls = []

    def fake(self, model, system, turns, user, timeout=20):
        calls.append(model)
        if model == "busy-model":
            raise ProviderError("the model is busy or unavailable (HTTP 503)", retryable=True)
        if model == "gone-model":
            raise ProviderError("the model name was not found (HTTP 404)", retryable=True)
        return "Answer [S1]."

    monkeypatch.setattr(Gemini, "_generate", fake)
    monkeypatch.setattr("backend.assistant.providers.RETRY_WAIT_S", 0)
    g = Gemini("KEY", "busy-model, gone-model, good-model")
    assert g.generate("SYS", [], "Q") == "Answer [S1]."
    assert calls == ["busy-model", "busy-model", "gone-model", "good-model"]
    assert g.label == "Gemini (good-model)"


def test_a_rejected_key_is_not_retried(monkeypatch):
    def fake(self, model, *a):
        raise ProviderError("the API key was rejected (HTTP 403)")
    monkeypatch.setattr(Gemini, "_generate", fake)
    with pytest.raises(ProviderError, match="rejected"):
        Gemini("KEY", "a, b").generate("SYS", [], "Q")


def test_gemini_asks_for_low_thinking_and_drops_it_if_refused(monkeypatch):
    bodies = []

    def fake_post(url, body, headers, timeout=20):
        bodies.append(json.loads(json.dumps(body)))
        if "thinkingConfig" in body["generationConfig"]:
            raise ProviderError('HTTP 400: {"message": "thinkingLevel is not supported"}')
        return {"candidates": [{"content": {"parts": [{"text": "Answer [S1]."}]}}]}

    monkeypatch.setattr("backend.assistant.providers._post", fake_post)
    g = Gemini("KEY", "old-model")
    assert g.generate("SYS", [], "Q") == "Answer [S1]."
    assert bodies[0]["generationConfig"]["thinkingConfig"] == {"thinkingLevel": "low"}
    assert "thinkingConfig" not in bodies[1]["generationConfig"]
    g.generate("SYS", [], "Q")                    # remembered: no second refusal
    assert len(bodies) == 3 and "thinkingConfig" not in bodies[2]["generationConfig"]


class RewriteLLM(FakeLLM):
    """Rephrases search words on the first call, answers on the second."""

    def __init__(self, words: str):
        super().__init__("Answer [S1].")
        self.words = words

    def generate(self, system, turns, user):
        self.calls.append((system, turns, user))
        return self.words if system.startswith("You turn a patient's question") else self.draft


def test_a_weak_search_is_rephrased_and_retried():
    q = "How regularly do I need the photo test?"
    assert not any(p.id == "screening#3" for _, p in Retriever().search(q))
    llm = RewriteLLM("diabetic eye screening interval how often")
    hits, searched_as = Assistant(llm).find_passages(q)
    assert "screening#3" in [p.id for p in hits]
    assert searched_as == "diabetic eye screening interval how often"


def test_rephrasing_cannot_open_an_off_topic_question():
    llm = RewriteLLM("NONE")
    r = Assistant(llm).answer("What is the capital of France?")
    assert r.outcome == "out_of_scope" and r.searched_as == ""


def test_a_strong_search_is_not_rephrased():
    llm = RewriteLLM("unused")
    Assistant(llm).find_passages("Can I drive after the eye drops at screening?")
    assert not any(c[0].startswith("You turn") for c in llm.calls)


def test_skipping_an_eye_exam_is_not_a_medicine_question():
    assert guard.classify("If it says not flagged, can I skip my eye exam?") is None
    assert guard.classify("can I take paracetamol") == "medication"

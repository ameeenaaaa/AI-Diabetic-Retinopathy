"""Accounts, roles, records, specialist review, admin stats and the assistant routes
(DECISION-078). Runs against the real FastAPI app with an in-memory database and a fake
predictor, so no checkpoint is needed and the grading model itself is not under test here
(that is tests/test_predictor.py and tests/test_api.py).
"""

from __future__ import annotations

import dataclasses
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient

from backend import security
from backend.app import create_app
from backend.assistant.engine import Assistant
from backend.assistant.providers import Provider
from backend.config import Settings
from backend.seed import DEMO_ADMIN, DEMO_PATIENT, SPECIALIST_PASSWORD, specialist_email

GRADE_NAMES = ["No DR", "Mild", "Moderate", "Severe", "Proliferative"]


@dataclasses.dataclass
class FakeDeployment:
    run_id: str = "phase4_stage3_arm_e_efficientnet_b0"
    seed: int = 42
    arch: str = "efficientnet_b0"
    head: str = "ordinal_regression"
    image_size: int = 224
    reported_val_qwk: float = 0.7569
    reported_val_sens_at_spec95: float = 0.7360

    def provenance(self) -> str:
        return "test"


@dataclasses.dataclass
class FakeCalibration:
    split: str = "train"
    n_images: int = 10
    low: float = 0.6138
    high: float = 0.8172


DISCLAIMER = ["a", "b", "c", "d"]


class FakePredictor:
    """Grades by file content: b'mild' -> Mild + Refer, b'dice' -> declined, else No DR."""

    deployment = FakeDeployment()
    calibration = FakeCalibration()

    def predict(self, raw: bytes, explain: bool = True) -> dict:
        guard = {"status": "ok", "coverage": 0.7, "low": 0.61, "high": 0.82,
                 "message": "Framing is within the range the model was trained on."}
        if raw.startswith(b"dice"):
            return {"graded": False, "guard": {"status": "not_a_fundus_photograph",
                                               "coverage": None, "low": 0.61, "high": 0.82,
                                               "message": "Not a fundus photograph."},
                    "run_id": "r", "disclaimer": DISCLAIMER}
        score, grade, refer = (1.2, 1, True) if raw.startswith(b"mild") else (0.1, 0, False)
        return {"graded": True, "grade": grade, "grade_name": GRADE_NAMES[grade],
                "score": score, "referable": refer, "referral_threshold": 0.9488,
                "cuts": [0.5, 1.62164, 2.17199, 3.272691], "guard": guard,
                "quality": {"status": "ok", "flags": [], "message": "Capture quality ok."},
                "run_id": "r", "disclaimer": DISCLAIMER}

    def preprocess_only(self, raw):           # pragma: no cover - explain=False in tests
        raise AssertionError("not used")


@pytest.fixture()
def client(monkeypatch) -> TestClient:
    monkeypatch.setattr(security, "ITERATIONS", 1000)     # fast hashing for tests
    settings = dataclasses.replace(Settings.from_env(), db_path=":memory:", seed_demo=True,
                                   assistant_provider="offline")
    app = create_app(FakePredictor(), settings=settings, assistant=Assistant(Provider()))
    return TestClient(app)


def login(client, email, password) -> dict:
    r = client.post("/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def grade(client, headers, content=b"mild-fundus") -> dict:
    r = client.post("/predict?explain=false", headers=headers,
                    files={"file": ("eye.png", content, "image/png")})
    assert r.status_code == 200, r.text
    return r.json()


# ------------------------------------------------------------------ accounts
def test_patient_can_register_and_sign_in(client):
    r = client.post("/auth/register", json={"name": "Ali", "email": "ali@x.pk",
                                            "password": "abc12345", "city": "Lahore"})
    assert r.status_code == 200 and r.json()["user"]["role"] == "patient"
    assert "password_hash" not in r.json()["user"]
    h = login(client, "ali@x.pk", "abc12345")
    assert client.get("/auth/me", headers=h).json()["user"]["email"] == "ali@x.pk"


def test_registration_rejects_weak_passwords_and_duplicates(client):
    assert client.post("/auth/register", json={"name": "A", "email": "a@x.pk",
                                               "password": "short"}).status_code == 400
    body = {"name": "A", "email": "a@x.pk", "password": "abc12345"}
    assert client.post("/auth/register", json=body).status_code == 200
    assert client.post("/auth/register", json=body).status_code == 409


def test_wrong_password_and_logout(client):
    r = client.post("/auth/login", json={"email": DEMO_PATIENT[0], "password": "nope1234"})
    assert r.status_code == 401
    h = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    assert client.post("/auth/logout", headers=h).status_code == 200
    assert client.get("/auth/me", headers=h).status_code == 401


def test_roles_are_enforced(client):
    patient = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    doctor = login(client, specialist_email("s01"), SPECIALIST_PASSWORD)
    assert client.get("/admin/stats", headers=patient).status_code == 403
    assert client.get("/admin/stats", headers=doctor).status_code == 403
    assert client.get("/reviews/queue", headers=patient).status_code == 403
    assert client.get("/screenings").status_code == 401


# ------------------------------------------------------------------ grading + saving
def test_predict_still_works_without_an_account(client):
    r = grade(client, {})
    assert r["graded"] and "result_id" not in r


def test_saved_screening_is_what_the_model_returned(client):
    h = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    r = grade(client, h)
    saved = client.post("/screenings", headers=h, json={"result_id": r["result_id"],
                                                        "eye": "left", "label": "clinic"})
    assert saved.status_code == 200
    s = saved.json()
    assert s["result"]["grade_name"] == "Mild" and s["result"]["referable"] is True
    assert s["meta"]["reported_val_sens_at_spec95"] == 0.7360
    # a result id is single use
    again = client.post("/screenings", headers=h, json={"result_id": r["result_id"]})
    assert again.status_code == 404
    assert len(client.get("/screenings", headers=h).json()) == 1


def test_patients_cannot_see_each_others_screenings(client):
    h1 = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    sid = client.post("/screenings", headers=h1,
                      json={"result_id": grade(client, h1)["result_id"]}).json()["id"]
    client.post("/auth/register", json={"name": "B", "email": "b@x.pk",
                                        "password": "abc12345"})
    h2 = login(client, "b@x.pk", "abc12345")
    assert client.get(f"/screenings/{sid}", headers=h2).status_code == 404
    assert client.delete(f"/screenings/{sid}", headers=h2).status_code == 404


# ------------------------------------------------------------------ review
def test_specialist_review_is_stored_beside_the_model_answer(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    sid = client.post("/screenings", headers=p,
                      json={"result_id": grade(client, p)["result_id"],
                            "request_review": True}).json()["id"]
    d = login(client, specialist_email("s05"), SPECIALIST_PASSWORD)
    queue = client.get("/reviews/queue", headers=d).json()
    assert [q["id"] for q in queue] == [sid]
    bad = client.post(f"/screenings/{sid}/review", headers=d,
                      json={"agrees": False, "grade": 1, "refer": True})
    assert bad.status_code == 400                    # same as the model: use "agree"
    r = client.post(f"/screenings/{sid}/review", headers=d,
                    json={"agrees": False, "grade": 2, "refer": True, "note": "IRMA"})
    assert r.status_code == 200
    seen = client.get(f"/screenings/{sid}", headers=p).json()
    assert seen["result"]["grade_name"] == "Mild"   # the model's answer is untouched
    assert seen["review"]["grade_name"] == "Moderate" and seen["review"]["note"] == "IRMA"
    stats = client.get("/admin/stats", headers=login(client, DEMO_ADMIN[0], DEMO_ADMIN[1]))
    sc = stats.json()["screenings"]
    assert sc["reviewed"] == 1 and sc["agreed"] == 0 and sc["table"][1][2] == 1


# ------------------------------------------------------------------ appointments
def test_appointment_flow_between_patient_and_clinic(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    day = (date.today() + timedelta(days=3)).isoformat()
    a = client.post("/appointments", headers=p, json={
        "specialist_id": "s01", "patient_name": "Demo", "phone": "+92 300 1234567",
        "preferred_date": day, "slot": "morning"})
    assert a.status_code == 200 and a.json()["status"] == "requested"
    aid = a.json()["id"]
    other = login(client, specialist_email("s02"), SPECIALIST_PASSWORD)
    assert client.get("/appointments", headers=other).json() == []
    d = login(client, specialist_email("s01"), SPECIALIST_PASSWORD)
    assert [x["id"] for x in client.get("/appointments", headers=d).json()] == [aid]
    assert client.patch(f"/appointments/{aid}", headers=p,
                        json={"status": "confirmed"}).status_code == 400
    r = client.patch(f"/appointments/{aid}", headers=d,
                     json={"status": "confirmed", "note": "Tuesday 10am"})
    assert r.json()["status"] == "confirmed" and r.json()["specialistNote"] == "Tuesday 10am"
    assert client.patch(f"/appointments/{aid}", headers=p,
                        json={"status": "cancelled"}).json()["status"] == "cancelled"


def test_past_dates_are_refused(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    r = client.post("/appointments", headers=p, json={
        "specialist_id": "s01", "patient_name": "Demo", "phone": "+92 300 1234567",
        "preferred_date": "2000-01-01", "slot": "morning"})
    assert r.status_code == 400


# ------------------------------------------------------------------ admin
def test_dashboard_counts_outcomes_without_images(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    grade(client, p)
    grade(client, p, b"dice")
    grade(client, p, b"plain")
    s = client.get("/admin/stats", headers=login(client, DEMO_ADMIN[0], DEMO_ADMIN[1]))
    u = s.json()["uploads"]
    assert u["total"] == 3 and u["graded"] == 2 and u["declined_not_fundus"] == 1
    assert u["referable"] == 1 and u["grades"][:2] == [1, 1]


def test_admin_creates_a_specialist_who_can_sign_in(client):
    a = login(client, DEMO_ADMIN[0], DEMO_ADMIN[1])
    r = client.post("/admin/specialists", headers=a, json={
        "name": "Dr New", "email": "new@clinic.pk", "password": "abc12345",
        "clinic": "New Eye Clinic", "city": "Quetta"})
    assert r.status_code == 200
    assert any(s["clinic"] == "New Eye Clinic" for s in client.get("/specialists").json())
    h = login(client, "new@clinic.pk", "abc12345")
    uid = r.json()["id"]
    client.patch(f"/admin/users/{uid}", headers=a, json={"active": False})
    assert client.get("/auth/me", headers=h).status_code == 401


# ------------------------------------------------------------------ assistant
def test_assistant_urgent_question_never_reaches_a_model(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    r = client.post("/assistant/chat", headers=p,
                    json={"message": "I suddenly can't see out of my left eye"}).json()
    assert r["outcome"] == "urgent" and r["mode"] == "fixed"
    assert "today" in r["answer"]


def test_assistant_explains_the_patients_own_result(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    rid = grade(client, p)["result_id"]
    r = client.post("/assistant/chat", headers=p, json={
        "message": "Why does my result say Mild but Refer?", "result_id": rid}).json()
    assert r["outcome"] == "answered"
    assert "Mild" in r["answer"] and "Refer" in r["answer"]
    assert any(s["id"] == "R" for s in r["sources"])


def test_assistant_will_not_diagnose(client):
    p = login(client, DEMO_PATIENT[0], DEMO_PATIENT[1])
    rid = grade(client, p, b"plain")["result_id"]
    r = client.post("/assistant/chat", headers=p, json={
        "message": "So I don't have retinopathy, right? Am I fine?", "result_id": rid}).json()
    assert r["outcome"] == "refused"
    assert "not reassurance" in r["answer"]


def test_assistant_needs_an_account(client):
    assert client.post("/assistant/chat", json={"message": "hi"}).status_code == 401

"""The fundus check (DECISION-076): non-retinal uploads must not be graded.

Every image here is synthetic so the test runs without the dataset. The synthetic fundus
mirrors the one tests/test_predictor.py and tests/test_api.py already grade, so this file
also pins that those tests' images still count as fundus photographs.
"""

from __future__ import annotations

import cv2
import numpy as np
import pytest

from src.inference.fundus_check import (
    MAX_COVERAGE, MIN_CIRCLE_FILL, MIN_WARM_FRACTION, check, failed_rules, measure,
)


def _fundus(size: int = 600, radius_frac: float = 0.45) -> np.ndarray:
    """The same synthetic fundus the predictor and API tests use."""
    img = np.zeros((size, size, 3), np.uint8)
    cv2.circle(img, (size // 2, size // 2), int(size * radius_frac), (40, 70, 120), -1)
    return img


def _sensor_cut_fundus(size: int = 600) -> np.ndarray:
    """A 4:3 frame whose disc is cut by the sensor top and bottom, as in EyePACS."""
    h, w = size * 3 // 4, size
    img = np.zeros((h, w, 3), np.uint8)
    cv2.circle(img, (w // 2, h // 2), int(h * 0.58), (40, 80, 170), -1)
    return img


def _dice_on_table(bg=(60, 110, 170), body=(40, 40, 200)) -> np.ndarray:
    img = np.full((600, 600, 3), bg, np.uint8)
    cv2.rectangle(img, (180, 180), (420, 420), body, -1)
    cv2.circle(img, (300, 300), 30, (240, 240, 240), -1)
    return img


def _square_on_black(body=(40, 40, 200)) -> np.ndarray:
    img = np.zeros((600, 600, 3), np.uint8)
    cv2.rectangle(img, (150, 150), (450, 450), body, -1)
    return img


# -- real-looking fundus images are accepted --------------------------------------
@pytest.mark.parametrize("img", [_fundus(), _fundus(radius_frac=0.40), _sensor_cut_fundus()])
def test_a_fundus_shaped_image_is_accepted(img):
    r = check(img)
    assert r["is_fundus"] is True, r
    assert r["message"] is None


def test_the_predictor_tests_synthetic_fundus_still_passes():
    """Guards against silently breaking every existing predictor/API test."""
    assert check(_fundus())["is_fundus"] is True


# -- the reported failure: a photo of dice ----------------------------------------
def test_dice_on_a_table_is_declined():
    r = check(_dice_on_table())
    assert r["is_fundus"] is False
    assert "coverage" in r["failed"]
    assert "not look like a usable fundus" in r["message"]


def test_white_dice_on_grey_is_declined_for_colour_too():
    r = check(_dice_on_table(bg=(200, 200, 205), body=(245, 245, 245)))
    assert r["is_fundus"] is False
    assert "warm_fraction" in r["failed"]


def test_a_red_square_on_true_black_is_declined_as_not_round():
    """The hardest synthetic case: right colour, dark border — but not a disc."""
    r = check(_square_on_black())
    assert r["is_fundus"] is False
    assert r["failed"] == ["circle_fill"]


def test_a_greyscale_photo_is_declined():
    img = np.random.default_rng(0).integers(30, 230, (500, 500), dtype=np.uint8)
    assert check(img)["is_fundus"] is False


def test_a_tightly_cropped_fundus_with_no_border_is_declined():
    """By design: no dark border means no field of view to judge."""
    img = _fundus(radius_frac=0.9)[150:450, 150:450]
    r = check(img)
    assert r["is_fundus"] is False and "coverage" in r["failed"]


# -- the no-retina path is not taken over -----------------------------------------
def test_an_all_black_frame_is_left_to_the_coverage_guard():
    r = check(np.zeros((600, 600, 3), np.uint8))
    assert r["is_fundus"] is None
    assert measure(np.zeros((600, 600, 3), np.uint8)) is None


# -- the rules are the documented constants, applied as documented ------------------
def test_each_rule_fires_on_its_own_feature():
    from src.inference.fundus_check import FundusFeatures
    good = FundusFeatures(1.0, 0.6, 0.0, 1.0, 1.0)
    assert failed_rules(good) == []
    assert failed_rules(FundusFeatures(MIN_WARM_FRACTION - 0.01, 0.6, 0, 1, 1)) == ["warm_fraction"]
    assert failed_rules(FundusFeatures(1, MAX_COVERAGE + 0.01, 0, 1, 1)) == ["coverage"]
    assert failed_rules(FundusFeatures(1, 0.6, 0, 1, MIN_CIRCLE_FILL - 0.01)) == ["circle_fill"]

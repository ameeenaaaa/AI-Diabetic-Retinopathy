"""Capture-quality warning (DECISION-076): reuses the Phase 2 rules, never declines."""

from __future__ import annotations

import cv2
import numpy as np

from src.inference.quality_check import OK, POOR, assess_quality


def _textured_fundus(size: int = 1200, brightness: int = 170) -> np.ndarray:
    rng = np.random.default_rng(0)
    img = np.zeros((size, size, 3), np.uint8)
    disc = np.zeros((size, size), np.uint8)
    cv2.circle(disc, (size // 2, size // 2), int(size * 0.45), 255, -1)
    base = np.dstack([np.full((size, size), c, np.uint8) for c in
                      (brightness // 4, brightness // 2, brightness)])
    noise = rng.integers(-40, 40, (size, size, 1))
    tex = np.clip(base.astype(int) + noise, 0, 255).astype(np.uint8)
    for i in range(25):   # vessel-like lines give real focus detail
        a = rng.uniform(0, np.pi)
        x0, y0 = size // 2, size // 2
        cv2.line(tex, (int(x0 - 500 * np.cos(a)), int(y0 - 500 * np.sin(a))),
                 (int(x0 + 500 * np.cos(a)), int(y0 + 500 * np.sin(a))), (20, 30, 90), 4)
    img[disc > 0] = tex[disc > 0]
    return img


def test_a_sharp_well_exposed_capture_has_no_warning():
    r = assess_quality(_textured_fundus())
    assert r["status"] == OK and r["flags"] == []


def test_a_blurred_capture_is_flagged():
    r = assess_quality(cv2.GaussianBlur(_textured_fundus(), (0, 0), 25))
    assert r["status"] == POOR and "blurred" in r["flags"]
    assert "retake" in r["message"]


def test_a_dark_capture_is_flagged():
    r = assess_quality(_textured_fundus(brightness=55))
    assert r["status"] == POOR and "dark" in r["flags"]


def test_framing_flags_are_not_repeated_here():
    """Tiny retina / off-centre belong to the coverage guard and fundus check."""
    img = np.zeros((1200, 1200, 3), np.uint8)
    img[100:400, 100:400] = _textured_fundus(300)
    flags = assess_quality(img)["flags"]
    assert "tiny-retina" not in flags and "off-centre" not in flags

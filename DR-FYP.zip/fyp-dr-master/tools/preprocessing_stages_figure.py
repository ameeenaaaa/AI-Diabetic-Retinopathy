"""Before-and-after preprocessing figure for the report (Figure 5.3).

Runs ONE fundus image through the real pipeline in src/data/preprocess.py and saves a
four-panel figure: original -> square crop -> Ben Graham enhanced -> final 224 x 224.
Every panel comes from the same functions preprocess_image() uses, so the figure shows
exactly what the model receives.

Use a VALIDATION or TEST image (see data/splits/val.csv), not a training image or a
fixture, and say which split it came from in the caption.

    python tools/preprocessing_stages_figure.py path\\to\\image.jpeg
    python tools/preprocessing_stages_figure.py path\\to\\image.jpeg --out figure_5_3.png
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.data.preprocess import (  # noqa: E402
    BASE_CONFIG,
    enhance,
    load_preprocess_config,
    preprocess_image,
    retina_mask,
    square_crop,
)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image", type=Path, help="a validation or test fundus image")
    ap.add_argument("--out", type=Path, default=Path("figure_5_3_preprocessing.png"))
    args = ap.parse_args()

    bgr = cv2.imread(str(args.image), cv2.IMREAD_COLOR)
    if bgr is None:
        print(f"could not read {args.image}", file=sys.stderr)
        return 1

    cfg = load_preprocess_config(BASE_CONFIG)
    mask = retina_mask(bgr)
    if not mask.any():
        print("no retina found in this image — choose another", file=sys.stderr)
        return 1

    cropped, cmask = square_crop(bgr, mask)
    enhanced = enhance(cropped, cfg, cmask)
    final = preprocess_image(bgr, cfg)  # the exact output the model receives

    h, w = bgr.shape[:2]
    panels = [
        (bgr, f"(a) Original image\n{w} × {h} px"),
        (cropped, f"(b) Square crop on retina\n{cropped.shape[1]} × {cropped.shape[0]} px"),
        (enhanced, "(c) Ben Graham enhancement\nlocal contrast normalised"),
        (final, f"(d) Final model input\n{cfg.image_size} × {cfg.image_size} px, re-masked"),
    ]

    fig, axes = plt.subplots(1, 4, figsize=(14, 4.2))
    for ax, (img, title) in zip(axes, panels):
        ax.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        ax.set_title(title, fontsize=11)
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(args.out, dpi=200, bbox_inches="tight", facecolor="white")
    print(f"saved {args.out.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

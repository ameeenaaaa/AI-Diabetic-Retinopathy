"""The admin dashboard and account management.

The dashboard is MONITORING, not marketing. It reports what the deployed model is being
asked to do and how often it is outside what it was validated on — the in-use version of
the thesis finding that the model does not generalise (DECISION-060):

* how many uploads were declined (not a fundus photograph / no retina), graded with a
  framing warning, or graded with a capture-quality warning;
* the grade mix and referral rate of what was graded;
* how often specialists AGREE with the model on reviewed cases, and the model-vs-
  specialist grade table for the ones they corrected.

Agreement here is measured on cases patients chose to send for review, which skews toward
referable and warned images. It is not a validation metric and the page says so.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from backend.db import Database, now, row
from backend.security import (EMAIL_RE, hash_password, password_problem, public_user,
                              require)
from src.inference.predictor import GRADE_NAMES

router = APIRouter(prefix="/admin", tags=["admin"])
admin_only = require("admin")


def _db(request: Request) -> Database:
    return request.app.state.db


def _count(c, sql: str, args=()) -> int:
    return int(c.execute(sql, args).fetchone()[0] or 0)


@router.get("/stats")
def stats(request: Request, _: dict = Depends(admin_only)) -> dict:
    with _db(request).connect() as c:
        users = {r["role"]: r["n"] for r in c.execute(
            "SELECT role, COUNT(*) AS n FROM users WHERE active = 1 GROUP BY role")}
        uploads = {r["guard_status"]: r["n"] for r in c.execute(
            "SELECT guard_status, COUNT(*) AS n FROM predict_log GROUP BY guard_status")}
        total_uploads = sum(uploads.values())
        graded = _count(c, "SELECT COUNT(*) FROM predict_log WHERE graded = 1")
        poor_quality = _count(c, "SELECT COUNT(*) FROM predict_log WHERE graded = 1 AND "
                                 "quality_status = 'poor_capture_quality'")
        referable = _count(c, "SELECT COUNT(*) FROM predict_log WHERE graded = 1 AND "
                              "referable = 1")
        grades = [0] * 5
        for r in c.execute("SELECT grade, COUNT(*) AS n FROM predict_log WHERE graded = 1 "
                           "GROUP BY grade"):
            grades[r["grade"]] = r["n"]

        saved = _count(c, "SELECT COUNT(*) FROM screenings")
        pending = _count(c, "SELECT COUNT(*) FROM screenings WHERE review_status='pending'")
        reviewed = [dict(r) for r in c.execute(
            "SELECT grade, referable, review_agrees, review_grade, review_refer "
            "FROM screenings WHERE review_status = 'reviewed'")]
        table = [[0] * 5 for _ in range(5)]          # rows: model grade, cols: specialist
        for r in reviewed:
            table[r["grade"]][r["review_grade"]] += 1
        agreed = sum(1 for r in reviewed if r["review_agrees"])
        refer_agree = sum(1 for r in reviewed if bool(r["referable"]) == bool(r["review_refer"]))

        appts = {r["status"]: r["n"] for r in c.execute(
            "SELECT status, COUNT(*) AS n FROM appointments GROUP BY status")}
        assistant = {r["outcome"]: r["n"] for r in c.execute(
            "SELECT outcome, COUNT(*) AS n FROM assistant_log GROUP BY outcome")}

        # Uploads per week for the last 12 weeks, oldest first.
        start = datetime.now(timezone.utc) - timedelta(weeks=12)
        weekly = [0] * 12
        for r in c.execute("SELECT created_at FROM predict_log WHERE created_at >= ?",
                           (start.isoformat(timespec="seconds"),)):
            t = datetime.fromisoformat(r["created_at"])
            i = min(11, max(0, int((t - start).days // 7)))
            weekly[i] += 1

    framing = uploads.get("framing_below_training_range", 0) + \
        uploads.get("framing_above_training_range", 0)
    return {
        "generated_at": now(),
        "users": {k: users.get(k, 0) for k in ("patient", "specialist", "admin")},
        "uploads": {
            "total": total_uploads,
            "graded": graded,
            "declined_not_fundus": uploads.get("not_a_fundus_photograph", 0),
            "declined_no_retina": uploads.get("no_retina_detected", 0),
            "framing_warning": framing,
            "poor_quality": poor_quality,
            "referable": referable,
            "grades": grades,
            "grade_names": GRADE_NAMES,
            "weekly": weekly,
        },
        "screenings": {"saved": saved, "review_pending": pending,
                       "reviewed": len(reviewed), "agreed": agreed,
                       "referral_agreed": refer_agree, "table": table},
        "appointments": {k: appts.get(k, 0) for k in
                         ("requested", "confirmed", "declined", "completed", "cancelled")},
        "assistant": {k: assistant.get(k, 0) for k in
                      ("answered", "urgent", "refused", "out_of_scope", "blocked",
                       "error")},
    }


@router.get("/users")
def users(request: Request, _: dict = Depends(admin_only)) -> list[dict]:
    with _db(request).connect() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT u.*, sp.clinic AS clinic FROM users u LEFT JOIN specialists sp "
            "ON sp.user_id = u.id ORDER BY u.role, u.name")]
    return [public_user(r) | {"clinic": r["clinic"]} for r in rows]


class NewSpecialist(BaseModel):
    name: str
    email: str
    password: str
    clinic: str
    city: str
    area: str = ""
    specialties: list[str] = ["Ophthalmologist"]
    services: list[str] = []
    days: str = "Mon–Fri"
    languages: list[str] = ["Urdu", "English"]


@router.post("/specialists")
def create_specialist(body: NewSpecialist, request: Request,
                      _: dict = Depends(admin_only)) -> dict:
    email = body.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "enter a valid email address")
    problem = password_problem(body.password)
    if problem:
        raise HTTPException(400, problem)
    if not body.name.strip() or not body.clinic.strip() or not body.city.strip():
        raise HTTPException(400, "name, clinic and city are required")
    with _db(request).connect() as c:
        if c.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            raise HTTPException(409, "an account with this email already exists")
        uid = c.execute(
            "INSERT INTO users (email, name, role, password_hash, city, phone, active, "
            "created_at) VALUES (?, ?, 'specialist', ?, ?, '', 1, ?)",
            (email, body.name.strip(), hash_password(body.password), body.city.strip(),
             now())).lastrowid
        n = _count(c, "SELECT COUNT(*) FROM specialists") + 1
        sid = f"c{n:03d}"
        while c.execute("SELECT 1 FROM specialists WHERE id = ?", (sid,)).fetchone():
            n += 1
            sid = f"c{n:03d}"
        c.execute(
            "INSERT INTO specialists (id, user_id, clinic, lead, specialties, city, area, "
            "services, days, languages, demo) VALUES (?,?,?,?,?,?,?,?,?,?,0)",
            (sid, uid, body.clinic.strip(), body.name.strip(), json.dumps(body.specialties),
             body.city.strip(), body.area.strip(), json.dumps(body.services),
             body.days.strip(), json.dumps(body.languages)))
        u = row(c.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone())
    return public_user(u) | {"clinic": body.clinic.strip()}


class UserUpdate(BaseModel):
    active: bool


@router.patch("/users/{uid}")
def update_user(uid: int, body: UserUpdate, request: Request,
                admin: dict = Depends(admin_only)) -> dict:
    if uid == admin["id"] and not body.active:
        raise HTTPException(400, "you cannot switch off your own account")
    with _db(request).connect() as c:
        if not c.execute("UPDATE users SET active = ? WHERE id = ?",
                         (int(body.active), uid)).rowcount:
            raise HTTPException(404, "no such user")
        if not body.active:
            c.execute("DELETE FROM sessions WHERE user_id = ?", (uid,))
        u = row(c.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone())
    return public_user(u)

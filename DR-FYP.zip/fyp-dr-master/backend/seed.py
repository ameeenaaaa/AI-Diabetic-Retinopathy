"""Demo accounts and the demo specialist directory, created on first start (DECISION-078).

Runs automatically when the database has no users (switch off with FYP_SEED_DEMO=0), or by
hand:

    python -m backend.seed            # add whatever is missing
    python -m backend.seed --list     # print the demo logins

THE DEMO PASSWORDS ARE PUBLIC — they are printed here and in the README so the panel can
sign in as each role. This is a local demonstration, not a deployment; change or remove
these accounts before anyone else can reach the server.

Every clinic is invented (see demo_specialists.json) and has no real contact details.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from backend.db import Database, now
from backend.security import hash_password

HERE = Path(__file__).resolve().parent

DEMO_ADMIN = ("admin@demo.pk", "Admin@1234", "Programme administrator")
DEMO_PATIENT = ("patient@demo.pk", "Patient@1234", "Demo Patient", "Islamabad")
SPECIALIST_PASSWORD = "Doctor@1234"


def specialist_email(sid: str) -> str:
    return f"{sid}@clinic.demo.pk"          # s01@clinic.demo.pk ... s10@clinic.demo.pk


def demo_logins() -> list[tuple[str, str, str]]:
    rows = [("admin", DEMO_ADMIN[0], DEMO_ADMIN[1]),
            ("patient", DEMO_PATIENT[0], DEMO_PATIENT[1])]
    for s in json.loads((HERE / "demo_specialists.json").read_text(encoding="utf-8")):
        rows.append((f"specialist ({s['clinic']}, {s['city']})",
                     specialist_email(s["id"]), SPECIALIST_PASSWORD))
    return rows


def _user(c, email, name, role, password, city="", phone="") -> int:
    r = c.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if r:
        return r["id"]
    cur = c.execute(
        "INSERT INTO users (email, name, role, password_hash, city, phone, active, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
        (email, name, role, hash_password(password), city, phone, now()))
    return cur.lastrowid


def seed(db: Database) -> None:
    clinics = json.loads((HERE / "demo_specialists.json").read_text(encoding="utf-8"))
    with db.connect() as c:
        _user(c, DEMO_ADMIN[0], DEMO_ADMIN[2], "admin", DEMO_ADMIN[1])
        _user(c, DEMO_PATIENT[0], DEMO_PATIENT[2], "patient", DEMO_PATIENT[1],
              city=DEMO_PATIENT[3])
        for s in clinics:
            uid = _user(c, specialist_email(s["id"]), s["lead"], "specialist",
                        SPECIALIST_PASSWORD, city=s["city"])
            c.execute(
                "INSERT OR IGNORE INTO specialists (id, user_id, clinic, lead, specialties, "
                "city, area, services, days, languages, demo) VALUES (?,?,?,?,?,?,?,?,?,?,1)",
                (s["id"], uid, s["clinic"], s["lead"], json.dumps(s["specialties"]),
                 s["city"], s["area"], json.dumps(s["services"]), s["days"],
                 json.dumps(s["languages"])))


def seed_if_empty(db: Database) -> bool:
    with db.connect() as c:
        empty = c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
    if empty:
        seed(db)
    return empty


def main() -> int:
    from backend.config import Settings

    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true", help="print the demo logins only")
    args = ap.parse_args()
    if not args.list:
        seed(Database(Settings.from_env().db_path))
        print("Demo data is in place.")
    print("\nDemo logins (local demonstration only):")
    for role, email, pw in demo_logins():
        print(f"  {role:<55} {email:<28} {pw}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

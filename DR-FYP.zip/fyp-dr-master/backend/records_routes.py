"""Saved screenings, the specialist directory, appointment requests, and specialist review.

WHO SEES WHAT.

    patient     their own screenings and appointments, nothing else
    specialist  screenings a patient asked to have reviewed (the shared review queue),
                and screenings attached to appointment requests sent to their clinic
    admin       counts only (admin_routes.py); no access to individual screenings here

THE MODEL'S ANSWER IS NEVER EDITED. A specialist review is stored beside the result —
agree, or a different grade and referral decision, with a note — and both are shown. A
review that silently replaced the model's grade would make every later comparison between
model and clinician impossible, and that comparison is the point of collecting reviews.
"""

from __future__ import annotations

import json
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from backend.db import Database, loads, now, row
from backend.security import current_user, require
from src.inference.predictor import GRADE_NAMES

router = APIRouter(tags=["records"])

Eye = Literal["left", "right", "unspecified"]
Slot = Literal["morning", "afternoon", "evening"]
PENDING_TTL_HOURS = 24


def _db(request: Request) -> Database:
    return request.app.state.db


# ------------------------------------------------------------------ shaping
def specialist_out(s: dict) -> dict:
    return {
        "id": s["id"], "clinic": s["clinic"], "lead": s["lead"],
        "specialties": loads(s["specialties"]), "city": s["city"], "area": s["area"],
        "services": loads(s["services"]), "days": s["days"],
        "languages": loads(s["languages"]), "demo": bool(s["demo"]),
        "bookable": s.get("user_id") is not None,
    }


def screening_out(s: dict, *, include_overlay: bool = True, patient: dict | None = None,
                  reviewer_name: str | None = None) -> dict:
    result = loads(s["result_json"])
    if not include_overlay:
        result.pop("overlay_png", None)
    review = {"status": s["review_status"]}
    if s["review_status"] == "reviewed":
        review |= {
            "agrees": bool(s["review_agrees"]),
            "grade": s["review_grade"],
            "grade_name": GRADE_NAMES[s["review_grade"]] if s["review_grade"] is not None
            else None,
            "refer": bool(s["review_refer"]),
            "note": s["review_note"] or "",
            "reviewer_name": reviewer_name or "",
            "reviewed_at": s["reviewed_at"],
        }
    out = {"id": s["id"], "createdAt": s["created_at"], "fileName": s["file_name"],
           "label": s["label"], "eye": s["eye"], "result": result,
           "meta": loads(s["meta_json"]), "review": review}
    if patient is not None:
        out["patient"] = {"name": patient["name"], "city": patient["city"]}
    return out


def appointment_out(a: dict) -> dict:
    return {"id": a["id"], "createdAt": a["created_at"], "updatedAt": a["updated_at"],
            "specialistId": a["specialist_id"], "specialistName": a["clinic"],
            "city": a["city"], "screeningId": a["screening_id"],
            "patientName": a["patient_name"], "phone": a["phone"],
            "preferredDate": a["preferred_date"], "slot": a["slot"], "notes": a["notes"],
            "status": a["status"], "specialistNote": a["specialist_note"]}


def _reviewer_name(c, uid) -> str | None:
    if uid is None:
        return None
    r = c.execute("SELECT name FROM users WHERE id = ?", (uid,)).fetchone()
    return r["name"] if r else None


def _my_clinic(c, user: dict) -> dict | None:
    return row(c.execute("SELECT * FROM specialists WHERE user_id = ?",
                         (user["id"],)).fetchone())


def can_view_screening(c, user: dict, s: dict) -> bool:
    if user["role"] == "patient":
        return s["patient_id"] == user["id"]
    if user["role"] == "specialist":
        if s["review_status"] in ("pending", "reviewed"):
            return True
        clinic = _my_clinic(c, user)
        return clinic is not None and c.execute(
            "SELECT 1 FROM appointments WHERE screening_id = ? AND specialist_id = ?",
            (s["id"], clinic["id"])).fetchone() is not None
    return False


# ------------------------------------------------------------------ pending results
def store_pending(db: Database, user_id: int, file_name: str, result: dict) -> str:
    """Keep a graded result server-side until the patient saves or abandons it."""
    rid = uuid.uuid4().hex
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=PENDING_TTL_HOURS)).isoformat(
        timespec="seconds")
    with db.connect() as c:
        c.execute("DELETE FROM pending_results WHERE created_at < ?", (cutoff,))
        c.execute("INSERT INTO pending_results VALUES (?, ?, ?, ?, ?)",
                  (rid, user_id, file_name[:200], json.dumps(result), now()))
    return rid


def load_pending(c, rid: str, user_id: int) -> dict | None:
    return row(c.execute("SELECT * FROM pending_results WHERE id = ? AND user_id = ?",
                         (rid, user_id)).fetchone())


# ------------------------------------------------------------------ directory
@router.get("/specialists")
def list_specialists(request: Request) -> list[dict]:
    with _db(request).connect() as c:
        rows = c.execute("SELECT * FROM specialists ORDER BY city, clinic").fetchall()
    return [specialist_out(dict(r)) for r in rows]


# ------------------------------------------------------------------ screenings
class SaveScreening(BaseModel):
    result_id: str
    eye: Eye = "unspecified"
    label: str = ""
    request_review: bool = False


@router.post("/screenings")
def save_screening(body: SaveScreening, request: Request,
                   user: dict = Depends(require("patient"))) -> dict:
    db = _db(request)
    meta = request.app.state.meta_snapshot()
    with db.connect() as c:
        p = load_pending(c, body.result_id, user["id"])
        if p is None:
            raise HTTPException(404, "this result is no longer available to save; "
                                     "screen the photograph again")
        r = loads(p["result_json"])
        sid = uuid.uuid4().hex
        c.execute(
            "INSERT INTO screenings (id, patient_id, created_at, file_name, label, eye, "
            "result_json, meta_json, grade, score, referable, guard_status, quality_status, "
            "review_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (sid, user["id"], p["created_at"], p["file_name"], body.label.strip()[:60],
             body.eye, p["result_json"], json.dumps(meta), r["grade"], r["score"],
             int(r["referable"]), r["guard"]["status"],
             (r.get("quality") or {}).get("status", "ok"),
             "pending" if body.request_review else "not_requested"))
        c.execute("DELETE FROM pending_results WHERE id = ?", (body.result_id,))
        s = row(c.execute("SELECT * FROM screenings WHERE id = ?", (sid,)).fetchone())
    return screening_out(s)


@router.get("/screenings")
def my_screenings(request: Request, user: dict = Depends(require("patient"))) -> list[dict]:
    with _db(request).connect() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT * FROM screenings WHERE patient_id = ? ORDER BY created_at DESC",
            (user["id"],)).fetchall()]
        return [screening_out(s, include_overlay=False,
                              reviewer_name=_reviewer_name(c, s["reviewer_id"]))
                for s in rows]


@router.get("/screenings/{sid}")
def get_screening(sid: str, request: Request, user: dict = Depends(current_user)) -> dict:
    with _db(request).connect() as c:
        s = row(c.execute("SELECT * FROM screenings WHERE id = ?", (sid,)).fetchone())
        if s is None or not can_view_screening(c, user, s):
            raise HTTPException(404, "this screening does not exist or is not yours to see")
        patient = None
        if user["role"] != "patient":
            patient = row(c.execute("SELECT name, city FROM users WHERE id = ?",
                                    (s["patient_id"],)).fetchone())
        return screening_out(s, patient=patient,
                             reviewer_name=_reviewer_name(c, s["reviewer_id"]))


@router.delete("/screenings/{sid}")
def delete_screening(sid: str, request: Request,
                     user: dict = Depends(require("patient"))) -> dict:
    with _db(request).connect() as c:
        n = c.execute("DELETE FROM screenings WHERE id = ? AND patient_id = ?",
                      (sid, user["id"])).rowcount
    if not n:
        raise HTTPException(404, "this screening does not exist or is not yours")
    return {"ok": True}


@router.post("/screenings/{sid}/request-review")
def request_review(sid: str, request: Request,
                   user: dict = Depends(require("patient"))) -> dict:
    with _db(request).connect() as c:
        s = row(c.execute("SELECT * FROM screenings WHERE id = ? AND patient_id = ?",
                          (sid, user["id"])).fetchone())
        if s is None:
            raise HTTPException(404, "this screening does not exist or is not yours")
        if s["review_status"] == "not_requested":
            c.execute("UPDATE screenings SET review_status = 'pending' WHERE id = ?", (sid,))
        s = row(c.execute("SELECT * FROM screenings WHERE id = ?", (sid,)).fetchone())
        return screening_out(s, reviewer_name=_reviewer_name(c, s["reviewer_id"]))


# ------------------------------------------------------------------ review (specialist)
@router.get("/reviews/queue")
def review_queue(request: Request, status: Literal["pending", "reviewed"] = "pending",
                 user: dict = Depends(require("specialist"))) -> list[dict]:
    with _db(request).connect() as c:
        where = "s.review_status = 'pending'" if status == "pending" else \
            "s.review_status = 'reviewed' AND s.reviewer_id = ?"
        args = () if status == "pending" else (user["id"],)
        rows = c.execute(
            f"SELECT s.*, u.name AS p_name, u.city AS p_city FROM screenings s "
            f"JOIN users u ON u.id = s.patient_id WHERE {where} "
            f"ORDER BY s.referable DESC, s.score DESC, s.created_at", args).fetchall()
        out = []
        for r in rows:
            s = dict(r)
            out.append(screening_out(s, include_overlay=False,
                                     patient={"name": s["p_name"], "city": s["p_city"]},
                                     reviewer_name=_reviewer_name(c, s["reviewer_id"])))
        return out


class Review(BaseModel):
    agrees: bool
    grade: int | None = None          # required when agrees is False
    refer: bool | None = None         # required when agrees is False
    note: str = ""


@router.post("/screenings/{sid}/review")
def review_screening(sid: str, body: Review, request: Request,
                     user: dict = Depends(require("specialist"))) -> dict:
    with _db(request).connect() as c:
        s = row(c.execute("SELECT * FROM screenings WHERE id = ?", (sid,)).fetchone())
        if s is None or not can_view_screening(c, user, s):
            raise HTTPException(404, "this screening is not in your review list")
        if body.agrees:
            grade, refer = s["grade"], bool(s["referable"])
        else:
            if body.grade is None or body.refer is None or not 0 <= body.grade <= 4:
                raise HTTPException(400, "give the grade (0-4) and referral decision you "
                                         "would record instead")
            grade, refer = body.grade, body.refer
            if grade == s["grade"] and refer == bool(s["referable"]):
                raise HTTPException(400, "that is the same as the model's answer; "
                                         "choose 'agree' instead")
        c.execute(
            "UPDATE screenings SET review_status='reviewed', reviewer_id=?, review_agrees=?, "
            "review_grade=?, review_refer=?, review_note=?, reviewed_at=? WHERE id=?",
            (user["id"], int(body.agrees), grade, int(refer), body.note.strip()[:1000],
             now(), sid))
        s = row(c.execute("SELECT * FROM screenings WHERE id = ?", (sid,)).fetchone())
        return screening_out(s, reviewer_name=user["name"])


# ------------------------------------------------------------------ appointments
class NewAppointment(BaseModel):
    specialist_id: str
    screening_id: str | None = None
    patient_name: str
    phone: str
    preferred_date: str               # yyyy-mm-dd
    slot: Slot
    notes: str = ""


APPT_SELECT = ("SELECT a.*, sp.clinic, sp.city FROM appointments a "
               "JOIN specialists sp ON sp.id = a.specialist_id ")


@router.post("/appointments")
def new_appointment(body: NewAppointment, request: Request,
                    user: dict = Depends(require("patient"))) -> dict:
    import re

    if not body.patient_name.strip():
        raise HTTPException(400, "enter the name the appointment is for")
    if not re.match(r"^[+\d][\d\s-]{6,}$", body.phone.strip()):
        raise HTTPException(400, "enter a phone number the clinic can call back on")
    try:
        d = date.fromisoformat(body.preferred_date)
    except ValueError as e:
        raise HTTPException(400, "choose a preferred date") from e
    if d < date.today():
        raise HTTPException(400, "the preferred date is in the past")
    with _db(request).connect() as c:
        sp = row(c.execute("SELECT * FROM specialists WHERE id = ?",
                           (body.specialist_id,)).fetchone())
        if sp is None:
            raise HTTPException(404, "that clinic is not in the directory")
        if sp["user_id"] is None:
            raise HTTPException(400, "this clinic does not take requests through the app")
        if body.screening_id and not c.execute(
                "SELECT 1 FROM screenings WHERE id = ? AND patient_id = ?",
                (body.screening_id, user["id"])).fetchone():
            raise HTTPException(400, "the attached screening is not one of yours")
        aid = uuid.uuid4().hex
        t = now()
        c.execute(
            "INSERT INTO appointments VALUES (?,?,?,?,?,?,?,?,?,'requested','',?,?)",
            (aid, user["id"], sp["id"], body.screening_id or None,
             body.patient_name.strip()[:80], body.phone.strip()[:30], d.isoformat(),
             body.slot, body.notes.strip()[:500], t, t))
        a = row(c.execute(APPT_SELECT + "WHERE a.id = ?", (aid,)).fetchone())
    return appointment_out(a)


@router.get("/appointments")
def list_appointments(request: Request, user: dict = Depends(current_user)) -> list[dict]:
    with _db(request).connect() as c:
        if user["role"] == "patient":
            rows = c.execute(APPT_SELECT + "WHERE a.patient_id = ? ORDER BY a.created_at DESC",
                             (user["id"],)).fetchall()
        elif user["role"] == "specialist":
            clinic = _my_clinic(c, user)
            if clinic is None:
                return []
            rows = c.execute(APPT_SELECT + "WHERE a.specialist_id = ? "
                             "ORDER BY a.preferred_date, a.created_at", (clinic["id"],)).fetchall()
        else:
            raise HTTPException(403, "appointments are for patient and specialist accounts")
    return [appointment_out(dict(r)) for r in rows]


class AppointmentUpdate(BaseModel):
    status: Literal["confirmed", "declined", "completed", "cancelled"]
    note: str = ""


# Which role may move an appointment from which status to which.
TRANSITIONS = {
    "patient": {"requested": {"cancelled"}, "confirmed": {"cancelled"}},
    "specialist": {"requested": {"confirmed", "declined"},
                   "confirmed": {"completed", "cancelled"}},
}


@router.patch("/appointments/{aid}")
def update_appointment(aid: str, body: AppointmentUpdate, request: Request,
                       user: dict = Depends(require("patient", "specialist"))) -> dict:
    with _db(request).connect() as c:
        a = row(c.execute(APPT_SELECT + "WHERE a.id = ?", (aid,)).fetchone())
        if a is None:
            raise HTTPException(404, "no such appointment")
        if user["role"] == "patient" and a["patient_id"] != user["id"]:
            raise HTTPException(404, "no such appointment")
        if user["role"] == "specialist":
            clinic = _my_clinic(c, user)
            if clinic is None or clinic["id"] != a["specialist_id"]:
                raise HTTPException(404, "no such appointment")
        allowed = TRANSITIONS[user["role"]].get(a["status"], set())
        if body.status not in allowed:
            raise HTTPException(400, f"a {a['status']} appointment cannot be marked "
                                     f"{body.status} from a {user['role']} account")
        note = body.note.strip()[:500] if user["role"] == "specialist" else a["specialist_note"]
        c.execute("UPDATE appointments SET status = ?, specialist_note = ?, updated_at = ? "
                  "WHERE id = ?", (body.status, note, now(), aid))
        a = row(c.execute(APPT_SELECT + "WHERE a.id = ?", (aid,)).fetchone())
    return appointment_out(a)

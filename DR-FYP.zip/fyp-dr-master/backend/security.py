"""Passwords, sessions, and the role checks every protected route goes through.

Standard library only:

* **Passwords** — PBKDF2-HMAC-SHA256, 240,000 iterations, a random 16-byte salt per user,
  compared in constant time. Stored as `pbkdf2_sha256$<iterations>$<salt>$<hash>` so the
  iteration count can be raised later without invalidating existing accounts.
* **Sessions** — a random 32-byte token handed to the browser once; only its SHA-256 is
  stored, so a copy of the database cannot be replayed as a login. Sent back as
  `Authorization: Bearer <token>`. Logging out deletes the row.

Roles: `patient` (screens, saves, books, chats), `specialist` (reviews referred screenings,
answers appointment requests), `admin` (dashboard, accounts, directory). A route states the
roles it accepts with `require(...)`; there is no implicit "admin can do everything".
"""

from __future__ import annotations

import hashlib
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import Depends, HTTPException, Request

from backend.db import Database, now, row

ITERATIONS = 240_000
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ROLES = ("patient", "specialist", "admin")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_hex, hash_hex = stored.split("$")
    except ValueError:
        return False
    if algo != "pbkdf2_sha256":
        return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex),
                                 int(iters))
    return hmac.compare_digest(digest.hex(), hash_hex)


def password_problem(password: str) -> str | None:
    if len(password) < 8:
        return "the password must be at least 8 characters"
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "the password must contain at least one letter and one number"
    return None


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db: Database, user_id: int, hours: int) -> str:
    token = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(hours=hours)
    with db.connect() as c:
        c.execute("DELETE FROM sessions WHERE expires_at < ?", (now(),))
        c.execute("INSERT INTO sessions VALUES (?, ?, ?, ?)",
                  (_token_hash(token), user_id, now(), expires.isoformat(timespec="seconds")))
    return token


def end_session(db: Database, token: str) -> None:
    with db.connect() as c:
        c.execute("DELETE FROM sessions WHERE token_hash = ?", (_token_hash(token),))


def public_user(u: dict) -> dict:
    """The user as the browser may see it — never the password hash."""
    return {k: u[k] for k in ("id", "email", "name", "role", "city", "phone", "active",
                              "created_at")} | {"active": bool(u["active"])}


def _bearer(request: Request) -> str | None:
    h = request.headers.get("authorization", "")
    if h.lower().startswith("bearer "):
        return h[7:].strip() or None
    return None


def optional_user(request: Request) -> dict | None:
    token = _bearer(request)
    if not token:
        return None
    db: Database = request.app.state.db
    with db.connect() as c:
        u = row(c.execute(
            "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id "
            "WHERE s.token_hash = ? AND s.expires_at > ?", (_token_hash(token), now())
        ).fetchone())
    if u is None or not u["active"]:
        return None
    return u


def current_user(user: dict | None = Depends(optional_user)) -> dict:
    if user is None:
        raise HTTPException(status_code=401, detail="sign in to continue")
    return user


def require(*roles: str):
    """Dependency that admits only the given roles."""
    def check(user: dict = Depends(current_user)) -> dict:
        if user["role"] not in roles:
            raise HTTPException(status_code=403,
                                detail=f"this action is for {' or '.join(roles)} accounts")
        return user
    return check

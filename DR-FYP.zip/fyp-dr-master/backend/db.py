"""The application database: SQLite through the standard library (DECISION-078).

WHAT IS STORED, AND WHAT IS NOT. Accounts, saved screenings, appointment requests,
specialist reviews, and counters for the admin dashboard. A saved screening keeps the
model's result and the two images the page already shows — the 224 x 224 crop the model
graded and its Grad-CAM overlay. **The original upload is never stored**, and an unsaved
result is deleted after a day. Assistant conversations are not stored: the dashboard
counts outcomes (answered / urgent / refused / out of scope), never message text.

One connection per request (`connect()`), WAL mode so the dashboard can read while a
screening is being saved. No ORM: the schema is small and plain SQL is what the write-up
can show.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name          TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('patient', 'specialist', 'admin')),
    password_hash TEXT NOT NULL,
    city          TEXT NOT NULL DEFAULT '',
    phone         TEXT NOT NULL DEFAULT '',
    active        INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);

-- The specialist directory. `user_id` links a clinic to the specialist account that
-- answers its requests; a clinic without an account is listed but cannot be booked.
CREATE TABLE IF NOT EXISTS specialists (
    id          TEXT PRIMARY KEY,
    user_id     INTEGER UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    clinic      TEXT NOT NULL,
    lead        TEXT NOT NULL,
    specialties TEXT NOT NULL,        -- JSON list
    city        TEXT NOT NULL,
    area        TEXT NOT NULL,
    services    TEXT NOT NULL,        -- JSON list
    days        TEXT NOT NULL,
    languages   TEXT NOT NULL,        -- JSON list
    demo        INTEGER NOT NULL DEFAULT 1
);

-- A graded result waiting for the patient to decide whether to save it. Kept server-side
-- so a saved record is exactly what the model returned, not something a browser sent.
CREATE TABLE IF NOT EXISTS pending_results (
    id          TEXT PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    file_name   TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS screenings (
    id             TEXT PRIMARY KEY,
    patient_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at     TEXT NOT NULL,
    file_name      TEXT NOT NULL,
    label          TEXT NOT NULL DEFAULT '',
    eye            TEXT NOT NULL CHECK (eye IN ('left', 'right', 'unspecified')),
    result_json    TEXT NOT NULL,
    meta_json      TEXT NOT NULL,
    grade          INTEGER NOT NULL,
    score          REAL NOT NULL,
    referable      INTEGER NOT NULL,
    guard_status   TEXT NOT NULL,
    quality_status TEXT NOT NULL DEFAULT 'ok',
    -- specialist review (human in the loop). The model's own answer above is never
    -- overwritten; the review is stored beside it.
    review_status  TEXT NOT NULL DEFAULT 'not_requested'
                   CHECK (review_status IN ('not_requested', 'pending', 'reviewed')),
    reviewer_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    review_agrees  INTEGER,
    review_grade   INTEGER,
    review_refer   INTEGER,
    review_note    TEXT,
    reviewed_at    TEXT
);
CREATE INDEX IF NOT EXISTS screenings_patient ON screenings(patient_id, created_at);

CREATE TABLE IF NOT EXISTS appointments (
    id               TEXT PRIMARY KEY,
    patient_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    specialist_id    TEXT NOT NULL REFERENCES specialists(id),
    screening_id     TEXT REFERENCES screenings(id) ON DELETE SET NULL,
    patient_name     TEXT NOT NULL,
    phone            TEXT NOT NULL,
    preferred_date   TEXT NOT NULL,
    slot             TEXT NOT NULL CHECK (slot IN ('morning', 'afternoon', 'evening')),
    notes            TEXT NOT NULL DEFAULT '',
    status           TEXT NOT NULL CHECK (status IN
                     ('requested', 'confirmed', 'declined', 'completed', 'cancelled')),
    specialist_note  TEXT NOT NULL DEFAULT '',
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);

-- One row per /predict call: the outcome only, never the image. Feeds the monitoring
-- dashboard (how often uploads are declined, warned, or out of the training range).
CREATE TABLE IF NOT EXISTS predict_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at     TEXT NOT NULL,
    user_id        INTEGER,
    graded         INTEGER NOT NULL,
    guard_status   TEXT NOT NULL,
    quality_status TEXT,
    grade          INTEGER,
    referable      INTEGER
);

-- One row per assistant reply: the outcome only, never the message text.
CREATE TABLE IF NOT EXISTS assistant_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    user_id    INTEGER,
    provider   TEXT NOT NULL,
    outcome    TEXT NOT NULL,
    lang       TEXT NOT NULL
);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        if str(self.path) != ":memory:":
            self.path.parent.mkdir(parents=True, exist_ok=True)
        # A shared in-memory database for tests needs one connection kept open.
        self._keep = None
        if str(self.path) == ":memory:":
            import uuid
            self._uri = f"file:fyp_{uuid.uuid4().hex}?mode=memory&cache=shared"
            self._keep = sqlite3.connect(self._uri, uri=True, check_same_thread=False)
        else:
            self._uri = None
        with self.connect() as c:
            c.executescript(SCHEMA)

    def _open(self) -> sqlite3.Connection:
        if self._uri:
            conn = sqlite3.connect(self._uri, uri=True, check_same_thread=False)
        else:
            conn = sqlite3.connect(self.path, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    @contextmanager
    def connect(self):
        conn = self._open()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def row(r: sqlite3.Row | None) -> dict | None:
    return dict(r) if r is not None else None


def loads(s: str | None):
    return json.loads(s) if s else None

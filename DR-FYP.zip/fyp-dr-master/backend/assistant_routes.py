"""HTTP for the assistant. Everything that decides an answer is in backend/assistant/."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from backend.db import loads, now, row
from backend.records_routes import can_view_screening, load_pending, screening_out
from backend.security import current_user

router = APIRouter(prefix="/assistant", tags=["assistant"])


class Turn(BaseModel):
    role: Literal["user", "assistant"]
    text: str


class Chat(BaseModel):
    message: str
    result_id: str | None = None        # an unsaved result on the screening page
    screening_id: str | None = None     # a saved screening
    history: list[Turn] = []
    lang: Literal["en", "ur"] = "en"


@router.get("/status")
def status(request: Request) -> dict:
    a = request.app.state.assistant
    return {"provider": a.provider.name, "label": a.provider.label,
            "mode": "llm" if a.uses_llm else "offline",
            "passages": len(a.retriever.passages)}


@router.post("/chat")
def chat(body: Chat, request: Request, user: dict = Depends(current_user)) -> dict:
    if not body.message.strip():
        raise HTTPException(400, "type a question first")
    db = request.app.state.db
    result = review = None
    with db.connect() as c:
        if body.screening_id:
            s = row(c.execute("SELECT * FROM screenings WHERE id = ?",
                              (body.screening_id,)).fetchone())
            if s is None or not can_view_screening(c, user, s):
                raise HTTPException(404, "that screening is not available")
            shaped = screening_out(s, include_overlay=False)
            result, review = shaped["result"], shaped["review"]
        elif body.result_id:
            p = load_pending(c, body.result_id, user["id"])
            if p is not None:
                result = loads(p["result_json"])
        cities = [r["city"] for r in c.execute("SELECT DISTINCT city FROM specialists")]
    reply = request.app.state.assistant.answer(
        body.message, result=result, review=review,
        history=[t.model_dump() for t in body.history], lang=body.lang, cities=cities)
    with db.connect() as c:
        c.execute("INSERT INTO assistant_log (created_at, user_id, provider, outcome, lang) "
                  "VALUES (?, ?, ?, ?, ?)",
                  (now(), user["id"], request.app.state.assistant.provider.name,
                   reply.outcome, reply.lang))
    return reply.to_dict()

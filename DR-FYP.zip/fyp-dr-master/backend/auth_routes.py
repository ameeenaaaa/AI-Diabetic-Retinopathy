"""Sign up, sign in, sign out, and "who am I".

Only PATIENTS sign themselves up. Specialist and admin accounts are created by an admin
(`backend/admin_routes.py`) or by the demo seed, so nobody can make themselves a doctor.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from backend.db import Database, now, row
from backend.security import (EMAIL_RE, create_session, current_user, end_session,
                              hash_password, password_problem, public_user,
                              verify_password)

router = APIRouter(prefix="/auth", tags=["auth"])


class Register(BaseModel):
    name: str
    email: str
    password: str
    city: str = ""
    phone: str = ""


class Login(BaseModel):
    email: str
    password: str


def _db(request: Request) -> Database:
    return request.app.state.db


@router.post("/register")
def register(body: Register, request: Request) -> dict:
    name, email = body.name.strip(), body.email.strip().lower()
    if not name:
        raise HTTPException(400, "enter your name")
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "enter a valid email address")
    problem = password_problem(body.password)
    if problem:
        raise HTTPException(400, problem)
    db = _db(request)
    with db.connect() as c:
        if c.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            raise HTTPException(409, "an account with this email already exists")
        uid = c.execute(
            "INSERT INTO users (email, name, role, password_hash, city, phone, active, "
            "created_at) VALUES (?, ?, 'patient', ?, ?, ?, 1, ?)",
            (email, name[:80], hash_password(body.password), body.city.strip()[:60],
             body.phone.strip()[:30], now())).lastrowid
        u = row(c.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone())
    token = create_session(db, uid, request.app.state.settings.session_hours)
    return {"token": token, "user": public_user(u)}


@router.post("/login")
def login(body: Login, request: Request) -> dict:
    db = _db(request)
    with db.connect() as c:
        u = row(c.execute("SELECT * FROM users WHERE email = ?",
                          (body.email.strip().lower(),)).fetchone())
    # One message for both cases, so the form does not reveal which emails have accounts.
    if u is None or not verify_password(body.password, u["password_hash"]):
        raise HTTPException(401, "the email or password is wrong")
    if not u["active"]:
        raise HTTPException(403, "this account has been switched off by the administrator")
    token = create_session(db, u["id"], request.app.state.settings.session_hours)
    return {"token": token, "user": public_user(u)}


@router.post("/logout")
def logout(request: Request, user: dict = Depends(current_user)) -> dict:
    token = request.headers.get("authorization", "")[7:].strip()
    end_session(_db(request), token)
    return {"ok": True}


@router.get("/me")
def me(user: dict = Depends(current_user)) -> dict:
    return {"user": public_user(user)}

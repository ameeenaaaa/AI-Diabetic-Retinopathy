"""The assistant: one question in, one checked answer with its sources out (DECISION-078).

    question
       │
       ├─ guard.classify ── urgent / medicine / diagnosis ──► fixed reply (no model)
       │
       ├─ retrieval (BM25 over kb/, incl. "Also asked:" phrasings)
       │      weak or no match + model online -> model rephrases the SEARCH WORDS,
       │      search runs again under the same rules ── still nothing ─► "not in my sources"
       │
       ├─ language model words an answer from the passages + the patient's result
       │      (offline: the passages themselves are quoted instead)
       │
       ├─ guard.unsafe_reason ── diagnosis / reassurance / % / dose ─► safe fallback
       │
       └─ actions (find a specialist in <city>, download the report, ...)

"Result-aware": when the question is asked from a result page, the result itself goes to
the model as source [R] — the grade name, the referral answer, the guard and quality
messages verbatim, and any specialist review. The model is told to repeat those exactly
and never to re-grade or reconcile them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from backend.assistant import guard
from backend.assistant.providers import Provider, ProviderError
from backend.assistant.retrieval import Passage, Retriever

MAX_MESSAGE = 1000
MAX_TURNS = 6
WEAK_SCORE = 4.0     # below this best match, ask the model to rephrase the search (online only)

REWRITE = """You turn a patient's question into a short search query for a small library \
of passages about diabetic retinopathy, diabetic eye screening, and a screening app (its \
grade, referral, score, warnings, heatmap, reports, specialist review, appointments, \
history and privacy).
Output ONLY 4 to 12 plain English search words, using standard medical and app terms \
(for example: retinopathy, screening interval, eye drops, macular oedema, framing warning, \
image quality, heatmap, referral, accuracy, stored data).
Do not answer the question. Do not add facts.
If the question has nothing to do with eyes, diabetes, or this app, output exactly: NONE"""
RESULT_WORDS = re.compile(r"\b(my|this|the) (result|grade|score|screening|photo|image|"
                          r"report|heatmap|map|warning|referral)\b|\b(refer|referral|mild|"
                          r"moderate|severe|proliferative|no dr|not flagged|score|grade|"
                          r"warning|heatmap)\b|نتیجہ|گریڈ|اسکور|ریفر", re.I)

SYSTEM = """You are the help assistant inside a research prototype that estimates a diabetic \
retinopathy grade from one retinal photograph. You help patients understand diabetic \
retinopathy, eye screening, and their own result in this app.

Rules you must follow:
1. Use ONLY the numbered sources and the screening result [R] provided with the question. \
If they do not answer the question, say plainly that your sources do not cover it and \
suggest asking an eye specialist. Never add facts from your own knowledge.
2. Never diagnose. Never say the person has or does not have a disease, that their eyes are \
fine, healthy or normal, or that they do not need an eye examination.
3. Repeat the app's estimated grade and referral answer exactly as given in [R]. Never \
change them, never guess a different grade, and never pick one over the other: the grade \
and the referral are two separate answers read off the same score.
4. Never give a confidence, probability or percentage of certainty. The model does not \
produce one.
5. Never give advice about medicines or doses.
6. If the person describes a sudden change in their sight, tell them to get urgent eye \
care today.
7. Put the source label, such as [S1] or [R], after each sentence that uses it.
8. Write plainly for a patient: short sentences, everyday words, at most 120 words, no \
headings, no tables.
9. Reply in {language}."""

LANG_NAME = {"en": "English", "ur": "Urdu (in Urdu script)"}


@dataclass
class Reply:
    answer: str
    outcome: str                # answered | urgent | refused | out_of_scope | blocked | error
    lang: str
    mode: str                   # llm | offline | fixed
    provider: str
    sources: list[dict] = field(default_factory=list)
    cited: list[str] = field(default_factory=list)
    actions: list[dict] = field(default_factory=list)
    note: str = ""
    searched_as: str = ""       # the model's rephrased search words, when they were used

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def result_summary(result: dict | None, review: dict | None = None) -> str | None:
    """The patient's result as plain sentences: the [R] source."""
    if not result:
        return None
    if not result.get("graded"):
        return ("No grade was produced for this upload. The app said: "
                f"{result['guard']['message']}")
    lines = [
        f"Estimated grade: {result['grade_name']} (grade {result['grade']} on the 0 to 4 "
        "scale).",
        f"Score: {result['score']:.2f}. Grade cut points: "
        f"{', '.join(f'{c:.3f}' for c in result['cuts'])}.",
        ("Referral answer: Refer. The score is at or above the referral threshold "
         f"{result['referral_threshold']:.3f}.") if result["referable"] else
        ("Referral answer: Not flagged. The score is below the referral threshold "
         f"{result['referral_threshold']:.3f}."),
        f"Framing check: {result['guard']['message']}",
    ]
    q = result.get("quality")
    if q:
        lines.append(f"Image quality check: {q['message']}")
    if review and review.get("status") == "reviewed":
        if review.get("agrees"):
            lines.append("Specialist review: an eye specialist reviewed this result and "
                         "agreed with the app's answers.")
        else:
            lines.append(f"Specialist review: an eye specialist reviewed this result and "
                         f"recorded grade {review.get('grade_name')} with referral "
                         f"{'Refer' if review.get('refer') else 'Not flagged'}.")
        if review.get("note"):
            lines.append(f"Specialist's note: {review['note']}")
    elif review and review.get("status") == "pending":
        lines.append("Specialist review: requested and waiting for a specialist.")
    return " ".join(lines)


def find_actions(text: str, cities: list[str], has_result: bool) -> list[dict]:
    t = text.lower()
    actions = []
    if re.search(r"\b(specialist|doctor|clinic|appointment|book|ophthalmologist|hospital|"
                 r"eye ?care)\b|ڈاکٹر|اپوائنٹمنٹ|کلینک|ماہر", t):
        city = next((c for c in cities if c.lower() in t), None)
        actions.append({"type": "find_specialist", "city": city})
    if has_result and re.search(r"\b(pdf|report|download|print)\b|رپورٹ", t):
        actions.append({"type": "download_report"})
    if re.search(r"\b(upload|screen again|new screening|retake|another (photo|image|picture))"
                 r"\b|نئی اسکریننگ|دوبارہ", t):
        actions.append({"type": "new_screening"})
    if re.search(r"\b(history|previous|over time|progress|compare|last (time|screening))\b|"
                 r"پچھلی|ریکارڈ", t):
        actions.append({"type": "open_records"})
    return actions


class Assistant:
    def __init__(self, provider: Provider, retriever: Retriever | None = None,
                 missed_pct: int = 26) -> None:
        self.provider = provider
        self.retriever = retriever or Retriever()
        self.by_id = {p.id: p for p in self.retriever.passages}
        self.missed_pct = missed_pct

    @property
    def uses_llm(self) -> bool:
        return self.provider.name != "offline" and self.provider.available()

    # ---------------------------------------------------------------- helpers
    def _sources(self, passages: list[Passage]) -> list[dict]:
        return [{"id": f"S{i}", "title": p.doc_title, "heading": p.heading,
                 "source": p.source, "url": p.url, "kind": p.kind, "passage": p.id}
                for i, p in enumerate(passages, 1)]

    def _fixed(self, text, outcome, lang, pids=(), with_result=False, actions=()) -> Reply:
        passages = [self.by_id[p] for p in pids if p in self.by_id]
        src = self._sources(passages)
        if with_result:
            src.append({"id": "R", "title": "Your screening result", "heading": "",
                        "source": "This app", "url": "", "kind": "result", "passage": ""})
        return Reply(text, outcome, lang, "fixed", self.provider.label, src,
                     guard.cited_ids(text), list(actions))

    def _translate_query(self, text: str) -> str:
        try:
            return self.provider.generate(
                "Translate the user's message into English. Output only the translation, "
                "nothing else.", [], text)
        except ProviderError:
            return text

    def find_passages(self, query: str, about_result: bool = False) -> tuple[list[Passage], str]:
        """Passages for a question, and the rephrased search words if they were used.

        The search matches words. When it finds nothing, or only a weak match, the
        language model REPHRASES THE QUESTION AS SEARCH WORDS and the search runs again
        under the same rules. The rephrasing is never shown as an answer and adds no
        facts: the answer still comes only from the passages found.
        """
        scored = self.retriever.search(query, k=4)
        searched_as = ""
        if self.uses_llm and (not scored or scored[0][0] < WEAK_SCORE):
            words = self._rewrite_query(query)
            if words and words.strip().upper() != "NONE":
                more = self.retriever.search(
                    words + (" grade referral score" if about_result else ""), k=4)
                if more:
                    searched_as = words
                    best: dict[str, tuple[float, Passage]] = {}
                    for sc, p in scored + more:
                        if p.id not in best or sc > best[p.id][0]:
                            best[p.id] = (sc, p)
                    scored = sorted(best.values(), key=lambda x: -x[0])[:4]
        return [p for _, p in scored], searched_as

    def _rewrite_query(self, text: str) -> str:
        try:
            out = self.provider.generate(REWRITE, [], text)
        except ProviderError:
            return ""
        return " ".join(out.split())[:200]

    def _extractive(self, passages, summary, about_result) -> str:
        parts = []
        if summary and about_result:
            parts.append(f"About your result: {summary} [R]")
        for i, p in enumerate(passages[:2], 1):
            parts.append(f"{p.text} [S{i}]")
        return "\n\n".join(parts)

    # ---------------------------------------------------------------- main
    def answer(self, message: str, *, result: dict | None = None,
               review: dict | None = None, history: list[dict] | None = None,
               lang: str = "en", cities: list[str] | None = None) -> Reply:
        msg = " ".join(message.split())[:MAX_MESSAGE]
        lang = guard.detect_lang(msg, lang)
        cities = cities or []
        summary = result_summary(result, review)
        actions = find_actions(msg, cities, result is not None)

        kind = guard.classify(msg)
        if kind == "urgent":
            return self._fixed(guard.URGENT_REPLY[lang], "urgent", lang, ["dr_symptoms#3"])
        if kind == "medication":
            return self._fixed(guard.MEDICATION_REPLY[lang], "refused", lang,
                               ["treatment#3", "treatment#2"])
        if kind == "diagnosis":
            graded = result if result and result.get("graded") else None
            pids = ["app_how_it_works#1"] + ([] if graded is None or graded["referable"]
                                             else ["app_how_it_works#5"])
            return self._fixed(guard.diagnosis_reply(graded, self.missed_pct, lang),
                               "refused", lang, pids, with_result=graded is not None,
                               actions=actions)

        query = msg
        if lang == "ur" and self.uses_llm:
            query = self._translate_query(msg)
        about_result = bool(summary) and bool(RESULT_WORDS.search(msg) or
                                              RESULT_WORDS.search(query))
        if about_result:
            query = f"{query} grade referral score"
        hits, searched_as = self.find_passages(query, about_result)

        if not hits and not about_result:
            return self._fixed(guard.OUT_OF_SCOPE_REPLY[lang], "out_of_scope", lang,
                               actions=actions)

        sources = self._sources(hits)
        if summary:
            sources.append({"id": "R", "title": "Your screening result", "heading": "",
                            "source": "This app", "url": "", "kind": "result",
                            "passage": ""})

        # -- offline: quote the sources themselves
        if not self.uses_llm:
            text = self._extractive(hits, summary, about_result)
            if lang == "ur":
                text = guard.OFFLINE_URDU_REPLY + "\n\n" + text
            return Reply(text, "answered", lang, "offline", self.provider.label, sources,
                         guard.cited_ids(text), actions, searched_as=searched_as,
                         note="Offline mode: no language model is connected, so these are "
                              "the matching passages from the sources, quoted.")

        # -- language model
        block = "\n".join(f"[S{i}] ({p.doc_title} — {p.heading}) {p.text}"
                          for i, p in enumerate(hits, 1))
        if summary:
            block += f"\n[R] (The person's screening result in this app) {summary}"
        user = f"Sources:\n{block}\n\nQuestion: {msg}"
        turns = []
        for h in (history or [])[-MAX_TURNS:]:
            role = "assistant" if h.get("role") == "assistant" else "user"
            turns.append((role, str(h.get("text", ""))[:600]))
        try:
            draft = self.provider.generate(SYSTEM.format(language=LANG_NAME[lang]),
                                           turns, user)
        except ProviderError as e:
            text = self._extractive(hits, summary, about_result)
            return Reply(text, "error", lang, "offline", self.provider.label, sources,
                         guard.cited_ids(text), actions, searched_as=searched_as,
                         note=f"The language model could not be used ({e}); showing the "
                              "matching passages from the sources instead.")

        why = guard.unsafe_reason(draft)
        if why:
            return Reply(guard.BLOCKED_REPLY[lang], "blocked", lang, "fixed",
                         self.provider.label, sources, [], actions, searched_as=searched_as,
                         note=f"The model's draft was withheld because it {why}.")
        cited = guard.cited_ids(draft)
        known = {s["id"] for s in sources}
        cited = [c for c in cited if c in known]
        return Reply(draft, "answered", lang, "llm", self.provider.label, sources, cited,
                     actions, searched_as=searched_as)

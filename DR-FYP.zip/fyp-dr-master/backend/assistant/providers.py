"""The language model behind the assistant — swappable, and optional.

    gemini    Google Gemini API (free key from aistudio.google.com)        GEMINI_API_KEY
    groq      Groq API, OpenAI-compatible (free key from console.groq.com) GROQ_API_KEY
    ollama    a model running locally with Ollama (no key, works offline)
    offline   no language model: the assistant answers with the retrieved passages
              themselves, quoted and cited. Always available; used for tests.

The model is used ONLY to word an answer from passages the retriever chose. It never
decides whether a question is urgent, a medicine question, or a diagnosis question (that
is `guard.py`), and its draft is checked again before anyone sees it.

Standard library HTTP (urllib) only, so the assistant adds no dependency to install.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request

TIMEOUT_S = 20            # one request; a model that has not answered by then is skipped
TOTAL_BUDGET_S = 45       # all models together — a patient should not wait longer than this
RETRY_WAIT_S = 1.5        # one short wait before retrying a model that said "busy"


class ProviderError(RuntimeError):
    """`retryable` is True for "busy / try later" (HTTP 429, 500, 503) and for a model
    name the key cannot use (404), so the caller may try the next model in its list."""

    def __init__(self, message: str, retryable: bool = False) -> None:
        super().__init__(message)
        self.retryable = retryable


def _post(url: str, body: dict, headers: dict, timeout: float = TIMEOUT_S) -> dict:
    data = json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:300]
        if e.code in (401, 403):
            raise ProviderError(f"the API key was rejected (HTTP {e.code}). Check the key "
                                "in .env.") from e
        if e.code == 429:
            raise ProviderError("the free usage limit has been reached for now (HTTP 429). "
                                "Try again later, or switch ASSISTANT_PROVIDER.",
                                retryable=True) from e
        if e.code == 404:
            raise ProviderError(f"the model name was not found (HTTP 404): {detail}. "
                                "Run `python -m backend.assistant.check` to list models.",
                                retryable=True) from e
        if e.code in (500, 502, 503, 504):
            raise ProviderError(f"the model is busy or unavailable (HTTP {e.code})",
                                retryable=True) from e
        raise ProviderError(f"HTTP {e.code}: {detail}") from e
    except (TimeoutError, urllib.error.URLError, OSError) as e:
        timed_out = isinstance(e, TimeoutError) or "timed out" in str(e)
        raise ProviderError(f"no answer within {timeout:.0f} s" if timed_out
                            else f"could not reach the service: {e}",
                            retryable=timed_out) from e


def _get(url: str, headers: dict) -> dict:
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise ProviderError(f"HTTP {e.code}: {e.read().decode(errors='replace')[:300]}") from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ProviderError(f"could not reach the service: {e}") from e


class Provider:
    name = "offline"
    label = "Offline (no language model)"

    def available(self) -> bool:
        return self.name == "offline"

    def generate(self, system: str, turns: list[tuple[str, str]], user: str) -> str:
        """`turns` = earlier (role, text) pairs, role 'user' or 'assistant'."""
        raise ProviderError("the offline provider does not generate text")

    def list_models(self) -> list[str]:
        return []


class Gemini(Provider):
    name = "gemini"
    BASE = "https://generativelanguage.googleapis.com/v1beta"

    def __init__(self, key: str, model: str) -> None:
        # GEMINI_MODEL may list several models, comma-separated, tried in order. Free-tier
        # models are often "busy" (HTTP 503) at peak times, and Google retires model names
        # for new keys (HTTP 404); a list keeps the assistant working through both.
        self.key = key
        self.models = [m.strip() for m in model.split(",") if m.strip()] or ["gemini-flash-latest"]
        self.model = self.models[0]
        self.label = f"Gemini ({self.model})"
        self._no_thinking_level: set[str] = set()

    def available(self) -> bool:
        return bool(self.key)

    def generate(self, system, turns, user) -> str:
        """Try each configured model in order; a busy model gets one short retry."""
        errors = []
        deadline = time.monotonic() + TOTAL_BUDGET_S
        for model in self.models:
            for attempt in range(2):
                left = deadline - time.monotonic()
                if left < 3:
                    raise ProviderError("no Gemini model answered in time — "
                                        + "; ".join(errors or ["time budget used up"]))
                try:
                    text = self._generate(model, system, turns, user, min(TIMEOUT_S, left))
                    self.model, self.label = model, f"Gemini ({model})"
                    return text
                except ProviderError as e:
                    if not e.retryable:
                        raise
                    errors.append(f"{model}: {e}")
                    busy = "busy" in str(e) or "429" in str(e)
                    if attempt == 0 and busy:
                        time.sleep(RETRY_WAIT_S)
                        continue
                    break
        raise ProviderError("no configured Gemini model answered — " + "; ".join(errors))

    def _generate(self, model, system, turns, user, timeout: float = TIMEOUT_S) -> str:
        contents = [{"role": "model" if r == "assistant" else "user", "parts": [{"text": t}]}
                    for r, t in turns]
        contents.append({"role": "user", "parts": [{"text": user}]})
        config = {"temperature": 0.2, "maxOutputTokens": 2048}
        # Newer Flash models reason before answering, which is slow. Rewording four short
        # passages needs little of it, so ask for low effort. A model that does not accept
        # the setting answers HTTP 400; it is then remembered and asked without it.
        if model not in self._no_thinking_level:
            config["thinkingConfig"] = {"thinkingLevel": "low"}
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents,
                "generationConfig": config}
        try:
            out = _post(f"{self.BASE}/models/{model}:generateContent", body,
                        {"x-goog-api-key": self.key}, timeout)
        except ProviderError as e:
            if "thinkingConfig" in config and "400" in str(e) and "think" in str(e).lower():
                self._no_thinking_level.add(model)
                del config["thinkingConfig"]
                out = _post(f"{self.BASE}/models/{model}:generateContent", body,
                            {"x-goog-api-key": self.key}, timeout)
            else:
                raise
        try:
            cand = out["candidates"][0]
        except (KeyError, IndexError) as e:
            reason = out.get("promptFeedback", {}).get("blockReason", "no candidates")
            raise ProviderError(f"Gemini returned no answer ({reason})") from e
        parts = cand.get("content", {}).get("parts", [])
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        if not text.strip():
            raise ProviderError(f"Gemini returned an empty answer "
                                f"(finishReason={cand.get('finishReason')})")
        return text.strip()

    def list_models(self) -> list[str]:
        out = _get(f"{self.BASE}/models?pageSize=200", {"x-goog-api-key": self.key})
        return [m["name"].removeprefix("models/") for m in out.get("models", [])
                if "generateContent" in m.get("supportedGenerationMethods", [])]


class OpenAICompatible(Provider):
    def __init__(self, name: str, base: str, key: str, model: str) -> None:
        self.name, self.base, self.key, self.model = name, base.rstrip("/"), key, model
        self.label = f"{name.capitalize()} ({model})"

    def available(self) -> bool:
        return bool(self.key)

    def generate(self, system, turns, user) -> str:
        msgs = [{"role": "system", "content": system}]
        msgs += [{"role": r, "content": t} for r, t in turns]
        msgs.append({"role": "user", "content": user})
        out = _post(f"{self.base}/chat/completions",
                    {"model": self.model, "messages": msgs, "temperature": 0.2,
                     "max_tokens": 700},
                    {"Authorization": f"Bearer {self.key}"})
        try:
            text = out["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError) as e:
            raise ProviderError("the service returned no answer") from e
        if not text.strip():
            raise ProviderError("the service returned an empty answer")
        return text.strip()

    def list_models(self) -> list[str]:
        out = _get(f"{self.base}/models", {"Authorization": f"Bearer {self.key}"})
        return sorted(m["id"] for m in out.get("data", []))


class Ollama(Provider):
    name = "ollama"

    def __init__(self, url: str, model: str) -> None:
        self.url, self.model = url.rstrip("/"), model
        self.label = f"Ollama ({model}, on this computer)"

    def available(self) -> bool:
        return True       # reachability is checked on first use; errors are reported then

    def generate(self, system, turns, user) -> str:
        msgs = [{"role": "system", "content": system}]
        msgs += [{"role": r, "content": t} for r, t in turns]
        msgs.append({"role": "user", "content": user})
        out = _post(f"{self.url}/api/chat",
                    {"model": self.model, "messages": msgs, "stream": False,
                     "options": {"temperature": 0.2}}, {})
        text = (out.get("message") or {}).get("content", "")
        if not text.strip():
            raise ProviderError("Ollama returned an empty answer")
        return text.strip()

    def list_models(self) -> list[str]:
        return [m["name"] for m in _get(f"{self.url}/api/tags", {}).get("models", [])]


def make_provider(settings) -> Provider:
    p = settings.assistant_provider
    if p == "gemini":
        return Gemini(settings.gemini_api_key, settings.gemini_model)
    if p == "groq":
        return OpenAICompatible("groq", "https://api.groq.com/openai/v1",
                                settings.groq_api_key, settings.groq_model)
    if p == "ollama":
        return Ollama(settings.ollama_url, settings.ollama_model)
    return Provider()

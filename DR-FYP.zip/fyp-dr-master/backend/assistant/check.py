"""Check the assistant's language-model connection before a demo.

    python -m backend.assistant.check

Prints which provider is configured, lists the models your key can use, and sends one
test question. If the configured model name is not in the list, copy one that is into
GEMINI_MODEL / GROQ_MODEL in .env.
"""

from __future__ import annotations

from backend.assistant.engine import Assistant
from backend.assistant.providers import ProviderError, make_provider
from backend.config import Settings


def main() -> int:
    s = Settings.from_env()
    p = make_provider(s)
    print(f"Provider: {p.label}")
    if getattr(p, "models", None) and len(p.models) > 1:
        print(f"Models tried in order: {', '.join(p.models)}")
    if p.name == "offline":
        print("No language model is configured, so the assistant runs in offline mode "
              "(it quotes its sources). Put GEMINI_API_KEY=... in .env to use Gemini.")
        return 0
    if not p.available():
        print("The key for this provider is missing in .env.")
        return 1
    try:
        models = p.list_models()
        print(f"Models available to you ({len(models)}):")
        for m in models[:40]:
            print(f"  {m}")
    except ProviderError as e:
        print(f"Could not list models: {e}")
    print("\nTest question: 'What happens at a diabetic eye screening appointment?'")
    print("(this can take up to 45 seconds while busy models are skipped)", flush=True)
    r = Assistant(p).answer("What happens at a diabetic eye screening appointment?")
    print(f"Outcome: {r.outcome} ({r.mode}){' — answered by ' + p.label if r.mode == 'llm' else ''}")
    if r.note:
        print(f"Note: {r.note}")
    print(f"Answer:\n{r.answer}")
    return 0 if r.mode == "llm" else 1


if __name__ == "__main__":
    raise SystemExit(main())

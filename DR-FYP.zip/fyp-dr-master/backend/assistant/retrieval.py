"""Retrieval for the assistant: BM25 over the passages in `kb/`.

WHY BM25 AND NOT EMBEDDINGS. The knowledge base is ~40 short passages in plain English.
A lexical ranker is enough at that size, needs no model download and no API key, runs in
microseconds, and — the reason that matters for a thesis — its scores are explainable: a
passage is retrieved because it shares rare words with the question, and the evaluation
can show exactly which words. An embedding model would be a second black box beside the
grading model.

The retriever also decides "out of scope": if no passage scores above `MIN_SCORE`, the
assistant says it has nothing in its sources rather than letting the language model
answer from its own memory.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

KB_DIR = Path(__file__).resolve().parent / "kb"
K1, B = 1.5, 0.75
MIN_SCORE = 2.0      # below this, the question is treated as not covered by the sources

STOP = set("""a an and are as at be been but by can could do does did for from had has
have how i if in into is it its me my of on or our should so than that the their them
then there these they this to too us was we were what when where which who why will with
would you your yours am also about any all just more most much not no very get got
best good better worse work works thing things buy need want like use know tell please
help way make one some many lot really right now new say says said give
""".split())

# A few spellings and synonyms that patients use and the sources do not.
SYNONYMS = {
    "dr": "retinopathy", "retinopathy": "retinopathy", "eyes": "eye", "sight": "vision",
    "seeing": "vision", "see": "vision", "blurry": "blurred", "blur": "blurred",
    "sugar": "glucose", "glucose": "glucose", "hba1c": "hba1c", "a1c": "hba1c",
    "doctor": "specialist", "doctors": "specialist", "ophthalmologist": "specialist",
    "specialists": "specialist", "appointment": "appointment", "appointments": "appointment",
    "book": "appointment", "booking": "appointment", "heatmap": "heatmap", "heat": "heatmap",
    "gradcam": "heatmap", "grad": "heatmap", "cam": "heatmap", "colours": "heatmap",
    "colors": "heatmap", "refer": "referral", "referred": "referral", "referable": "referral",
    "flagged": "flagged", "injection": "injections", "injections": "injections",
    "laser": "laser", "oedema": "oedema", "edema": "oedema", "swelling": "oedema",
    "macula": "macula", "macular": "macula", "photo": "photograph", "picture": "photograph",
    "image": "photograph", "images": "photograph", "photos": "photograph",
    "pictures": "photograph", "upload": "photograph", "blurred": "blurred",
    "stored": "stored", "store": "stored", "save": "stored", "saved": "stored",
    "privacy": "stored", "data": "stored", "accurate": "performance",
    "accuracy": "performance", "reliable": "performance", "trust": "performance",
    "sensitivity": "performance", "kappa": "performance", "miss": "performance",
    "missed": "performance", "performs": "performance", "perform": "performance",
    "well": "performance", "wrong": "performance", "mistake": "performance",
    "stages": "stage", "stage": "stage", "grades": "grade", "grading": "grade",
    "often": "interval", "frequency": "interval", "yearly": "interval",
    "annual": "interval", "annually": "interval", "prevent": "risk", "prevention": "risk",
    "lower": "risk", "reduce": "risk", "avoid": "risk",
}


def tokens(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    out = []
    for w in words:
        if w in STOP or len(w) < 2:
            continue
        w = SYNONYMS.get(w, w)
        # light stemming: plural and -ing/-ed endings
        for suf in ("ing", "ed", "es", "s"):
            if len(w) > 5 and w.endswith(suf) and w not in SYNONYMS.values():
                w = w[: -len(suf)]
                break
        out.append(w)
    return out


@dataclass(frozen=True)
class Passage:
    id: str               # e.g. "dr_symptoms#2"
    doc_title: str
    heading: str
    text: str
    source: str
    url: str
    kind: str             # health | app
    aliases: str = ""     # "Also asked:" phrasings — searched, never shown or quoted


def load_passages(kb_dir: Path = KB_DIR) -> list[Passage]:
    passages = []
    for path in sorted(kb_dir.glob("*.md")):
        if path.name.lower() == "readme.md":
            continue
        raw = path.read_text(encoding="utf-8")
        head, _, body = raw.partition("\n---\n")
        meta = {}
        for line in head.splitlines():
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
        for key in ("title", "source", "url", "kind"):
            if key not in meta:
                raise ValueError(f"{path.name} is missing '{key}:' in its header")
        sections = re.split(r"^## +", body, flags=re.M)
        n = 0
        for sec in sections:
            sec = sec.strip()
            if not sec:
                continue
            heading, _, text = sec.partition("\n")
            # "Also asked:" lines are other ways patients phrase the same question. They
            # help the search find the passage and are never shown or sent as source text.
            body, aliases = [], []
            for line in text.splitlines():
                if line.strip().lower().startswith("also asked:"):
                    aliases.append(line.split(":", 1)[1].strip())
                else:
                    body.append(line)
            n += 1
            passages.append(Passage(f"{path.stem}#{n}", meta["title"], heading.strip(),
                                    " ".join(" ".join(body).split()), meta["source"],
                                    meta["url"], meta["kind"], " ".join(aliases)))
    if not passages:
        raise ValueError(f"no passages found in {kb_dir}")
    return passages


class Retriever:
    def __init__(self, passages: list[Passage] | None = None) -> None:
        self.passages = passages if passages is not None else load_passages()
        # Headings count twice: they are the most specific words in a passage.
        self.docs = [Counter(tokens(f"{p.heading} {p.heading} {p.text} {p.aliases}"))
                     for p in self.passages]
        self.lens = [sum(d.values()) for d in self.docs]
        self.avg = sum(self.lens) / len(self.lens)
        df = Counter()
        for d in self.docs:
            df.update(d.keys())
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    def score(self, query: str) -> list[tuple[float, Passage]]:
        q = tokens(query)
        out = []
        for d, length, p in zip(self.docs, self.lens, self.passages):
            s = 0.0
            for t in q:
                f = d.get(t, 0)
                if f:
                    s += self.idf[t] * f * (K1 + 1) / (f + K1 * (1 - B + B * length / self.avg))
            out.append((s, p))
        out.sort(key=lambda x: -x[0])
        return out

    def search(self, query: str, k: int = 4) -> list[tuple[float, Passage]]:
        """Top-k passages above MIN_SCORE (possibly none).

        A passage must also share at least two distinct words with the question, or one
        rare word (idf >= 2.5), or score strongly on one word (>= 5). One common word in common ("screening", "eye") is how an
        off-topic question would otherwise be answered from a loosely related passage.
        """
        q = set(tokens(query))
        out = []
        for s, p in self.score(query)[:k]:
            if s < MIN_SCORE:
                continue
            shared = q & set(self.docs[self.passages.index(p)])
            if len(shared) >= 2 or s >= 5.0 or any(self.idf[t] >= 2.5 for t in shared):
                out.append((s, p))
        return out

title: The Grad-CAM heatmap in this app
source: Project documentation (this app)
url: /about
kind: app
---
## What the heatmap shows
The Grad-CAM view colours the regions of the graded image that most moved the score. Warmer colours mean a larger effect on the score in that region.
Also asked: what are the colours on my image; coloured map on the picture; red and yellow areas; Grad-CAM view

## What the heatmap does not show
The map is computed on a coarse grid (7 by 7) and enlarged, so it shows broad regions only. It cannot point to individual lesions such as microaneurysms. It shows where the model's attention and the score's sensitivity coincide; it is not proof that a region caused the result, and it is not a map of where disease is.
Also asked: does red mean disease; does the map show where the damage is

## Heat outside the retina
Sometimes the map puts heat in the black border outside the retina. The project measured this across many images and found the model gives more weight to the border than it should, partly an edge effect of the photograph. When the map is mostly outside the retina it should not be read as showing anything about the eye.
Also asked: colour in the black corners; heatmap outside the eye

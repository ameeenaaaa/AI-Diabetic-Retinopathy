title: Warnings and declined uploads in this app
source: Project documentation (this app)
url: /about
kind: app
---
## Not a usable retinal photograph
Before grading, the app checks that the upload looks like a fundus photograph: a round, warm-coloured image of the retina on a dark background. Photos of other things, screenshots, very dark or washed-out images and tightly cropped images are declined with no grade. Upload the full round retinal photograph from a fundus camera.
Also asked: why was my image refused; why did my photo get no grade; it said not a usable photograph; wrong kind of picture

## No retina detected
If almost no illuminated area is found, the image is treated as having no retina and nothing is graded.
Also asked: it says no retina; black image no result

## Framing warning
The retina should fill a similar share of the photograph as in the training images (about 61% to 82%). If it fills much less or much more, the app still gives a grade but shows a framing warning, because the model is known to depend on framing. Treat that grade as less dependable and consider retaking the photograph.
Also asked: eye cut off in the photo; image too zoomed in or too zoomed out; what is the framing warning; retina too small in the picture

## Image quality warning
If the photograph is blurred, too dark, over-exposed or low in contrast, the app still gives a grade but warns that the capture quality is low. Retaking the photograph and uploading it again is recommended. Images sent through messaging apps are often compressed and can trigger this warning.
Also asked: my photo is blurry; picture is fuzzy or dark; low quality warning; out of focus image; WhatsApp photo quality

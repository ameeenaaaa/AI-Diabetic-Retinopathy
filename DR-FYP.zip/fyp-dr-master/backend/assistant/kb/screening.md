title: Diabetic eye screening appointments (NHS)
source: Gloucestershire Hospitals NHS Foundation Trust, "Diabetic eye screening"; NHS "Diabetic retinopathy" — summaries in our own words
url: https://www.gloshospitals.nhs.uk/our-services/services-we-offer/diabetic-eye-screening/
kind: health
---
## What happens at a screening appointment
Eye drops are used to widen (dilate) the pupils so a camera can take clear photographs of the retina. Nothing touches the eye; there is a bright flash when each photograph is taken. Bring the glasses you use for distance vision.
Also asked: what will they do at the eye check; do they put drops in my eyes; does the eye test hurt; what is the eye photo appointment like

## After the drops
The drops can blur vision for roughly two to six hours. People are advised not to drive until the effect has worn off, so arrange other transport.
Also asked: can I drive afterwards; will my vision be blurry after the test; how long do the drops last

## How often to be screened
In the NHS, people with diabetes aged 12 and over are invited every one or two years. After a first screen with no retinopathy, the next invitation is usually after a year; after two screens in a row with no retinopathy, people at low risk are usually invited every two years. Anyone with changes is seen more often, and anyone referred is followed up by the hospital eye service. Follow the interval your own doctor or screening service gives you.
Also asked: how often should my eyes be checked; how many times a year; when is my next eye test due; every year or every two years

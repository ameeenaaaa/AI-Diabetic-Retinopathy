title: Stages and the 0 to 4 grading scale
source: Wilkinson CP et al., "Proposed international clinical diabetic retinopathy and diabetic macular edema disease severity scales", Ophthalmology 2003;110(9):1677-82 (doi:10.1016/S0161-6420(03)00475-5); NHS stage names — summaries in our own words
url: https://doi.org/10.1016/S0161-6420(03)00475-5
kind: health
---
## The 0 to 4 grading scale
Screening programmes and research datasets often grade diabetic retinopathy on a five-step international scale: 0 no apparent retinopathy, 1 mild non-proliferative, 2 moderate non-proliferative, 3 severe non-proliferative, and 4 proliferative. The training images for this app were labelled on this scale, which is why it reports grade names No DR, Mild, Moderate, Severe and Proliferative.
Also asked: what do the grade numbers mean; what is grade 2; how bad is my grade; levels of the disease

## Non-proliferative grades (1 to 3)
In mild disease the only change is microaneurysms, tiny bulges in the small vessels. Moderate disease has more than microaneurysms but less than severe. Severe non-proliferative disease has widespread bleeding spots in all four quarters of the retina, or beading of the veins, or abnormal small vessels inside the retina, but no new vessel growth yet.

## Proliferative grade (4)
Proliferative diabetic retinopathy means fragile new blood vessels have started to grow, or there has been bleeding into the eye. These new vessels can bleed or pull on the retina, so this stage carries the highest risk to sight and needs a specialist.
Also asked: what is the worst stage; can it make me lose my sight; can I go blind; new blood vessels growing

## The NHS stage names
The NHS screening programme uses different names: background retinopathy (small changes, sight not affected), pre-proliferative retinopathy (more widespread changes, more frequent checks), and proliferative retinopathy (new vessels, referral to a specialist for treatment). Diabetic maculopathy is the name for changes affecting the macula, the centre of the retina.

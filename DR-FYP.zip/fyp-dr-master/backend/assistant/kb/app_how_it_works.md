title: How this screening app works
source: Project documentation (this app)
url: /about
kind: app
---
## What the app does
The app looks at one colour photograph of the retina and estimates a diabetic retinopathy grade on the 0 to 4 scale. It is a research prototype and not a medical device. It does not diagnose anyone; only an examination by an eye specialist can do that.
Also asked: what does this website do; is this a diagnosis; what is this tool

## The score
The model produces one number, the score. A higher score means the model sees more severe changes. Everything else on the result page is read off this one score.
Also asked: what does my number mean; what is the score on my result

## Two separate answers: grade and referral
The grade comes from four cut points on the score, fitted to agree with human graders. The referral decision comes from a separate threshold on the same score, fitted so that the app flags as many cases that need a specialist as possible while flagging few that do not. Because the referral threshold (0.949) is below the cut point between Mild and Moderate (1.622), a score between them gives the grade Mild together with Refer. Both answers are correct readings of the score; neither overrides the other.
Also asked: why do grade and referral disagree; why does it say mild and refer; two different answers on the result; why refer if only mild

## How well it performs
On validation images the model flagged 73.6% of the images that needed referral, at 95% specificity. That means about one in four images that needed referral were not flagged. Its agreement with graders, measured as quadratic weighted kappa, was 0.7569. These are averages over three training runs and they are below the 0.80 sensitivity often used as a reference for screening.
Also asked: how accurate is it; how good is the model; can I trust the result; how often is it wrong; how reliable is this app

## Why "not flagged" is not reassurance
Because about one in four referable images were missed on validation, a result that is not flagged does not mean the eye is free of disease. People with diabetes should keep their regular dilated eye examinations whatever the app says.
Also asked: not flagged means I am okay; can I skip my eye examination; does no referral mean no disease

## Where it was trained and why that matters
The model was trained on EyePACS images from one screening population. On images from a different population its behaviour changed, and it showed a dependence on how the retina is framed in the photograph. Its thresholds were fitted on EyePACS and would need recalibrating before use anywhere else.
Also asked: will it work for people in Pakistan; what data was it trained on

title: Lowering the risk (NHS)
source: NHS, "Diabetic retinopathy" — summary in our own words
url: https://www.nhs.uk/conditions/diabetic-retinopathy/
kind: health
---
## Ways to lower the risk
The NHS lists the following: keep blood sugar levels well controlled (a diabetes education course can help), bring down high blood pressure and high cholesterol, do not smoke, and go to every diabetic eye screening appointment. Your diabetes team can help set targets that suit you.
Also asked: how do I protect my eyes; how to stop it getting worse; what can I do myself; diet and lifestyle for my eyes

## Blood sugar and HbA1c
HbA1c is a blood test that shows your average blood sugar over the past two to three months. Your diabetes team uses it to judge control over time. Bringing a recent HbA1c result to an eye appointment helps the clinic see the whole picture.
Also asked: what is the sugar test over three months; average blood glucose test; A1C number

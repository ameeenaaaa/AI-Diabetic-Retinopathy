title: Symptoms and when to get help (NHS)
source: NHS, "Diabetic retinopathy" — summary in our own words
url: https://www.nhs.uk/conditions/diabetic-retinopathy/
kind: health
---
## Symptoms of diabetic retinopathy
Later symptoms can include eyesight that slowly gets worse, blurred vision, floaters (small dots or lines that drift across your vision), and difficulty seeing in low light. One or both eyes can be affected. These symptoms do not always mean diabetic retinopathy, but they should be checked.
Also asked: what signs should I look out for; how would I notice it; spots or lines floating in my vision; trouble seeing at night

## When to contact a doctor or optician
If you have diabetes and your eyesight is getting worse over time, you notice floaters, or you find it hard to see in the dark, contact your doctor, your diabetes care team or an optician for a check.
Also asked: when should I see someone about my eyes; my eyesight is slowly getting worse

## When to get urgent help
If you have diabetes and your eyesight suddenly gets worse, or you suddenly develop blurred vision, get urgent medical help the same day. In the UK the NHS advises an urgent GP appointment or NHS 111; elsewhere, contact an eye doctor or a hospital eye department urgently. Do not wait for a routine appointment.
Also asked: when is it an emergency; when should I go to hospital

title: What to do after a result in this app
source: Project documentation (this app)
url: /about
kind: app
---
## If the result says Refer
The image was flagged for an eye-specialist assessment. That is a reason to be examined, not a finding about your eye. Request an appointment with an ophthalmologist or a retina specialist, tell them the photograph was flagged by a screening prototype, and bring the PDF report and any recent HbA1c results.
Also asked: what do I do now; my result says refer; what should I take to the eye clinic; next steps after refer

## If the result says Not flagged
Keep your routine dilated eye examinations. If you have not had one in the last year, book one with an ophthalmologist or a diabetic eye-screening service. Bring the PDF report.
Also asked: what to do if not flagged; do I still need an eye exam

## Specialist review in the app
When you save a result you can ask for it to be reviewed by an eye specialist using the app. The specialist sees the graded image and the model's answer and records whether they agree or what they would grade instead. The model's own answer is kept and shown beside the review.
Also asked: can a doctor check my result; ask an ophthalmologist to look at it; how does the review work

## Booking an appointment
Use Find a specialist to choose a clinic and send an appointment request with a preferred date and time. You can attach a saved screening. The clinic's specialist can confirm or decline it, and you can follow its status under My records. The clinics in the demo directory are invented.
Also asked: how do I book; make an appointment with an eye doctor; find a clinic

## Tracking over time
Saved screenings are grouped by eye under My records, where a chart shows how the score has changed between screenings. The app suggests a re-screening date one year after your last screening; your doctor may advise a different interval.
Also asked: has my eye got worse; compare my results; history of my screenings; when is my next screening

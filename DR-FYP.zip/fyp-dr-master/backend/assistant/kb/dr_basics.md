title: Diabetic retinopathy (NHS)
source: NHS, "Diabetic retinopathy" — summary in our own words
url: https://www.nhs.uk/conditions/diabetic-retinopathy/
kind: health
---
## What diabetic retinopathy is
Diabetic retinopathy is an eye condition caused by diabetes. High blood sugar (glucose) over time damages the small blood vessels in the retina, the light-sensitive layer at the back of the eye. Damaged vessels can leak, become blocked, or be replaced by fragile new vessels, and this can eventually affect sight.
Also asked: what is wrong with my eye from diabetes; how does diabetes harm the eyes; what causes damage inside the eye; does high sugar hurt my eyes

## Who is more likely to get it
It is more likely the longer a person has had diabetes. High blood pressure and high cholesterol also raise the risk. Anyone with type 1 or type 2 diabetes can develop it.
Also asked: am I at risk; who gets eye problems from diabetes; does having diabetes for many years matter

## Why screening matters when you feel fine
In the early stages diabetic retinopathy usually causes no symptoms, so a person can have it without noticing anything wrong with their sight. That is why people with diabetes are offered regular eye screening: it can find changes before they affect vision, when treatment works best.
Also asked: why test my eyes if I can see fine; do I need checks if I have no problems

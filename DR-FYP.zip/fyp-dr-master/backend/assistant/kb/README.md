# Assistant knowledge base

Every file here is a short summary **written by the project team in our own words** from
the source named in its header. They are not copies of the sources. Before the app is used
by anyone outside the project, a clinician should check each file against its source.

Header format (first lines, then `---`):

    title: <shown to the user as the source name>
    source: <publisher / citation>
    url: <link the user can open>
    kind: health | app

An optional `Also asked:` line inside a passage lists other ways patients phrase its
question, separated by `;`. It helps the search find the passage and is never shown or
sent to the language model as source text (DECISION-080).

`## ` headings split a file into the passages the retriever searches. Keep each passage on
one idea, so a citation points at something specific.

Adding a file: write it, restart the backend, then run `python tools/eval_assistant.py`
to check the assistant still passes its question set.

title: Diabetic macular oedema
source: Yorston D., "Understanding and managing sight-threatening diabetic retinopathy", Community Eye Health 2023;36(119):15-16; NHS "Diabetic retinopathy" — summaries in our own words
url: https://pmc.ncbi.nlm.nih.gov/articles/PMC10436770/
kind: health
---
## What macular oedema is
Diabetic macular oedema is a build-up of fluid in the macula, the small central part of the retina used for reading and recognising faces. When the very centre is affected, central vision becomes blurred even though side vision may still work.
Also asked: fluid in the centre of the eye; swelling at the back of the eye; central vision blurry; macula swollen

## How it is found
Macular oedema is usually confirmed with an OCT scan, a painless imaging test that shows the layers of the retina. A single colour photograph of the retina, like the one this app grades, cannot measure retinal swelling, so the app's grade says nothing reliable about macular oedema.
Also asked: how do doctors check for swelling; what is an OCT scan

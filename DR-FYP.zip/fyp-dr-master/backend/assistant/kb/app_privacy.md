title: Accounts and privacy in this app
source: Project documentation (this app)
url: /about
kind: app
---
## What is stored
With an account, the app stores the results you choose to save: the model's answer, the cropped image the model graded and its heatmap. Your original photograph is never stored. A result you do not save is deleted within a day.
Also asked: is my photo saved; what happens to my picture after upload; do you keep my images; is my data safe

## Who can see your screenings
Only you, and eye specialists using the app when you ask for a review or attach the screening to an appointment request. The administrator sees totals for the dashboard, not individual screenings.
Also asked: who can look at my results; can other people see my screening; is it private

## The assistant
The assistant does not keep your messages. The app counts how often it answered, refused or sent someone to urgent care, without storing what was asked.
Also asked: do you save my chat; are my questions stored

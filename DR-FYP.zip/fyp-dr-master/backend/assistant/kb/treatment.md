title: Treatment of diabetic retinopathy
source: NHS, "Diabetic retinopathy"; Yorston D., Community Eye Health 2023;36(119):15-16 — summaries in our own words
url: https://www.nhs.uk/conditions/diabetic-retinopathy/
kind: health
---
## The aim of treatment
Treatment aims to stop sight getting worse. Sight that has already been lost to diabetic retinopathy usually cannot be fully restored, which is why finding the condition early matters. Early stages are usually monitored with more frequent checks rather than treated.
Also asked: can it be cured; can lost sight come back; is there a fix

## Types of treatment
An eye specialist chooses the treatment. The main options are laser treatment to the retina, a course of injections into the eye with anti-VEGF medicine (repeated over many months), a steroid implant in the eye to reduce swelling, and surgery (vitrectomy) to remove blood or scar tissue from inside the eye. Good control of blood sugar, blood pressure and cholesterol matters at every stage.
Also asked: what will the eye doctor do; injections in the eye; laser on the eye; operation on the eye

## Medicines and doses
Decisions about any medicine or dose, including diabetes medicines and eye injections, are made by your own doctor. This app and its assistant do not give medicine or dose advice.

"""The assistant's safety rules, applied in code BEFORE and AFTER the language model.

A system prompt asks a model to behave; it does not make it behave. So the rules that
matter most are not left to the prompt:

BEFORE (no model call at all):
  urgent      sudden loss/blurring of sight, flashes, a curtain, eye pain -> fixed
              "get care today" reply. A model is never in the loop for an emergency.
  medication  doses, which medicine to take or stop -> fixed refusal.
  diagnosis   "do I have it?", "am I fine?", "is it 100%?" -> a fixed reply built from the
              screening result itself, which states what the app estimated and why that
              is not a diagnosis.

AFTER (on the model's draft):
  `unsafe_reason()` rejects a draft that diagnoses, reassures ("your eyes are fine"),
  waves away an examination, gives a confidence percentage, or names a dose. A rejected
  draft is replaced by a safe fallback and the turn is logged as `blocked`.

The patterns are deliberately broad. A false block costs one less-fluent answer; a missed
one could tell someone with sight-threatening disease that they are fine.
"""

from __future__ import annotations

import re

ARABIC_SCRIPT = re.compile(r"[؀-ۿ]")


def detect_lang(text: str, preferred: str = "en") -> str:
    """'ur' if the message is written in Urdu script, else the page language."""
    if ARABIC_SCRIPT.search(text):
        return "ur"
    return preferred if preferred in ("en", "ur") else "en"


# ------------------------------------------------------------------ before the model
URGENT_EN = re.compile(
    r"(sudden(ly)?|all of a sudden)\W+(\w+\W+){0,6}?"
    r"(lost|loss|lose|losing|can'?t see|cannot see|blind|blur|blurred|blurry|dark|black|"
    r"worse|vision|sight|floaters?|flash(es)?|shadow|curtain)"
    r"|(curtain|shadow|veil)\W+(\w+\W+){0,4}?(over|across|in)\W+(\w+\W+){0,3}?(eye|vision|sight)"
    r"|(worse|blur\w*|dark\w*|dim\w*|lost|gone|loss)\W+(\w+\W+){0,3}?(sudden(ly)?|overnight|"
    r"all of a sudden)"
    r"|flash(es|ing)? of light"
    r"|shower of (floaters|spots)"
    r"|(can'?t|cannot|unable to) see (anything|at all|out of)"
    r"|(lost|losing) (my )?(vision|sight)"
    r"|(severe|bad|terrible|sharp) (eye )?pain"
    r"|eye (is )?(very )?(painful|hurts? (a lot|badly))"
    r"|(went|gone) blind",
    re.I)
URGENT_UR = re.compile(r"اچانک|نظر چلی|دکھائی نہیں|دکھنا بند|اندھا|اندھیرا چھا|روشنی کی چمک|"
                       r"شدید درد|آنکھ میں درد")

MEDICATION = re.compile(
    r"\b(dose|doses|dosage|\d+\s?(mg|units?)\b|how much (insulin|metformin|medicine)|"
    r"which (medicine|medication|tablet|drug|pill|insulin)s?|what (medicine|medication|"
    r"tablet|drug|pill)s? (should|can|do)|should i (take|stop|start|change)\b|"
    r"can i (take|stop|skip) (taking )?(my |the |any |this )?(medicine|medication|insulin|tablets?|pills?|drugs?|dose)|(stop|skip|quit) (taking )?(my |the )?(medicine|medication|insulin|tablets?|pills?|drugs?)|"
    r"(can|should) i (take|use|have) (\w+ ){0,2}(paracetamol|panadol|aspirin|ibuprofen|brufen|metformin|"
    r"insulin|antibiotics?|steroids?|vitamins?|supplements?)|prescri(be|ption)|eye ?drops? (to|for|should))",
    re.I)
MEDICATION_UR = re.compile(r"دوا|دوائی|خوراک|انسولین|گولی")

DIAGNOSIS = re.compile(
    r"\b(do i (have|got)|have i got|i (don'?t|do not) have|i have no (sign|retinopathy|dr\b|"
    r"disease)|so i'?m (fine|ok|okay|safe)|am i (fine|ok|okay|safe|healthy|normal|alright|"
    r"going blind|sick|ill)|are my eyes (fine|ok|okay|healthy|normal|safe)|"
    r"is my eye (fine|ok|okay|healthy|normal|safe)|(definitely|certainly|surely)|"
    r"100 ?%|for sure|guarantee|will i (go blind|lose my (sight|vision))|"
    r"can i (trust|rely on) (this|the|it)|is (this|it|the result) (correct|right|true)|"
    r"diagnos)",
    re.I)
DIAGNOSIS_UR = re.compile(r"کیا مجھے|کیا میری آنکھ(یں)? ٹھیک|یقین|سو فیصد|اندھا ہو")


def classify(text: str) -> str | None:
    """'urgent' | 'medication' | 'diagnosis' | None — checked in that order."""
    if URGENT_EN.search(text) or URGENT_UR.search(text):
        return "urgent"
    if MEDICATION.search(text) or MEDICATION_UR.search(text):
        return "medication"
    if DIAGNOSIS.search(text) or DIAGNOSIS_UR.search(text):
        return "diagnosis"
    return None


# ------------------------------------------------------------------ after the model
UNSAFE = [
    (re.compile(r"(?<!whether )(?<!if )\byou (do not|don't|definitely|clearly|certainly|"
                r"probably)?\s*have "
                r"(diabetic retinopathy|retinopathy|dr\b|no (signs of )?(disease|"
                r"retinopathy|dr)|macular)", re.I), "states a diagnosis"),
    (re.compile(r"\byour eyes? (is|are) (fine|healthy|normal|ok|okay|safe|perfect)", re.I),
     "reassures that the eyes are fine"),
    (re.compile(r"\byou are (fine|healthy|normal|safe|ok|okay|in the clear)\b", re.I),
     "reassures that the person is fine"),
    (re.compile(r"\b(no need|don'?t need|do not need|not necessary) (to )?(see|visit|go|"
                r"get|have|book)", re.I), "waves away an examination"),
    (re.compile(r"\b\d{1,3}(\.\d+)?\s?% (confident|confidence|sure|certain|chance|"
                r"probability|likely|likelihood)", re.I), "gives a confidence figure"),
    (re.compile(r"\bconfidence (score|level|of)\b", re.I), "gives a confidence figure"),
    (re.compile(r"\b\d+(\.\d+)?\s?(mg|milligrams?|units? of)\b", re.I), "names a dose"),
    (re.compile(r"\b(i|we|this app|the app|the model) (diagnose|confirm|detected)", re.I),
     "claims to diagnose"),
    (re.compile(r"آپ کو (ذیابیطس ریٹینوپیتھی|بیماری) (ہے|نہیں ہے)(?! یا)|آپ کی آنکھیں ٹھیک ہیں|"
                r"ڈاکٹر (کے پاس )?جانے کی ضرورت نہیں"), "diagnoses or reassures (Urdu)"),
]

CITATION = re.compile(r"\[(S\d+|R)\]")


def unsafe_reason(answer: str) -> str | None:
    for pattern, why in UNSAFE:
        if pattern.search(answer):
            return why
    return None


def cited_ids(answer: str) -> list[str]:
    seen = []
    for m in CITATION.finditer(answer):
        if m.group(1) not in seen:
            seen.append(m.group(1))
    return seen


# ------------------------------------------------------------------ fixed replies
URGENT_REPLY = {
    "en": ("Sudden changes in your sight need urgent care today. Please contact an eye "
           "doctor or go to a hospital eye or emergency department now. Do not wait for an "
           "appointment request, a specialist review, or anything in this app. For people "
           "with diabetes, sudden worsening or sudden blurring of vision should always be "
           "checked the same day."),
    "ur": ("نظر میں اچانک تبدیلی کا آج ہی فوری معائنہ ضروری ہے۔ ابھی کسی آنکھوں کے ڈاکٹر "
           "سے رابطہ کریں یا ہسپتال کے آئی یا ایمرجنسی شعبے میں جائیں۔ اپوائنٹمنٹ کی "
           "درخواست، ماہر کے جائزے یا اس ایپ کی کسی چیز کا انتظار نہ کریں۔ ذیابیطس کے "
           "مریضوں میں نظر کا اچانک خراب یا دھندلا ہونا ہمیشہ اسی دن چیک کروانا چاہیے۔"),
}

MEDICATION_REPLY = {
    "en": ("I can't give advice about medicines or doses, including diabetes medicines and "
           "eye treatments. Those decisions belong to your own doctor, who knows your "
           "history. Do not start, stop or change any medicine because of this app. I can "
           "explain what the treatments for diabetic retinopathy are in general, if that "
           "helps."),
    "ur": ("میں دواؤں یا ان کی خوراک کے بارے میں مشورہ نہیں دے سکتا، چاہے وہ ذیابیطس کی "
           "دوائیں ہوں یا آنکھوں کا علاج۔ یہ فیصلے آپ کے اپنے ڈاکٹر کے ہیں۔ اس ایپ کی وجہ "
           "سے کوئی دوا شروع، بند یا تبدیل نہ کریں۔ اگر آپ چاہیں تو میں عام طور پر بتا سکتا "
           "ہوں کہ ذیابیطس ریٹینوپیتھی کے علاج کیا ہوتے ہیں۔"),
}

OUT_OF_SCOPE_REPLY = {
    "en": ("My sources don't cover that, so I won't guess. I can answer questions about "
           "diabetic retinopathy, eye screening, and how to read your result in this app. "
           "For anything else about your health, please ask your doctor."),
    "ur": ("میرے ذرائع میں اس کا جواب موجود نہیں، اس لیے میں اندازہ نہیں لگاؤں گا۔ میں "
           "ذیابیطس ریٹینوپیتھی، آنکھوں کی اسکریننگ اور اس ایپ میں آپ کے نتیجے کو سمجھنے کے "
           "بارے میں سوالات کے جواب دے سکتا ہوں۔ صحت کے دوسرے سوالات اپنے ڈاکٹر سے پوچھیں۔"),
}

BLOCKED_REPLY = {
    "en": ("I'm not able to answer that safely in my own words. What I can say: this app "
           "estimates a grade from one photograph and does not diagnose. Only an "
           "examination by an eye specialist can tell you what is happening in your eye. "
           "The sources below have more detail."),
    "ur": ("میں اس کا جواب محفوظ طریقے سے نہیں دے سکتا۔ اتنا بتا سکتا ہوں کہ یہ ایپ ایک "
           "تصویر سے گریڈ کا اندازہ لگاتی ہے اور تشخیص نہیں کرتی۔ آپ کی آنکھ کی اصل حالت "
           "صرف آنکھوں کے ماہر کا معائنہ بتا سکتا ہے۔ مزید تفصیل نیچے دیے گئے ذرائع میں ہے۔"),
}

OFFLINE_URDU_REPLY = (
    "یہ اسسٹنٹ ابھی آف لائن موڈ میں ہے اور صرف انگریزی سوالات سمجھ سکتا ہے۔ اردو میں جواب "
    "کے لیے ایڈمنسٹریٹر کو Gemini یا Groq کی کلید (key) سیٹ کرنی ہوگی۔")


def diagnosis_reply(result: dict | None, missed_pct: int, lang: str) -> str:
    """A fixed, result-specific answer to 'do I have it / am I fine?'."""
    if lang == "ur":
        if result is None:
            return ("میں نہیں بتا سکتا کہ آپ کو ذیابیطس ریٹینوپیتھی ہے یا نہیں۔ یہ صرف آنکھوں کے "
                    "ماہر کا معائنہ بتا سکتا ہے۔ یہ ایپ صرف ایک تصویر سے گریڈ کا اندازہ لگاتی "
                    "ہے اور تشخیص نہیں کرتی۔")
        refer = "ریفر (ماہر سے معائنہ)" if result["referable"] else "فلیگ نہیں ہوا"
        tail = (" ریفر کا مطلب ہے کہ معائنہ کروانے کی وجہ ہے، یہ آپ کی آنکھ کے بارے میں حتمی "
                "بات نہیں۔") if result["referable"] else (
                f" فلیگ نہ ہونا اطمینان کی ضمانت نہیں: جانچ کی تصاویر میں تقریباً {missed_pct}٪ "
                "ایسی تصاویر بھی فلیگ نہیں ہوئیں جنہیں ریفر ہونا چاہیے تھا۔")
        return ("میں نہیں بتا سکتا کہ آپ کو ذیابیطس ریٹینوپیتھی ہے یا نہیں، اور نہ ہی کوئی "
                "یقینی فیصد دے سکتا ہوں۔ اس ایپ نے آپ کی تصویر سے گریڈ "
                f"{result['grade_name']} کا اندازہ لگایا اور ریفرل کا جواب: {refer} [R]۔"
                + tail + " آپ کی آنکھ کی اصل حالت صرف آنکھوں کے ماہر کا معائنہ بتا سکتا ہے۔")
    if result is None:
        return ("I can't tell you whether you have diabetic retinopathy, and I can't give a "
                "percentage for it. Only an examination by an eye specialist can do that. "
                "This app estimates a grade from one photograph; it does not diagnose [S1].")
    refer = "Refer" if result["referable"] else "Not flagged"
    tail = (" Refer means there is a reason to be examined; it is not a finding about your "
            "eye.") if result["referable"] else (
            f" Not flagged is not reassurance: on validation images about {missed_pct}% of "
            "the images that needed referral were not flagged either [S2].")
    return ("I can't tell you whether you have diabetic retinopathy, and there is no "
            "percentage of certainty to give; the model does not produce one. What the app "
            f"did: from your photograph it estimated the grade {result['grade_name']}, and "
            f"its referral answer is {refer} [R]." + tail +
            " Only an examination by an eye specialist can tell you what is happening in your "
            "eye [S1].")

"""Settings for the web application, read from the environment and an optional `.env` file.

`.env` sits in the repository root and is gitignored. It exists so the assistant's API key
and the checkpoint path are typed ONCE rather than in every terminal window (PowerShell's
`set` does not export to child processes, which is the most common setup mistake on
Windows). Values already in the environment win over the file, so a one-off override in a
terminal still works.

Standard library only — no python-dotenv dependency for six lines of parsing.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ENV_FILE = REPO / ".env"
DEFAULT_GEMINI_MODELS = ("gemini-flash-latest,gemini-flash-lite-latest,gemini-3.5-flash,"
                         "gemini-3.5-flash-lite")


def load_env_file(path: Path = ENV_FILE) -> None:
    """KEY=VALUE lines into os.environ, without overriding what is already set."""
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


@dataclass(frozen=True)
class Settings:
    db_path: Path
    seed_demo: bool
    session_hours: int
    assistant_provider: str          # gemini | groq | ollama | offline
    gemini_api_key: str
    gemini_model: str
    groq_api_key: str
    groq_model: str
    ollama_url: str
    ollama_model: str

    @classmethod
    def from_env(cls) -> "Settings":
        load_env_file()
        e = os.environ.get
        provider = (e("ASSISTANT_PROVIDER") or "").strip().lower()
        if not provider:
            # Pick the first provider that has what it needs; offline otherwise.
            provider = ("gemini" if e("GEMINI_API_KEY") else
                        "groq" if e("GROQ_API_KEY") else "offline")
        if provider not in {"gemini", "groq", "ollama", "offline"}:
            raise ValueError(f"ASSISTANT_PROVIDER={provider!r}; expected gemini, groq, "
                             "ollama or offline")
        db = Path(e("FYP_DB_PATH") or (REPO / "var" / "app.db"))
        return cls(
            db_path=db,
            seed_demo=(e("FYP_SEED_DEMO", "1") != "0"),
            session_hours=int(e("FYP_SESSION_HOURS", "72")),
            assistant_provider=provider,
            gemini_api_key=e("GEMINI_API_KEY", ""),
            # Comma-separated, tried in order (busy or retired models are skipped). The
            # "-latest" aliases follow Google's current models, so the default does not go
            # stale when a version is retired for new keys.
            gemini_model=e("GEMINI_MODEL") or DEFAULT_GEMINI_MODELS,
            groq_api_key=e("GROQ_API_KEY", ""),
            groq_model=e("GROQ_MODEL", "llama-3.3-70b-versatile"),
            ollama_url=e("OLLAMA_URL", "http://localhost:11434"),
            ollama_model=e("OLLAMA_MODEL", "llama3.2:3b"),
        )
